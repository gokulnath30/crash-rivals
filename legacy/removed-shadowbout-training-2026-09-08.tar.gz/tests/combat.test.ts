import { describe, expect, it } from 'vitest';
import { applyHit, judgeContact, type Strike } from '@domain/fighting/combat.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { RULES } from '@domain/fighting/moves.ts';

const punch: Strike = {
  joint: 'wrL',
  reach: RULES.contact.punch,
  damage: 10,
  heavy: false,
  label: 'jab',
};

/** Two fighters facing each other in their neutral stances. */
function pair(): { attacker: Fighter; defender: Fighter } {
  return {
    attacker: new Fighter({ name: 'A', side: -1 }),
    defender: new Fighter({ name: 'B', side: 1 }),
  };
}

/**
 * Puts the attacker's fist on the defender's head. Written in terms of the
 * defender's actual world position rather than hard-coded numbers, so the
 * test still means the same thing if the stance is re-tuned.
 */
function aimAtHead(attacker: Fighter, defender: Fighter): void {
  // Placed so the fist lands exactly on the head in world space. The attacker
  // faces the opponent with no turn, so its local frame is unrotated and the
  // world offset can be used directly.
  const head = defender.worldOf('head');
  attacker.pose.wrL.set(
    head.x - attacker.position.x,
    head.y - attacker.position.y,
    head.z - attacker.position.z,
  );
}

describe('judging contact', () => {
  it('lands a blow lined up with the head', () => {
    const { attacker, defender } = pair();
    aimAtHead(attacker, defender);
    const judgement = judgeContact(attacker, defender, punch);
    expect(judgement.landed).toBe(true);
    if (judgement.landed) expect(judgement.zone).toBe('head');
  });

  it('lands a blow at chest height as a body shot', () => {
    const { attacker, defender } = pair();
    const chest = defender.worldOf('chest');
    attacker.pose.wrL.set(chest.x - attacker.position.x, chest.y - attacker.position.y, 0.5);
    const judgement = judgeContact(attacker, defender, punch);
    expect(judgement.landed).toBe(true);
    if (judgement.landed) expect(judgement.zone).toBe('body');
  });

  it('misses when the fist is off to one side', () => {
    const { attacker, defender } = pair();
    aimAtHead(attacker, defender);
    // Well past the contact radius.
    attacker.pose.wrL.x += 1.2;
    const judgement = judgeContact(attacker, defender, punch);
    expect(judgement.landed).toBe(false);
    if (!judgement.landed) expect(judgement.hint).toBe('line up with them');
  });

  it('misses when the fighters are too far apart to reach', () => {
    const { attacker, defender } = pair();
    aimAtHead(attacker, defender);
    defender.position.z += 3;
    const judgement = judgeContact(attacker, defender, punch);
    expect(judgement.landed).toBe(false);
    if (!judgement.landed) expect(judgement.hint).toBe('too far — step in');
  });

  describe('the hand has to actually reach them', () => {
    /** Puts the fist at chest height, dead in line, `short` metres shy. */
    function reachTowardChest(attacker: Fighter, defender: Fighter, short: number): void {
      const chest = defender.worldOf('chest');
      attacker.pose.wrL.set(
        chest.x - attacker.position.x,
        chest.y - attacker.position.y,
        chest.z - attacker.position.z - short,
      );
    }

    it('lands a punch that arrives on the body', () => {
      const { attacker, defender } = pair();
      reachTowardChest(attacker, defender, 0.1);
      expect(judgeContact(attacker, defender, punch).landed).toBe(true);
    });

    it('misses a punch thrown into thin air', () => {
      // The old test asked only whether the two fighters were roughly lined
      // up and roughly close, so a half-extended arm connected with somebody
      // most of a metre away. Once real characters are on screen that reads
      // as plainly broken.
      const { attacker, defender } = pair();
      reachTowardChest(attacker, defender, 0.7);
      const judgement = judgeContact(attacker, defender, punch);
      expect(judgement.landed).toBe(false);
      if (!judgement.landed) expect(judgement.hint).toBe('too far — step in');
    });

    it('forgives depth more than it forgives sideways error', () => {
      // A webcam knows where your hand is left-to-right far better than how
      // far away it is, so the two axes are not weighted the same.
      const chestGap = 0.34;
      const depthMiss = pair();
      reachTowardChest(depthMiss.attacker, depthMiss.defender, chestGap);
      const sideMiss = pair();
      reachTowardChest(sideMiss.attacker, sideMiss.defender, 0);
      sideMiss.attacker.pose.wrL.x += chestGap;

      expect(judgeContact(depthMiss.attacker, depthMiss.defender, punch).landed).toBe(true);
      expect(judgeContact(sideMiss.attacker, sideMiss.defender, punch).landed).toBe(false);
    });

    it('gives a kick more reach than a punch, as a leg has', () => {
      const kick: Strike = { ...punch, joint: 'anR', reach: RULES.contact.kick, heavy: true };
      const { attacker, defender } = pair();
      const chest = defender.worldOf('chest');
      attacker.pose.anR.set(
        chest.x - attacker.position.x,
        chest.y - attacker.position.y,
        chest.z - attacker.position.z - 0.55,
      );
      expect(judgeContact(attacker, defender, kick).landed).toBe(true);
      // The same distance is out of range for a fist.
      attacker.pose.wrL.copyFrom(attacker.pose.anR);
      expect(judgeContact(attacker, defender, punch).landed).toBe(false);
    });

    it('puts the spark where the hand is, not inside the torso', () => {
      const { attacker, defender } = pair();
      reachTowardChest(attacker, defender, 0.12);
      const judgement = judgeContact(attacker, defender, punch);
      expect(judgement.landed).toBe(true);
      if (!judgement.landed) return;
      const fist = attacker.worldOf('wrL');
      const chest = defender.worldOf('chest');
      // Biased toward the fist, so it reads as a collision.
      expect(Math.abs(judgement.contact.z - fist.z)).toBeLessThan(
        Math.abs(judgement.contact.z - chest.z),
      );
    });
  });

  it('does not mutate either fighter', () => {
    const { attacker, defender } = pair();
    aimAtHead(attacker, defender);
    judgeContact(attacker, defender, punch);
    expect(defender.hp).toBe(RULES.maxHp);
    expect(defender.hurtFor).toBe(0);
  });
});

describe('applying a hit', () => {
  function land(overrides: Partial<Strike> = {}, block = false) {
    const { attacker, defender } = pair();
    aimAtHead(attacker, defender);
    defender.blocking = block;
    const strike = { ...punch, ...overrides };
    const judgement = judgeContact(attacker, defender, strike);
    if (!judgement.landed) throw new Error('the test setup failed to land the blow');
    const events = applyHit({ attacker, defender, attackerIndex: 0, strike, judgement });
    return { attacker, defender, events };
  }

  it('takes health off the defender and reports the blow', () => {
    const { defender, events } = land();
    expect(defender.hp).toBeLessThan(RULES.maxHp);
    expect(events[0]?.kind).toBe('hit');
  });

  it('scales a head shot up', () => {
    const { defender } = land();
    // 10 damage × the 1.2 head multiplier.
    expect(RULES.maxHp - defender.hp).toBe(12);
  });

  it('cuts a blocked blow to a fraction and leaves the stance intact', () => {
    const { defender, events } = land({}, true);
    const taken = RULES.maxHp - defender.hp;
    expect(taken).toBeLessThan(5);
    expect(defender.hurtFor).toBe(0);
    const [first] = events;
    expect(first?.kind === 'hit' && first.blocked).toBe(true);
  });

  it('staggers an unblocked defender', () => {
    const { defender } = land();
    expect(defender.hurtFor).toBeGreaterThan(0);
    expect(defender.knockback).toBeGreaterThan(0);
  });

  it('reads a head shot as heavy even from a light punch', () => {
    const { events } = land();
    const [first] = events;
    expect(first?.kind === 'hit' && first.heavy).toBe(true);
  });

  it('raises a knockout and puts them down when health runs out', () => {
    const { defender, events } = land({ damage: 500 });
    expect(defender.hp).toBe(0);
    expect(defender.down).toBe(true);
    expect(events.some((event) => event.kind === 'knockout')).toBe(true);
  });

  it('does not raise a knockout while health remains', () => {
    const { events } = land();
    expect(events.some((event) => event.kind === 'knockout')).toBe(false);
  });
});
