import { describe, expect, it } from 'vitest';
import { Fighter } from '@domain/fighting/fighter.ts';
import { detectGestureStrikes, isTelegraphingPunch, scriptedStrike } from '@domain/fighting/gestures.ts';
import { MOVES, RULES } from '@domain/fighting/moves.ts';

/**
 * Reading punches off a pose.
 *
 * These are the thresholds that decide whether the game feels responsive or
 * possessed, so they are worth pinning down: a hand held out is not a punch, a
 * hand thrown forward is, and one swing is one hit.
 */

/** Puts a wrist out in front of the chest and gives it some speed. */
function throwPunch(fighter: Fighter, options: { extension: number; speed: number }): void {
  fighter.pose.wrL.z = fighter.pose.chest.z + options.extension;
  fighter.speed.wrL = options.speed;
  fighter.forwardSpeed.wrL = options.speed;
}

const fresh = (): Fighter => new Fighter({ name: 'A', side: -1 });

describe('detecting a punch', () => {
  it('registers a fast, extended hand', () => {
    const fighter = fresh();
    throwPunch(fighter, { extension: 0.4, speed: 2 });
    const strikes = detectGestureStrikes(fighter);
    expect(strikes).toHaveLength(1);
    expect(strikes[0]?.joint).toBe('wrL');
    expect(strikes[0]?.heavy).toBe(false);
  });

  it('ignores a hand held out but not moving', () => {
    // Standing with your arm out is a pose, not a punch.
    const fighter = fresh();
    throwPunch(fighter, { extension: 0.5, speed: 0 });
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('ignores a fast hand that is not extended', () => {
    const fighter = fresh();
    throwPunch(fighter, { extension: 0, speed: 4 });
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('accepts a shorter reach if it is travelling at the opponent', () => {
    // Half the extension, but committed forward speed — that is a jab.
    const fighter = fresh();
    fighter.pose.wrL.z = fighter.pose.chest.z + 0.2;
    fighter.speed.wrL = 0.2;
    fighter.forwardSpeed.wrL = 2;
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
  });

  it('puts the hands on cooldown so one swing lands once', () => {
    const fighter = fresh();
    throwPunch(fighter, { extension: 0.4, speed: 2 });
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
    // The pose has not changed, but the limb is spent.
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
    expect(fighter.cooldownMs.punch).toBe(RULES.cooldownMs.punch);
  });

  it('throws nothing while guarding', () => {
    const fighter = fresh();
    fighter.blocking = true;
    throwPunch(fighter, { extension: 0.4, speed: 2 });
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('throws nothing while down', () => {
    const fighter = fresh();
    fighter.putDown();
    throwPunch(fighter, { extension: 0.4, speed: 2 });
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('scales damage with speed, within limits', () => {
    const slow = fresh();
    throwPunch(slow, { extension: 0.4, speed: 1.2 });
    const fast = fresh();
    throwPunch(fast, { extension: 0.4, speed: 9 });

    const slowDamage = detectGestureStrikes(slow)[0]?.damage ?? 0;
    const fastDamage = detectGestureStrikes(fast)[0]?.damage ?? 0;
    expect(fastDamage).toBeGreaterThan(slowDamage);
    // Clamped, so a tracking glitch cannot produce a one-frame knockout.
    expect(fastDamage).toBeLessThanOrEqual(15);
  });

  it('reports only one punch even with both hands out', () => {
    const fighter = fresh();
    throwPunch(fighter, { extension: 0.4, speed: 2 });
    fighter.pose.wrR.z = fighter.pose.chest.z + 0.4;
    fighter.speed.wrR = 2;
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
  });
});

describe('detecting a kick', () => {
  function throwKick(fighter: Fighter): void {
    // A real kick: foot off the floor, *knee raised with it*, driven forward.
    fighter.pose.anR.y = fighter.pose.pelvis.y - 0.2;
    fighter.pose.knR.y = fighter.pose.pelvis.y - 0.15;
    fighter.pose.anR.z = fighter.pose.chest.z + 0.4;
    fighter.speed.anR = 2;
    fighter.forwardSpeed.anR = 2;
  }

  it('registers a lifted, extended, moving foot', () => {
    const fighter = fresh();
    throwKick(fighter);
    const strikes = detectGestureStrikes(fighter);
    expect(strikes).toHaveLength(1);
    expect(strikes[0]?.heavy).toBe(true);
    expect(strikes[0]?.label).toBe('kick');
    expect(strikes[0]?.reach).toBe(RULES.contact.kick);
  });

  it('ignores a foot on the floor, however fast it moves', () => {
    // Otherwise walking about the room would be a barrage of kicks.
    const fighter = fresh();
    fighter.pose.anR.z = fighter.pose.chest.z + 0.4;
    fighter.speed.anR = 4;
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('ignores a raised foot when the knee stays down', () => {
    // This is a step, not a kick — and it is what the game used to mistake
    // for one. The knee coming up is what tells them apart.
    const fighter = fresh();
    fighter.pose.anR.y = fighter.pose.pelvis.y - 0.2;
    fighter.pose.anR.z = fighter.pose.chest.z + 0.4;
    fighter.speed.anR = 2;
    fighter.forwardSpeed.anR = 2;
    // Knee left at its resting height.
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('quietens the hands briefly after a kick', () => {
    const fighter = fresh();
    throwKick(fighter);
    detectGestureStrikes(fighter);
    expect(fighter.cooldownMs.kick).toBe(RULES.cooldownMs.kick);
    expect(fighter.cooldownMs.punch).toBeGreaterThan(0);
  });

  it('hits harder than a punch at the same speed', () => {
    const puncher = fresh();
    throwPunch(puncher, { extension: 0.4, speed: 2 });
    const kicker = fresh();
    throwKick(kicker);

    const punchDamage = detectGestureStrikes(puncher)[0]?.damage ?? 0;
    const kickDamage = detectGestureStrikes(kicker)[0]?.damage ?? 0;
    expect(kickDamage).toBeGreaterThan(punchDamage);
  });
});

describe('scripted moves', () => {
  it('lands once, partway into the extension', () => {
    const fighter = fresh();
    expect(fighter.throwMove('jab')).toBe(true);

    // Nothing on the first frame: the fist has not arrived yet.
    expect(scriptedStrike(fighter)).toBeNull();

    // Contact is a little way into the held extension, not at the start of
    // the wind-up, so advance just past that point.
    const jab = MOVES.jab;
    fighter.blendAnimation(jab.wind + jab.hold * 0.5, 0);
    const strike = scriptedStrike(fighter);
    expect(strike?.label).toBe('jab');

    // And not again, however long the move is held.
    expect(scriptedStrike(fighter)).toBeNull();
  });

  it('refuses a new move while one is mid-swing', () => {
    const fighter = fresh();
    fighter.throwMove('jab');
    expect(fighter.throwMove('cross')).toBe(false);
  });

  it('refuses a move while staggered', () => {
    const fighter = fresh();
    fighter.stagger(10);
    expect(fighter.throwMove('jab')).toBe(false);
  });
});

describe('reading a telegraph', () => {
  it('sees a punch being wound up', () => {
    const fighter = fresh();
    throwPunch(fighter, { extension: 0.35, speed: 2 });
    expect(isTelegraphingPunch(fighter)).toBe(true);
  });

  it('is not fooled by a still stance', () => {
    expect(isTelegraphingPunch(fresh())).toBe(false);
  });
});
