import { describe, expect, it } from 'vitest';
import type { BodyReading } from '@domain/fighting/body-reading.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { RULES } from '@domain/fighting/moves.ts';
import { LANDMARK, type Triple } from '@domain/fighting/skeleton.ts';

/**
 * Turning your body turns your fighter.
 *
 * The angle is read from the line across the shoulders: at rest it runs along
 * the fighter's own X, and turning swings it into Z, so its angle in the XZ
 * plane *is* the body's rotation. No calibration step, nothing to press.
 *
 * These tests build a synthetic camera reading for a body rotated by a known
 * angle and check the fighter arrives at it — which is the only way to verify
 * the derivation without standing in front of a webcam.
 */

/**
 * A neutral standing body, in the vision model's own convention: x to the
 * subject's left as the image sees it, y *down*, z toward the camera, all
 * relative to the hips.
 */
const NEUTRAL: Readonly<Record<number, Triple>> = {
  [LANDMARK.nose]: [0, -0.72, 0.04],
  [LANDMARK.shoulderL]: [0.19, -0.46, 0],
  [LANDMARK.shoulderR]: [-0.19, -0.46, 0],
  [LANDMARK.elbowL]: [0.27, -0.24, -0.12],
  [LANDMARK.elbowR]: [-0.27, -0.24, -0.12],
  [LANDMARK.wristL]: [0.15, -0.42, -0.24],
  [LANDMARK.wristR]: [-0.15, -0.42, -0.24],
  [LANDMARK.hipL]: [0.11, 0, 0],
  [LANDMARK.hipR]: [-0.11, 0, 0],
  [LANDMARK.kneeL]: [0.15, 0.42, -0.06],
  [LANDMARK.kneeR]: [-0.16, 0.42, 0.02],
  [LANDMARK.ankleL]: [0.16, 0.84, -0.1],
  [LANDMARK.ankleR]: [-0.17, 0.84, 0.06],
};

/**
 * A reading of that body turned by `yaw`, in the game's sense of yaw: the
 * same rotation `Fighter.worldOf` applies, so a positive angle turns the
 * fighter's left shoulder toward the opponent.
 */
function readingTurnedBy(yaw: number): BodyReading {
  const cos = Math.cos(yaw);
  const sin = Math.sin(yaw);
  const world: Triple[] = [];
  const normalised: Triple[] = [];

  for (let index = 0; index < 33; index++) {
    const point = NEUTRAL[index] ?? ([0, 0, 0] as Triple);
    // Convert to the game's space (y up, z toward the opponent), rotate, then
    // convert back — so the reading is what a camera would actually have seen.
    const [gx, gy, gz] = [point[0], -point[1], -point[2]];
    const rx = gx * cos + gz * sin;
    const rz = -gx * sin + gz * cos;
    world.push([rx, -gy, -rz]);
    // Hips centred in frame, so the strafe reading stays neutral.
    normalised.push([0.5, 0.5, 0]);
  }
  return { world, normalised };
}

/** The camera delivers many readings a second; convergence is over frames. */
function settleAt(fighter: Fighter, yaw: number, frames = 60): void {
  const reading = readingTurnedBy(yaw);
  for (let i = 0; i < frames; i++) fighter.applyBodyReading(reading);
}

const fresh = (side: -1 | 1 = -1): Fighter => new Fighter({ name: 'A', side });

describe('reading the body turn', () => {
  it('stays square when the player faces the camera', () => {
    const fighter = fresh();
    settleAt(fighter, 0);
    expect(fighter.facing).toBeCloseTo(0, 2);
  });

  it('follows a turn to the left', () => {
    const fighter = fresh();
    settleAt(fighter, 0.9);
    expect(fighter.facing).toBeCloseTo(0.9, 1);
  });

  it('follows a turn to the right', () => {
    const fighter = fresh();
    settleAt(fighter, -1.1);
    expect(fighter.facing).toBeCloseTo(-1.1, 1);
  });

  it('follows a turn all the way to side-on', () => {
    const fighter = fresh();
    settleAt(fighter, Math.PI / 2);
    expect(fighter.facing).toBeCloseTo(Math.PI / 2, 1);
  });

  it('will not turn further than the limit', () => {
    // Past this the shoulders foreshorten to nothing and a single camera
    // cannot honestly tell facing away from facing forward.
    const fighter = fresh();
    settleAt(fighter, 3.1);
    expect(Math.abs(fighter.facing)).toBeLessThanOrEqual(RULES.turnLimit + 1e-6);
  });

  it('eases into a turn rather than snapping to it', () => {
    const fighter = fresh();
    settleAt(fighter, 1.2, 1);
    // One frame gets part of the way, not all of it.
    expect(fighter.facing).toBeGreaterThan(0);
    expect(fighter.facing).toBeLessThan(1.2);
  });

  it('comes back to square when the player faces front again', () => {
    const fighter = fresh();
    settleAt(fighter, 1.3);
    settleAt(fighter, 0);
    expect(fighter.facing).toBeCloseTo(0, 1);
  });

  it('resets the turn between rounds', () => {
    const fighter = fresh();
    settleAt(fighter, 1.2);
    fighter.reset();
    expect(fighter.facing).toBe(0);
  });
});

describe('the turn moves what can be hit', () => {
  it('is folded into the fighter yaw', () => {
    const near = fresh(-1);
    near.facing = 0.5;
    expect(near.yaw).toBeCloseTo(0.5, 6);

    // The far fighter is squared up by a half turn, then turns from there.
    const far = fresh(1);
    far.facing = 0.5;
    expect(far.yaw).toBeCloseTo(Math.PI + 0.5, 6);
  });

  it('moves a fist in the world when the body turns', () => {
    // This is the point of putting the turn in the domain rather than the
    // renderer: a fist is hittable exactly where it is drawn.
    const fighter = fresh(-1);
    fighter.pose.wrL.set(0, 0.45, 0.7);

    const square = fighter.worldOf('wrL').clone();
    fighter.facing = Math.PI / 2;
    const turned = fighter.worldOf('wrL');

    expect(turned.x).not.toBeCloseTo(square.x, 2);
    expect(turned.z).not.toBeCloseTo(square.z, 2);
    // A quarter turn sends what was straight ahead out to the side.
    expect(turned.x - fighter.position.x).toBeCloseTo(0.7, 5);
    expect(turned.z - fighter.position.z).toBeCloseTo(0, 5);
  });

  it('leaves height alone, whatever the turn', () => {
    const fighter = fresh();
    fighter.pose.wrL.set(0.1, 0.5, 0.6);
    const before = fighter.worldOf('wrL').y;
    fighter.facing = -1.4;
    expect(fighter.worldOf('wrL').y).toBeCloseTo(before, 6);
  });

  it('matches the old behaviour when nobody has turned', () => {
    // The far fighter used to be mirrored by flipping x and z; the general
    // rotation has to agree with that at facing zero.
    const far = fresh(1);
    far.pose.wrL.set(0.2, 0.5, 0.7);
    const world = far.worldOf('wrL');
    expect(world.x - far.position.x).toBeCloseTo(-0.2, 5);
    expect(world.z - far.position.z).toBeCloseTo(-0.7, 5);
  });
});
