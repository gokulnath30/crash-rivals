import { describe, expect, it } from 'vitest';
import { MAX_PUNCH_OPENNESS, type BodyReading, type HandsReading } from '@domain/fighting/body-reading.ts';
import { judgeContact, type Strike } from '@domain/fighting/combat.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { detectGestureStrikes } from '@domain/fighting/gestures.ts';
import { RULES } from '@domain/fighting/moves.ts';
import { LANDMARK, type Triple } from '@domain/fighting/skeleton.ts';

/**
 * What the hand tracker buys.
 *
 * The pose model stops at the wrist, so a punch was aimed from the wrist —
 * most of a hand short of where it actually lands. The holistic tracker adds
 * the knuckles, and whether the hand is a fist at all.
 *
 * All of it is optional: shared-screen play needs two bodies and only the
 * pose-only tracker can see two, so every one of these behaviours has to
 * degrade to the old one when the hands are absent.
 */

const NEUTRAL: Readonly<Record<number, Triple>> = {
  [LANDMARK.nose]: [0, -0.72, 0.04],
  [LANDMARK.shoulderL]: [0.19, -0.46, 0],
  [LANDMARK.shoulderR]: [-0.19, -0.46, 0],
  [LANDMARK.elbowL]: [0.27, -0.24, -0.12],
  [LANDMARK.elbowR]: [-0.27, -0.24, -0.12],
  [LANDMARK.wristL]: [0.15, -0.42, -0.24],
  [LANDMARK.wristR]: [-0.15, -0.42, -0.24],
  [LANDMARK.hipL]: [0.11, 0, 0],
  [LANDMARK.hipR]: [-0.11, 0, 0],
  [LANDMARK.kneeL]: [0.15, 0.42, -0.06],
  [LANDMARK.kneeR]: [-0.16, 0.42, 0.02],
  [LANDMARK.ankleL]: [0.16, 0.84, -0.1],
  [LANDMARK.ankleR]: [-0.17, 0.84, 0.06],
};

function reading(hands?: HandsReading): BodyReading {
  const world: Triple[] = [];
  const normalised: Triple[] = [];
  for (let i = 0; i < 33; i++) {
    world.push(NEUTRAL[i] ?? ([0, 0, 0] as Triple));
    normalised.push([0.5, 0.5, 0]);
  }
  return hands ? { world, normalised, hands } : { world, normalised };
}

/** Applied repeatedly, because the offsets are eased rather than copied. */
function settle(fighter: Fighter, hands?: HandsReading, frames = 40): void {
  const frame = reading(hands);
  for (let i = 0; i < frames; i++) fighter.applyBodyReading(frame);
}

const fresh = (): Fighter => new Fighter({ name: 'A', side: -1 });

const fist = (knuckles: Triple, openness = 0.1) => ({ knuckles, openness });

describe('knuckles', () => {
  it('start at the wrist when nothing has been tracked', () => {
    const fighter = fresh();
    const wrist = fighter.worldOf('wrL');
    const strike = fighter.strikePointOf('wrL');
    expect(strike.x).toBeCloseTo(wrist.x, 6);
    expect(strike.z).toBeCloseTo(wrist.z, 6);
  });

  it('move the strike point past the wrist once a hand is seen', () => {
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09]), right: null });

    const wrist = fighter.worldOf('wrL');
    const strike = fighter.strikePointOf('wrL');
    // Toward the opponent, by most of the knuckle offset.
    expect(strike.z - wrist.z).toBeGreaterThan(0.05);
  });

  it('turns the offset with the body', () => {
    // Otherwise a turned fighter's strike point would stay pointing at where
    // the opponent used to be.
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09]), right: null });
    fighter.facing = Math.PI / 2;

    const wrist = fighter.worldOf('wrL');
    const strike = fighter.strikePointOf('wrL');
    // A quarter turn sends a forward offset out to the side.
    expect(strike.x - wrist.x).toBeGreaterThan(0.05);
    expect(Math.abs(strike.z - wrist.z)).toBeLessThan(0.02);
  });

  it('leaves the feet alone', () => {
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09]), right: fist([0, 0, 0.09]) });
    const ankle = fighter.worldOf('anR');
    const strike = fighter.strikePointOf('anR');
    expect(strike.z).toBeCloseTo(ankle.z, 6);
  });

  it('eases back toward the wrist when the hand is lost', () => {
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09]), right: null });
    const held = fighter.knuckles.wrL.z;

    settle(fighter, { left: null, right: null }, 5);
    // Decaying, not snapping — a jump of a hand's length mid-punch would
    // register as a strike on its own.
    expect(fighter.knuckles.wrL.z).toBeLessThan(held);
    expect(fighter.knuckles.wrL.z).toBeGreaterThan(0);
  });

  it('lets a punch reach further than it used to', () => {
    const punch: Strike = {
      joint: 'wrL',
      reach: RULES.contact.punch,
      damage: 10,
      heavy: false,
      label: 'jab',
    };
    const defender = new Fighter({ name: 'B', side: 1 });
    const chest = defender.worldOf('chest');

    // Depth counts at `depthTrust`, so the furthest a purely-forward punch can
    // land from is this. Derived rather than hard-coded, so the test keeps
    // meaning the same thing if the tuning moves.
    const depthLimit = RULES.contact.punch / RULES.depthTrust;

    /** Puts the wrist just beyond that limit — out of reach on its own. */
    const place = (fighter: Fighter): void => {
      fighter.pose.wrL.set(
        chest.x - fighter.position.x,
        chest.y - fighter.position.y,
        chest.z - fighter.position.z - (depthLimit + 0.03),
      );
    };

    const wristOnly = fresh();
    place(wristOnly);
    expect(judgeContact(wristOnly, defender, punch).landed).toBe(false);

    const withHands = fresh();
    settle(withHands, { left: fist([0, 0, 0.1]), right: null });
    place(withHands);
    // The same arm, the same distance — but the knuckles are what count.
    expect(judgeContact(withHands, defender, punch).landed).toBe(true);
  });
});

describe('an open hand is not a punch', () => {
  /** A hand thrown forward hard enough that only openness can reject it. */
  function throwIt(fighter: Fighter): void {
    fighter.pose.wrL.z = fighter.pose.chest.z + 0.4;
    fighter.speed.wrL = 2;
    fighter.forwardSpeed.wrL = 2;
  }

  it('counts a closed fist', () => {
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09], 0.1), right: null });
    throwIt(fighter);
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
  });

  it('rejects a flat, spread hand', () => {
    // A reach or a slap, not a punch.
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09], 0.95), right: null });
    throwIt(fighter);
    expect(detectGestureStrikes(fighter)).toHaveLength(0);
  });

  it('is generous about a loose fist', () => {
    // Hand tracking is the least reliable part of the pipeline, so the gate
    // has to be forgiving: rejecting real punches is far worse than letting a
    // sloppy one through.
    const fighter = fresh();
    settle(fighter, { left: fist([0, 0, 0.09], MAX_PUNCH_OPENNESS - 0.05), right: null });
    throwIt(fighter);
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
  });

  it('counts the punch when there is no hand data at all', () => {
    // The pose-only tracker supplies none, and shared-screen play depends on
    // it, so an absent hand must never mean a rejected punch.
    const fighter = fresh();
    settle(fighter);
    throwIt(fighter);
    expect(fighter.isFlatHand('wrL')).toBe(false);
    expect(detectGestureStrikes(fighter)).toHaveLength(1);
  });
});
