import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { TASKS_BASE, TASKS_VERSION } from '@adapters/pose/camera.ts';

/**
 * The runtime bundle must be the version the code was written against.
 *
 * This is a guard on a bug that already happened once and was invisible: the
 * adapters are typed against the installed `@mediapipe/tasks-vision`, but at
 * runtime they load the bundle from a CDN by version string. When the two
 * drifted, `HolisticLandmarker` was present in the types and a stub at
 * runtime — so it compiled, passed review, and tracking simply stopped
 * working with nothing to point at.
 */
describe('the tracking bundle version', () => {
  const installed = (
    JSON.parse(readFileSync('package.json', 'utf8')) as {
      dependencies: Record<string, string>;
    }
  ).dependencies['@mediapipe/tasks-vision'];

  it('matches the installed dependency', () => {
    expect(installed).toBeDefined();
    // Strip the range marker: `^1.0.1` is satisfied by the 1.0.1 bundle.
    const wanted = (installed ?? '').replace(/^[\^~]/, '');
    expect(TASKS_VERSION).toBe(`@mediapipe/tasks-vision@${wanted}`);
  });

  it('is pinned exactly, not floating', () => {
    // `@latest` would reintroduce exactly the drift this guards against.
    expect(TASKS_VERSION).toMatch(/@\d+\.\d+\.\d+$/);
    expect(TASKS_VERSION).not.toContain('latest');
  });

  it('builds a CDN base from it', () => {
    expect(TASKS_BASE).toContain(TASKS_VERSION);
    expect(TASKS_BASE.startsWith('https://')).toBe(true);
  });
});
