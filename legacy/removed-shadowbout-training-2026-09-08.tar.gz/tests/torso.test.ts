import { describe, expect, it } from 'vitest';
import type { BodyReading } from '@domain/fighting/body-reading.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { LANDMARK, type Triple } from '@domain/fighting/skeleton.ts';

/**
 * The torso stays a torso.
 *
 * The spine is driven by the direction from the hips to the chest, and both
 * ends of that line come from landmarks whose depth a single camera can only
 * guess at. Lean toward the camera and the model puts the shoulders well
 * forward of the hips — so the fighter bent at the waist, and at the extreme
 * folded in half with its head by the floor. It read as cloth, not a person.
 */

/**
 * A body leaning forward by `lean` metres — the shoulders displaced toward
 * the opponent relative to the hips, which is what the model reports when
 * somebody leans into the camera.
 */
function leaningReading(lean: number): BodyReading {
  // Vision-model convention: y grows down, z grows away from the camera.
  const shoulderZ = -lean;
  const points: Readonly<Record<number, Triple>> = {
    [LANDMARK.nose]: [0, -0.72, shoulderZ - 0.04],
    [LANDMARK.shoulderL]: [0.19, -0.46, shoulderZ],
    [LANDMARK.shoulderR]: [-0.19, -0.46, shoulderZ],
    [LANDMARK.elbowL]: [0.27, -0.24, shoulderZ - 0.12],
    [LANDMARK.elbowR]: [-0.27, -0.24, shoulderZ - 0.12],
    [LANDMARK.wristL]: [0.15, -0.42, shoulderZ - 0.24],
    [LANDMARK.wristR]: [-0.15, -0.42, shoulderZ - 0.24],
    [LANDMARK.hipL]: [0.11, 0, 0],
    [LANDMARK.hipR]: [-0.11, 0, 0],
    [LANDMARK.kneeL]: [0.15, 0.42, -0.06],
    [LANDMARK.kneeR]: [-0.16, 0.42, 0.02],
    [LANDMARK.ankleL]: [0.16, 0.84, -0.1],
    [LANDMARK.ankleR]: [-0.17, 0.84, 0.06],
  };
  const world: Triple[] = [];
  const normalised: Triple[] = [];
  for (let i = 0; i < 33; i++) {
    world.push(points[i] ?? ([0, 0, 0] as Triple));
    normalised.push([0.5, 0.5, 0]);
  }
  return { world, normalised };
}

function settle(fighter: Fighter, lean: number, frames = 90): void {
  const frame = leaningReading(lean);
  for (let i = 0; i < frames; i++) fighter.applyBodyReading(frame);
}

const fresh = (): Fighter => new Fighter({ name: 'A', side: -1 });

/** How far the torso is off vertical, in radians. */
function tiltOf(fighter: Fighter): number {
  const neck = fighter.pose.neck;
  const length = Math.hypot(neck.x, neck.y, neck.z);
  return Math.acos(neck.y / length);
}

describe('the torso under a bad depth reading', () => {
  it('stands upright when the player does', () => {
    const fighter = fresh();
    settle(fighter, 0);
    expect(tiltOf(fighter)).toBeLessThan(0.12);
  });

  it('allows a real lean', () => {
    const fighter = fresh();
    settle(fighter, 0.12);
    // Still leaning — ducking and weaving must survive.
    expect(tiltOf(fighter)).toBeGreaterThan(0.08);
  });

  it('refuses to fold over, however far the reading leans', () => {
    // This is the bug: a large reported lean bent the fighter double.
    const fighter = fresh();
    settle(fighter, 1.5);
    expect(tiltOf(fighter)).toBeLessThan(0.45);
  });

  it('keeps the spine straight rather than kinking it', () => {
    // The chest has to sit on the hips-to-neck line, or the spine bends in
    // the middle and the model creases.
    const fighter = fresh();
    settle(fighter, 1.5);
    const { chest, neck } = fighter.pose;
    const along = Math.hypot(neck.x, neck.y, neck.z);
    const cross = Math.hypot(
      chest.y * neck.z - chest.z * neck.y,
      chest.z * neck.x - chest.x * neck.z,
      chest.x * neck.y - chest.y * neck.x,
    );
    // A zero cross product means chest and neck are colinear from the hips.
    expect(cross / (along * along)).toBeLessThan(0.05);
  });

  it('keeps the head attached to the neck', () => {
    const fighter = fresh();
    settle(fighter, 1.5);
    const gap = Math.hypot(
      fighter.pose.head.x - fighter.pose.neck.x,
      fighter.pose.head.y - fighter.pose.neck.y,
      fighter.pose.head.z - fighter.pose.neck.z,
    );
    // A head's worth of offset, not flung across the arena.
    expect(gap).toBeLessThan(0.4);
    expect(gap).toBeGreaterThan(0.05);
  });

  it('still leans the way the player leans', () => {
    // Capped, not discarded: the direction of the lean is preserved.
    const forward = fresh();
    settle(forward, 1.5);
    expect(forward.pose.neck.z).toBeGreaterThan(0);

    const back = fresh();
    settle(back, -1.5);
    expect(back.pose.neck.z).toBeLessThan(0);
  });
});
