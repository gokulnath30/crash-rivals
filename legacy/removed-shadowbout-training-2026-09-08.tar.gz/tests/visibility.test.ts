import { describe, expect, it } from 'vitest';
import { MIN_VISIBILITY, type BodyReading } from '@domain/fighting/body-reading.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { LANDMARK, STANCE, type Triple } from '@domain/fighting/skeleton.ts';

/**
 * Following only the landmarks the camera actually saw.
 *
 * A pose model returns all thirty-three landmarks whether or not it can see
 * them. Sit close to the camera, with your legs out of frame, and it will
 * still happily report your ankles — by guessing, often above your hips. The
 * old code trusted that: the legs pointed upward and the foot plant, which
 * derives standing height from the lowest ankle, drove the whole body down
 * through the floor. The result was a fighter lying on its back with its legs
 * in the air.
 */

const UPPER_BODY: Readonly<Record<number, Triple>> = {
  [LANDMARK.nose]: [0, -0.72, 0.04],
  [LANDMARK.shoulderL]: [0.19, -0.46, 0],
  [LANDMARK.shoulderR]: [-0.19, -0.46, 0],
  [LANDMARK.elbowL]: [0.27, -0.24, -0.12],
  [LANDMARK.elbowR]: [-0.27, -0.24, -0.12],
  [LANDMARK.wristL]: [0.15, -0.42, -0.24],
  [LANDMARK.wristR]: [-0.15, -0.42, -0.24],
  [LANDMARK.hipL]: [0.11, 0, 0],
  [LANDMARK.hipR]: [-0.11, 0, 0],
};

/**
 * The legs as a model hallucinates them when they are out of frame: reported,
 * but *above* the hips, which is anatomically impossible standing up.
 */
const HALLUCINATED_LEGS: Readonly<Record<number, Triple>> = {
  [LANDMARK.kneeL]: [0.15, -0.55, -0.06],
  [LANDMARK.kneeR]: [-0.16, -0.55, 0.02],
  [LANDMARK.ankleL]: [0.16, -0.85, -0.1],
  [LANDMARK.ankleR]: [-0.17, -0.85, 0.06],
};

const LEG_LANDMARKS: readonly number[] = [
  LANDMARK.kneeL,
  LANDMARK.kneeR,
  LANDMARK.ankleL,
  LANDMARK.ankleR,
];

/** @param legsSeen the confidence the model reports for the leg landmarks. */
function reading(legsSeen: number): BodyReading {
  const world: Triple[] = [];
  const normalised: Triple[] = [];
  const visibility: number[] = [];
  for (let i = 0; i < 33; i++) {
    world.push(UPPER_BODY[i] ?? HALLUCINATED_LEGS[i] ?? ([0, 0, 0] as Triple));
    normalised.push([0.5, 0.5, 0]);
    visibility.push(LEG_LANDMARKS.includes(i) ? legsSeen : 1);
  }
  return { world, normalised, visibility };
}

function settle(fighter: Fighter, legsSeen: number, frames = 90): void {
  const frame = reading(legsSeen);
  for (let i = 0; i < frames; i++) fighter.applyBodyReading(frame);
}

const fresh = (): Fighter => new Fighter({ name: 'A', side: -1 });

describe('landmarks the camera could not see', () => {
  it('keeps the fighter standing when the legs are out of frame', () => {
    // The bug: this put the body on the floor.
    const fighter = fresh();
    settle(fighter, 0.05);
    expect(fighter.position.y).toBeGreaterThan(0.5);
  });

  it('holds unseen legs in the fighting stance', () => {
    const fighter = fresh();
    settle(fighter, 0.05);
    // Rather than following the hallucination, which had the ankle up at -0.85
    // in a space where the stance puts it near -0.84 *below* the hips.
    expect(fighter.pose.anL.y).toBeCloseTo(STANCE.anL[1], 1);
    expect(fighter.pose.knR.y).toBeCloseTo(STANCE.knR[1], 1);
  });

  it('still follows the arms, which the camera can see', () => {
    // Rejecting a limb must be per-joint, not all-or-nothing.
    const fighter = fresh();
    settle(fighter, 0.05);
    // The reading puts the wrists forward of the stance; that must come through.
    expect(fighter.pose.wrL.y).toBeCloseTo(0.42, 1);
  });

  it('follows the legs once the camera can see them', () => {
    const fighter = fresh();
    settle(fighter, 1);
    // Now the reading is trusted, so the pose leaves the stance behind.
    expect(fighter.pose.anL.y).toBeGreaterThan(STANCE.anL[1] + 0.1);
  });

  it('treats a score right at the threshold as seen', () => {
    const fighter = fresh();
    settle(fighter, MIN_VISIBILITY);
    expect(fighter.pose.anL.y).toBeGreaterThan(STANCE.anL[1] + 0.1);
  });

  it('trusts everything when the tracker reports no scores', () => {
    // Older trackers send none, and shared-screen play depends on one of them.
    const fighter = fresh();
    const { world, normalised } = reading(1);
    const frame: BodyReading = { world, normalised };
    for (let i = 0; i < 90; i++) fighter.applyBodyReading(frame);
    expect(fighter.pose.anL.y).toBeGreaterThan(STANCE.anL[1] + 0.1);
  });

  it('never drives the hips through the floor, however wild the reading', () => {
    // The clamp is the backstop: even a trusted but absurd ankle cannot post
    // the fighter underground.
    const fighter = fresh();
    const world: Triple[] = [];
    const normalised: Triple[] = [];
    for (let i = 0; i < 33; i++) {
      world.push(UPPER_BODY[i] ?? ([0, 3, 0] as Triple));
      normalised.push([0.5, 0.5, 0]);
    }
    const frame: BodyReading = { world, normalised };
    for (let i = 0; i < 120; i++) fighter.applyBodyReading(frame);
    expect(fighter.position.y).toBeGreaterThan(0.5);
    expect(fighter.position.y).toBeLessThan(1.2);
  });
});
