// @vitest-environment jsdom
import { beforeEach, describe, expect, it } from 'vitest';
import {
  CHARACTERS,
  DEFAULT_CHARACTER,
  TRAINING_CHARACTER,
  findCharacter,
  readSavedCharacter,
  saveCharacter,
} from '@games/shadowbout/characters.ts';

/**
 * The character roster.
 *
 * A model is only ever a skin: reach, damage and hit detection all come from
 * the domain skeleton, so nothing here may look like a stat.
 */
describe('the character roster', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('offers at least two fighters to choose between', () => {
    expect(CHARACTERS.length).toBeGreaterThanOrEqual(2);
  });

  it('gives every character a unique id', () => {
    const ids = CHARACTERS.map((character) => character.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('points every character at a model file', () => {
    for (const character of CHARACTERS) {
      expect(character.model).toMatch(/\.glb$/);
      // Relative, so the app still works under a project subpath.
      expect(character.model.startsWith('/')).toBe(false);
    }
  });

  it('carries nothing that could affect the fight', () => {
    // If a stat ever appears on a character, this is where it gets caught:
    // picking a fighter must be a cosmetic choice.
    const allowed = new Set(['id', 'name', 'blurb', 'model', 'tint', 'accent']);
    for (const character of CHARACTERS) {
      for (const key of Object.keys(character)) expect(allowed).toContain(key);
    }
  });

  it('opens a fight on the light export, not a 13 MB one', () => {
    // A fight is viewed from across the arena, where the extra detail does
    // not read but the download still costs.
    expect(findCharacter(DEFAULT_CHARACTER).model).toBe('characters/fighter-a.glb');
  });

  it('gives the training space a character with a real face', () => {
    // That room exists to look closely, so it must not follow the fight's
    // lighter default.
    expect(TRAINING_CHARACTER).not.toBe(DEFAULT_CHARACTER);
    expect(findCharacter(TRAINING_CHARACTER).model).toBe('characters/trainer-a.glb');
  });

  it('resolves the detailed exports the training space asks for by name', () => {
    // These ids are referenced as string literals by the training space's
    // reference-clip table. A typo there would fall back to the default and
    // silently play the wrong animation, so pin them.
    for (const id of ['ranger', 'ranger-alt']) {
      expect(findCharacter(id).id).toBe(id);
    }
  });

  it('points the two detailed exports at different files', () => {
    // They are the same avatar carrying different baked actions; if both rows
    // pointed at one file, "Reference 2" would replay "Reference 1".
    const a = findCharacter('ranger');
    const b = findCharacter('ranger-alt');
    expect(a.model).not.toBe(b.model);
  });

  describe('resolving a choice', () => {
    it('finds a character by id', () => {
      expect(findCharacter('shade').id).toBe('shade');
    });

    it('falls back to the default for anything unknown', () => {
      // Comes straight off the wire from the other player, so it is input.
      expect(findCharacter('not-a-character').id).toBe(DEFAULT_CHARACTER);
      expect(findCharacter(null).id).toBe(DEFAULT_CHARACTER);
      expect(findCharacter('').id).toBe(DEFAULT_CHARACTER);
    });
  });

  describe('remembering the pick', () => {
    it('defaults before anything has been chosen', () => {
      expect(readSavedCharacter()).toBe(DEFAULT_CHARACTER);
    });

    it('reads back what was saved', () => {
      saveCharacter('shade');
      expect(readSavedCharacter()).toBe('shade');
    });

    it('ignores a stored value that is no longer a character', () => {
      // A roster change must not leave someone stuck on a missing model.
      localStorage.setItem('shadowbout.character.v2', 'retired-fighter');
      expect(readSavedCharacter()).toBe(DEFAULT_CHARACTER);
    });

    it('does not inherit a pick made under the previous key', () => {
      // The key was versioned precisely so changing the opening character
      // takes effect for someone who had already been handed the old one.
      localStorage.setItem('shadowbout.character', 'ranger');
      expect(readSavedCharacter()).toBe(DEFAULT_CHARACTER);
    });
  });
});
