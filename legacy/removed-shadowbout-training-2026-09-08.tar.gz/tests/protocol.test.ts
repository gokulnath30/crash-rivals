import { describe, expect, it } from 'vitest';
import { JOINTS, type Triple } from '@domain/fighting/skeleton.ts';
import {
  decodeMessage,
  decodePoseFrame,
  encodeMessage,
  encodePoseFrame,
  isNewer,
  POSE_FRAME_BYTES,
  type NetMessage,
  type PoseFrameMessage,
} from '@games/shadowbout/netcode/protocol.ts';

const joints = (): Triple[] =>
  JOINTS.map((_, index) => [index * 0.01, 0.5 - index * 0.02, -0.3 + index * 0.03] as Triple);

const frame = (overrides: Partial<PoseFrameMessage> = {}): PoseFrameMessage => ({
  sequence: 42,
  joints: joints(),
  strafe: -0.31,
  standingY: 0.93,
  facing: 0.42,
  knuckles: [
    [0.02, -0.01, 0.08],
    [-0.02, -0.01, 0.08],
  ],
  blocking: true,
  down: false,
  ...overrides,
});

describe('pose frames', () => {
  it('fits in the advertised number of bytes', () => {
    expect(encodePoseFrame(frame()).byteLength).toBe(POSE_FRAME_BYTES);
    // Sixteen joints plus a header: small enough to send 24 times a second
    // without thinking about it.
    expect(POSE_FRAME_BYTES).toBeLessThan(128);
  });

  it('round-trips every field', () => {
    const decoded = decodePoseFrame(encodePoseFrame(frame()));
    expect(decoded).not.toBeNull();
    expect(decoded?.sequence).toBe(42);
    expect(decoded?.blocking).toBe(true);
    expect(decoded?.down).toBe(false);
    expect(decoded?.joints).toHaveLength(JOINTS.length);
  });

  it('carries where the fists are, not just the wrists', () => {
    // The host judges every hit, so it has to know where the guest's
    // knuckles are — a wrist is most of a hand short of the contact point.
    const decoded = decodePoseFrame(encodePoseFrame(frame()));
    expect(decoded?.knuckles[0]?.[2]).toBeCloseTo(0.08, 3);
    expect(decoded?.knuckles[1]?.[0]).toBeCloseTo(-0.02, 3);
  });

  it('carries which way the player has turned', () => {
    // Without this the opponent's body faces forward on your screen however
    // far they have actually turned, and their strikes land from nowhere.
    const turned = decodePoseFrame(encodePoseFrame(frame({ facing: -1.85 })));
    expect(turned?.facing).toBeCloseTo(-1.85, 3);
  });

  it('keeps positions accurate to well under a millimetre', () => {
    const original = frame();
    const decoded = decodePoseFrame(encodePoseFrame(original));
    const first = original.joints[0];
    const back = decoded?.joints[0];
    expect(first && back).toBeTruthy();
    if (!first || !back) return;
    expect(Math.abs(back[0] - first[0])).toBeLessThan(0.001);
    expect(Math.abs(back[1] - first[1])).toBeLessThan(0.001);
    expect(Math.abs(back[2] - first[2])).toBeLessThan(0.001);
  });

  it('survives a coordinate far outside the expected range', () => {
    // A tracking glitch can produce a wild number; it must clamp, not wrap
    // around into a fighter standing behind the camera.
    const wild = frame({ joints: JOINTS.map(() => [99, -99, 99] as Triple) });
    const decoded = decodePoseFrame(encodePoseFrame(wild));
    const joint = decoded?.joints[0];
    expect(joint).toBeTruthy();
    if (!joint) return;
    expect(joint[0]).toBeGreaterThan(0);
    expect(joint[1]).toBeLessThan(0);
  });

  it('rejects a buffer of the wrong size', () => {
    expect(decodePoseFrame(new ArrayBuffer(8))).toBeNull();
  });

  it('rejects a buffer that is the right size but not ours', () => {
    const bogus = new ArrayBuffer(POSE_FRAME_BYTES);
    new DataView(bogus).setUint8(0, 0x00);
    expect(decodePoseFrame(bogus)).toBeNull();
  });
});

describe('sequence numbers', () => {
  it('recognises a later frame', () => {
    expect(isNewer(11, 10)).toBe(true);
    expect(isNewer(10, 11)).toBe(false);
  });

  it('handles the wrap at 65536', () => {
    // Without wrap-aware comparison the opponent would freeze for a couple of
    // seconds every 45 minutes.
    expect(isNewer(2, 65534)).toBe(true);
    expect(isNewer(65534, 2)).toBe(false);
  });
});

describe('reliable messages', () => {
  const roundTrip = (message: NetMessage): NetMessage | null =>
    decodeMessage(encodeMessage(message));

  it('round-trips a state snapshot', () => {
    const message: NetMessage = {
      t: 'state',
      hp: [80, 55],
      wins: [1, 0],
      round: 2,
      timeLeft: 31.5,
      phase: 'fighting',
      down: [false, false],
    };
    expect(roundTrip(message)).toEqual(message);
  });

  it('round-trips a round result', () => {
    const message: NetMessage = { t: 'round', winner: 1, wins: [0, 1], round: 1, matchOver: false };
    expect(roundTrip(message)).toEqual(message);
  });

  it('round-trips a hit', () => {
    const message: NetMessage = {
      t: 'fx',
      knockout: null,
      hits: [
        {
          attacker: 0,
          defender: 1,
          damage: 12,
          blocked: false,
          heavy: true,
          zone: 'head',
          contact: [0.1, 1.4, 0.5],
          label: 'jab',
        },
      ],
    };
    expect(roundTrip(message)).toEqual(message);
  });

  describe('rejecting rubbish', () => {
    it('returns null for text that is not JSON', () => {
      expect(decodeMessage('not json at all')).toBeNull();
    });

    it('returns null for JSON that is not a message', () => {
      expect(decodeMessage('42')).toBeNull();
      expect(decodeMessage('{"t":"nonsense"}')).toBeNull();
    });

    it('returns null for a snapshot with fields missing', () => {
      expect(decodeMessage('{"t":"state","hp":[1]}')).toBeNull();
    });

    it('returns null for a snapshot with a bogus phase', () => {
      const bad = '{"t":"state","hp":[1,2],"wins":[0,0],"round":1,"timeLeft":5,"phase":"cheating","down":[false,false]}';
      expect(decodeMessage(bad)).toBeNull();
    });

    it('clamps a hit claiming absurd damage', () => {
      // The peer is another browser. Its numbers are input, not truth.
      const hostile =
        '{"t":"fx","knockout":null,"hits":[{"attacker":0,"defender":1,"damage":99999,"zone":"head","contact":[0,0,0]}]}';
      const decoded = decodeMessage(hostile);
      expect(decoded?.t).toBe('fx');
      if (decoded?.t !== 'fx') return;
      expect(decoded.hits[0]?.damage).toBeLessThanOrEqual(40);
    });

    it('drops malformed hits but keeps the good ones', () => {
      const mixed =
        '{"t":"fx","knockout":null,"hits":[{"nope":true},{"attacker":1,"defender":0,"damage":5,"zone":"body","contact":[0,1,0]}]}';
      const decoded = decodeMessage(mixed);
      if (decoded?.t !== 'fx') throw new Error('expected an fx message');
      expect(decoded.hits).toHaveLength(1);
      expect(decoded.hits[0]?.zone).toBe('body');
    });

    it('rejects an out-of-range fighter index', () => {
      const bad =
        '{"t":"fx","knockout":7,"hits":[{"attacker":5,"defender":1,"damage":5,"zone":"body","contact":[0,1,0]}]}';
      const decoded = decodeMessage(bad);
      if (decoded?.t !== 'fx') throw new Error('expected an fx message');
      expect(decoded.hits).toHaveLength(0);
      expect(decoded.knockout).toBeNull();
    });

    it('truncates an over-long name rather than trusting it', () => {
      const decoded = decodeMessage(JSON.stringify({ t: 'hello', name: 'x'.repeat(500) }));
      if (decoded?.t !== 'hello') throw new Error('expected a hello message');
      expect(decoded.name.length).toBeLessThanOrEqual(40);
    });
  });
});
