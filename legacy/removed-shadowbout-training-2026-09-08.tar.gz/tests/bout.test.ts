import { describe, expect, it } from 'vitest';
import { Bout } from '@domain/fighting/bout.ts';
import type { FightEvent } from '@domain/fighting/events.ts';
import { RULES } from '@domain/fighting/moves.ts';

const FULL: readonly [number, number] = [RULES.maxHp, RULES.maxHp];

/** Runs the clock forward in small steps, collecting everything raised. */
function advance(bout: Bout, seconds: number, hp: readonly [number, number] = FULL): FightEvent[] {
  const events: FightEvent[] = [];
  const step = 1 / 60;
  for (let elapsed = 0; elapsed < seconds; elapsed += step) {
    events.push(...bout.tick(step, hp));
  }
  return events;
}

const kinds = (events: readonly FightEvent[]): string[] => events.map((event) => event.kind);

describe('a bout', () => {
  it('starts a round on the clock and announces it', () => {
    const bout = new Bout();
    const events = bout.beginRound();
    expect(bout.phase).toBe('fighting');
    expect(bout.timeLeft).toBe(RULES.roundSeconds);
    expect(kinds(events)).toEqual(['round-start', 'announce']);
  });

  it('shouts "Fight" a beat after the round starts', () => {
    const bout = new Bout();
    bout.beginRound();
    const events = advance(bout, 1.3);
    const shout = events.find((event) => event.kind === 'announce');
    expect(shout?.kind === 'announce' && shout.text).toBe('Fight');
  });

  it('does not shout "Fight" if the round is already over', () => {
    // A knockout inside the first second used to be followed by an eager
    // "Fight" once the pending timer fired.
    const bout = new Bout();
    bout.beginRound();
    bout.recordKnockout(1);
    const events = advance(bout, 1.3);
    const announcements = events
      .filter((event): event is Extract<FightEvent, { kind: 'announce' }> => event.kind === 'announce')
      .map((event) => event.text);
    expect(announcements).not.toContain('Fight');
  });

  it('awards the round to whoever did not get knocked out', () => {
    const bout = new Bout();
    bout.beginRound();
    bout.recordKnockout(1);
    expect(bout.wins).toEqual([1, 0]);
    expect(bout.phase).toBe('settling');
  });

  it('closes the round after the knockout has been announced', () => {
    const bout = new Bout();
    bout.beginRound();
    bout.recordKnockout(1);
    const events = advance(bout, 1.6);
    const end = events.find((event) => event.kind === 'round-end');
    expect(end?.kind === 'round-end' && end.winner).toBe(0);
    expect(end?.kind === 'round-end' && end.matchOver).toBe(false);
    expect(bout.phase).toBe('round-over');
  });

  it('ignores a knockout that arrives when the round is not running', () => {
    const bout = new Bout();
    expect(bout.recordKnockout(1)).toHaveLength(0);
    expect(bout.wins).toEqual([0, 0]);
  });

  it('ends the match when someone takes enough rounds', () => {
    const bout = new Bout();
    for (let round = 0; round < RULES.roundsToWin; round++) {
      bout.beginRound();
      bout.recordKnockout(1);
      advance(bout, 1.6);
      if (round + 1 < RULES.roundsToWin) bout.advance();
    }
    expect(bout.decided).toBe(true);
    expect(bout.winner).toBe(0);
    expect(bout.phase).toBe('match-over');
  });

  describe('when the clock runs out', () => {
    it('gives the round to whoever has more health left', () => {
      const bout = new Bout();
      bout.beginRound();
      const events = advance(bout, RULES.roundSeconds + 0.2, [40, 70]);
      const timeUp = events.find((event) => event.kind === 'time-up');
      expect(timeUp?.kind === 'time-up' && timeUp.winner).toBe(1);
      expect(bout.wins).toEqual([0, 1]);
    });

    it('replays the round when health is level', () => {
      const bout = new Bout();
      bout.beginRound();
      const events = advance(bout, RULES.roundSeconds + 0.2, [50, 50]);
      const timeUp = events.find((event) => event.kind === 'time-up');
      expect(timeUp?.kind === 'time-up' && timeUp.winner).toBeNull();
      expect(bout.wins).toEqual([0, 0]);

      // And it actually starts again rather than sitting there.
      const after = advance(bout, 1.6, [50, 50]);
      expect(kinds(after)).toContain('round-start');
    });

    it('does not run the clock past zero', () => {
      const bout = new Bout();
      bout.beginRound();
      advance(bout, RULES.roundSeconds + 5, [40, 70]);
      expect(bout.timeLeft).toBe(0);
    });
  });

  describe('hitstop', () => {
    it('slows the simulation after an impact, then lets it go', () => {
      const bout = new Bout();
      bout.beginRound();
      bout.registerImpact(false, true);
      // Slowed while the freeze lasts...
      expect(bout.scaleFrameTime(0.016)).toBeLessThan(0.016);
      // ...and back to real time once it is spent.
      bout.scaleFrameTime(1);
      expect(bout.scaleFrameTime(0.016)).toBe(0.016);
    });

    it('freezes longer on a heavy hit than a blocked one', () => {
      const heavy = new Bout();
      heavy.registerImpact(false, true);
      const blocked = new Bout();
      blocked.registerImpact(true, false);
      expect(heavy.hitstop).toBeGreaterThan(blocked.hitstop);
    });
  });

  describe('advancing', () => {
    it('moves to the next round after a round win', () => {
      const bout = new Bout();
      bout.beginRound();
      bout.recordKnockout(1);
      advance(bout, 1.6);
      bout.advance();
      expect(bout.round).toBe(2);
      expect(bout.phase).toBe('fighting');
    });

    it('wipes the scoreboard for a rematch', () => {
      const bout = new Bout();
      bout.beginRound();
      bout.recordKnockout(1);
      advance(bout, 1.6);
      bout.advance();
      bout.recordKnockout(1);
      advance(bout, 1.6);
      expect(bout.phase).toBe('match-over');

      bout.advance();
      expect(bout.round).toBe(1);
      expect(bout.wins).toEqual([0, 0]);
      expect(bout.phase).toBe('fighting');
    });
  });
});
