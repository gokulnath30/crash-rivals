import * as THREE from 'three';
import { Fighter } from '@domain/fighting/fighter.ts';
import { detectGestureStrikes } from '@domain/fighting/gestures.ts';
import { RULES } from '@domain/fighting/moves.ts';
import { OVERLAY_LINKS } from '@domain/fighting/skeleton.ts';
import type { GameContext, GameHandle } from '@app/ports/game-runtime.port.ts';
import type { PoseSourcePort, PoseStatus } from '@app/ports/pose-source.port.ts';
import { TRAINING_CHARACTER, findCharacter } from '../shadowbout/characters.ts';
import { CharacterModels } from '../shadowbout/render/character-model.ts';
import { GltfFighterRig } from '../shadowbout/render/gltf-fighter-rig.ts';
import type { FighterView } from '../shadowbout/render/fighter-view.ts';
import { TrainingHud, type SignalName, type TrainingMode } from './training-hud.ts';
import { TrainingStage, type ViewPreset } from './training-stage.ts';
import './training.css';

/** A tab left in the background resumes with a delta of several seconds. */
const MAX_FRAME = 0.05;

/**
 * The training space: one fighter, no opponent, nothing to win.
 *
 * It exists to answer "why did that punch not register?", so it runs the same
 * `detectGestureStrikes` the fight runs and puts every number it reads on
 * screen. A signal lighting up here is a strike that would have landed in a
 * match; a signal sitting flat is the reason one did not.
 *
 * Nothing in here scores, damages or ends. There is no `Bout`, no health and
 * no netcode — deliberately, because the moment a training space keeps score
 * it stops being one.
 */
export class TrainingSession implements GameHandle {
  private readonly fighter = new Fighter({ name: 'You', side: -1 });
  private readonly stage: TrainingStage;
  private readonly hud: TrainingHud;
  private readonly models: CharacterModels;

  private view: FighterView | null = null;
  private mixer: THREE.AnimationMixer | null = null;
  private mode: TrainingMode = 'live';
  private tracking = false;
  /** How much expression the face tracker is reporting, for the meter. */
  private faceEnergy = 0;
  private lastFrameAt: number;
  private frameHandle: number | null = null;
  private stopped = false;
  private readonly detach: (() => void)[] = [];

  constructor(
    private readonly context: GameContext,
    private readonly pose: PoseSourcePort,
  ) {
    this.models = new CharacterModels(context.logger);
    this.models.watchProgress((progress) => {
      if (progress.done) {
        this.hud.setStatus('');
        return;
      }
      const done =
        progress.fraction !== null
          ? `${Math.round(progress.fraction * 100)}%`
          : `${(progress.loadedBytes / 1048576).toFixed(1)} MB`;
      this.hud.setStatus(`Loading ${progress.name}… ${done}`);
    });
    this.hud = new TrainingHud(context.mount, {
      onStartCamera: () => {
        void this.startCamera();
      },
      onView: (preset: ViewPreset) => {
        this.stage.setView(preset);
        this.hud.setView(preset);
      },
      onMode: (mode) => {
        void this.setMode(mode);
      },
      onExit: context.exit,
    });
    this.stage = new TrainingStage(this.hud.canvas);

    this.detach.push(
      this.pose.onStatusChange((status) => {
        this.hud.setCameraNote(noteFor(status));
        if (status.kind === 'starting') this.hud.setStatus(status.message);
      }),
    );

    this.lastFrameAt = context.clock.elapsed();
  }

  begin(): void {
    // The character loads immediately, so there is something to look at and
    // orbit before the camera is ever switched on.
    void this.dress('live');
    this.loop();
  }

  stop(): void {
    if (this.stopped) return;
    this.stopped = true;
    if (this.frameHandle !== null) cancelAnimationFrame(this.frameHandle);
    for (const remove of this.detach.splice(0)) remove();
    this.pose.stop();
    this.view?.dispose();
    this.models.dispose();
    this.stage.dispose();
    this.hud.dispose();
  }

  // ------------------------------------------------------------------ setup

  private async startCamera(): Promise<void> {
    this.hud.setStatus('Asking for the camera…');
    const started = await this.pose.start(1);
    if (this.stopped) return;

    if (!started.ok) {
      this.hud.setStatus(started.error.message);
      return;
    }
    const video = this.pose.videoElement();
    if (video) this.hud.attachCamera(video);
    this.tracking = true;
    this.hud.setStatus('');
    this.hud.hideGate();
    void this.setMode('live');
  }

  private async setMode(mode: TrainingMode): Promise<void> {
    this.mode = mode;
    this.hud.setMode(mode);
    await this.dress(mode);
  }

  /**
   * Loads the model for a mode and puts it on the stage.
   *
   * The reference modes are separate exports, each carrying one baked clip, so
   * switching to one is a download. `CharacterModels` caches, so switching
   * back is instant.
   */
  private async dress(mode: TrainingMode): Promise<void> {
    // Live mode uses the detailed export rather than whatever the fight was
    // last set to: this room is for looking at a face closely, and the light
    // model does not have one worth looking at.
    const character = findCharacter(mode === 'live' ? TRAINING_CHARACTER : REFERENCE[mode]);
    const loaded = await this.models.instance(character);
    if (this.stopped || this.mode !== mode) return;

    if (!loaded.ok) {
      this.hud.setStatus(loaded.error.message);
      return;
    }

    this.view?.dispose();
    this.mixer = null;

    // No rim light: an emissive edge flattens exactly the shading that makes
    // a face read as skin, and here the face is the point.
    this.view = new GltfFighterRig(this.stage.scene, this.fighter, loaded.value.scene, {
      tint: character.tint,
      rim: null,
    });

    if (mode !== 'live') {
      const clip = loaded.value.clips[0];
      if (clip) {
        // The mixer drives the same bones the retarget would, so only one of
        // the two may be running at a time.
        this.mixer = new THREE.AnimationMixer(loaded.value.scene);
        const action = this.mixer.clipAction(clip);
        action.setLoop(THREE.LoopRepeat, Infinity);
        action.play();
        this.hud.note(`Playing ${clip.name || 'reference'} · ${clip.duration.toFixed(1)}s`);
      } else {
        this.hud.setStatus('That export carries no animation to play.');
      }
    }
  }

  // ------------------------------------------------------------------- loop

  private loop(): void {
    const step = (): void => {
      if (this.stopped) return;
      this.frameHandle = requestAnimationFrame(step);
      this.frame();
    };
    this.frameHandle = requestAnimationFrame(step);
  }

  private frame(): void {
    const now = this.context.clock.elapsed();
    const dt = Math.min(MAX_FRAME, Math.max(0, (now - this.lastFrameAt) / 1000));
    this.lastFrameAt = now;

    if (this.mode === 'live') {
      this.readCamera();
      // A body that is not being tracked breathes on the spot rather than
      // standing frozen in a T-pose.
      if (!this.fighter.tracked) this.fighter.blendAnimation(dt, now);
      this.fighter.integrate(dt);
      this.report();
      this.view?.sync(dt);
    } else {
      // The clip owns the bones in reference mode, so the retarget stands down.
      this.mixer?.update(dt);
    }

    this.stage.render(dt);
  }

  private readCamera(): void {
    if (!this.tracking) return;
    const frame = this.pose.read();
    if (!frame) return;

    const body = frame.bodies[0];
    if (!body) {
      this.hud.clearOverlay();
      return;
    }
    this.fighter.applyBodyReading(body);
    // The face is presentation, not simulation, so it goes straight to the
    // view rather than through the fighter.
    this.view?.setFace?.(body.face ?? null);
    this.faceEnergy = expressionEnergy(body.face);
    this.hud.drawOverlay(frame.forOverlay, OVERLAY_LINKS);
  }

  /**
   * Puts the numbers the detector is working from on screen, then runs the
   * detector itself and names whatever it found.
   */
  private report(): void {
    const { fighter } = this;
    const chestZ = fighter.pose.chest.z;
    const hipY = fighter.pose.pelvis.y;

    // Hands: how far past the chest, and how fast — the two things a punch is.
    for (const [signal, joint] of HANDS) {
      const extension = fighter.pose[joint].z - chestZ;
      const pace = Math.max(fighter.speed[joint], fighter.forwardSpeed[joint]);
      // Scaled against the thresholds the detector uses, so 1.0 means "this
      // is enough".
      const reading = Math.min(extension / 0.3, 1) * Math.min(pace / 1.1, 1);
      this.hud.setSignal(signal, Math.max(0, reading), extension > 0.3 && pace > 1.1);
    }

    for (const [signal, ankle, knee] of LEGS) {
      const lift = (fighter.pose[knee].y - hipY + 0.42) / 0.42;
      const extension = fighter.pose[ankle].z - chestZ;
      const pace = Math.max(fighter.speed[ankle], fighter.forwardSpeed[ankle]);
      const reading = Math.min(lift, 1) * Math.min(Math.max(0, extension) / 0.2, 1) * Math.min(pace / 1.35, 1);
      this.hud.setSignal(signal, Math.max(0, reading), fighter.pose[knee].y - hipY > -0.3 && pace > 1.35);
    }

    // Hands and face, when the holistic tracker is the one running. The
    // meters sit at zero on the pose-only tracker, which is itself the answer
    // to "why is nothing showing here".
    for (const [signal, joint] of FISTS) {
      const openness = fighter.handOpenness[joint];
      this.hud.setSignal(signal, openness ?? 0, openness !== null && !fighter.isFlatHand(joint));
    }
    this.hud.setSignal('face', this.faceEnergy, this.faceEnergy > 0.08);

    this.hud.setSignal('guard', fighter.blocking ? 1 : 0, fighter.blocking);
    this.hud.setSignal(
      'turn',
      Math.abs(fighter.facing) / RULES.turnLimit,
      Math.abs(fighter.facing) > 0.35,
    );

    // The same call the fight makes. If it fires here, it would have landed.
    for (const strike of detectGestureStrikes(fighter)) {
      this.hud.note(`${strike.label} — ${Math.round(strike.damage)} force`);
      this.context.audio.play(strike.heavy ? 'kick' : 'punch-light', { intensity: 0.5 });
    }
  }
}

/** Which export carries which reference clip. */
const REFERENCE: Readonly<Record<Exclude<TrainingMode, 'live'>, string>> = {
  'reference-a': 'ranger',
  'reference-b': 'ranger-alt',
};

const FISTS: readonly (readonly [SignalName, 'wrL' | 'wrR'])[] = [
  ['fistL', 'wrL'],
  ['fistR', 'wrR'],
];

/**
 * A single number for "how much is the face doing", so the panel can show
 * that face tracking is alive without listing fifty-two weights.
 */
function expressionEnergy(face: Readonly<Record<string, number>> | undefined): number {
  if (!face) return 0;
  let strongest = 0;
  for (const weight of Object.values(face)) strongest = Math.max(strongest, weight);
  return strongest;
}

const HANDS: readonly (readonly [SignalName, 'wrL' | 'wrR'])[] = [
  ['punchL', 'wrL'],
  ['punchR', 'wrR'],
];

const LEGS: readonly (readonly [SignalName, 'anL' | 'anR', 'knL' | 'knR'])[] = [
  ['kickL', 'anL', 'knL'],
  ['kickR', 'anR', 'knR'],
];

function noteFor(status: PoseStatus): string {
  switch (status.kind) {
    case 'off':
      return 'camera off';
    case 'starting':
      return status.message;
    case 'tracking':
      return 'tracking you';
    case 'no-body':
      return 'no body in frame — step back';
    case 'failed':
      return status.message;
  }
}
