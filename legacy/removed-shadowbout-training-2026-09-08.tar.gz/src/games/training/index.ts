import { GAME_IDS } from '@adapters/catalog/static-catalog.adapter.ts';
import { ok, type Result } from '@domain/shared/result.ts';
import type { GameContext, GameHandle, GameRuntime } from '@app/ports/game-runtime.port.ts';
import type { PoseSourcePort } from '@app/ports/pose-source.port.ts';
import { TrainingSession } from './session.ts';

/**
 * The training space as the store sees it.
 *
 * A game in the catalogue's sense — something that mounts, runs and stops —
 * but with no opponent, no score and no end. It shares the fighting domain's
 * pose reading and strike detection so that what it shows you is exactly what
 * a match would decide, and shares nothing else.
 */
export function createTrainingSpace(deps: { pose: PoseSourcePort }): GameRuntime {
  return {
    id: GAME_IDS.training,

    async launch(context: GameContext): Promise<Result<GameHandle>> {
      const session = new TrainingSession(context, deps.pose);
      session.begin();
      return ok(session);
    },
  };
}
