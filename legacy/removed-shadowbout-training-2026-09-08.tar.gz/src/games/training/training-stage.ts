import * as THREE from 'three';

/**
 * The studio the training space happens in.
 *
 * Deliberately not the fight arena. The arena is dark, lit from behind with
 * coloured rims, and viewed from far enough away to keep two fighters on
 * screen — every one of which works against seeing a face. This is a bright
 * three-point setup at conversational distance, with tone mapping that keeps
 * skin from clipping to white.
 *
 * The camera orbits on drag and zooms on wheel or pinch, because the whole
 * point of a training space is being able to look at the thing from wherever
 * you want.
 */
export type ViewPreset = 'full' | 'upper' | 'face';

interface Orbit {
  yaw: number;
  pitch: number;
  distance: number;
  /** Height the camera looks at, in metres. */
  target: number;
}

const PRESETS: Readonly<Record<ViewPreset, Orbit>> = {
  full: { yaw: 0.42, pitch: 0.06, distance: 3.3, target: 1.0 },
  upper: { yaw: 0.38, pitch: 0.05, distance: 1.9, target: 1.32 },
  face: { yaw: 0.22, pitch: 0.02, distance: 0.92, target: 1.56 },
};

const MIN_DISTANCE = 0.55;
const MAX_DISTANCE = 6;
const MAX_PITCH = 1.1;

export class TrainingStage {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(38, 1, 0.05, 60);

  private readonly renderer: THREE.WebGLRenderer;
  private readonly orbit: Orbit = { ...PRESETS.full };
  private readonly wanted: Orbit = { ...PRESETS.full };
  private readonly resizeObserver: ResizeObserver;
  private readonly detach: (() => void)[] = [];
  private dragging: number | null = null;
  private lastX = 0;
  private lastY = 0;
  private pinchFrom: number | null = null;

  constructor(private readonly canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    // Skin lit brightly enough to see clips to flat white without this.
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.scene.background = new THREE.Color(0x14121c);
    this.buildStudio();
    this.bindPointer();

    this.resizeObserver = new ResizeObserver(() => {
      this.resize();
    });
    this.resizeObserver.observe(canvas);
    this.resize();
  }

  /** Jumps the camera toward one of the framings. Eased, not snapped. */
  setView(preset: ViewPreset): void {
    Object.assign(this.wanted, PRESETS[preset]);
  }

  render(dt: number): void {
    const ease = Math.min(1, dt * 6);
    this.orbit.yaw += (this.wanted.yaw - this.orbit.yaw) * ease;
    this.orbit.pitch += (this.wanted.pitch - this.orbit.pitch) * ease;
    this.orbit.distance += (this.wanted.distance - this.orbit.distance) * ease;
    this.orbit.target += (this.wanted.target - this.orbit.target) * ease;

    const { yaw, pitch, distance, target } = this.orbit;
    const flat = Math.cos(pitch) * distance;
    this.camera.position.set(
      Math.sin(yaw) * flat,
      target + Math.sin(pitch) * distance,
      Math.cos(yaw) * flat,
    );
    this.camera.lookAt(0, target, 0);
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.resizeObserver.disconnect();
    for (const remove of this.detach.splice(0)) remove();
    this.scene.traverse((object) => {
      const drawable = object as Partial<THREE.Mesh>;
      drawable.geometry?.dispose();
      const material = drawable.material;
      if (!material) return;
      for (const one of Array.isArray(material) ? material : [material]) one.dispose();
    });
    this.renderer.dispose();
  }

  /**
   * A key light high and to the front so the face is modelled rather than
   * flat, a cool fill opposite it to keep the shadow side readable, and a
   * rim behind to lift the silhouette off the background.
   */
  private buildStudio(): void {
    this.scene.add(new THREE.HemisphereLight(0xdfe6ff, 0x1a1726, 0.55));

    const key = new THREE.DirectionalLight(0xfff4e2, 2.1);
    key.position.set(1.6, 2.7, 2.4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.near = 0.5;
    key.shadow.camera.far = 8;
    key.shadow.camera.left = -2;
    key.shadow.camera.right = 2;
    key.shadow.camera.top = 3;
    key.shadow.camera.bottom = -1;
    key.shadow.bias = -0.0012;
    this.scene.add(key);

    const fill = new THREE.DirectionalLight(0xbcd0ff, 0.6);
    fill.position.set(-2.2, 1.4, 1.2);
    this.scene.add(fill);

    const rim = new THREE.DirectionalLight(0xffffff, 1.1);
    rim.position.set(-0.8, 2.2, -2.6);
    this.scene.add(rim);

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(4, 64),
      new THREE.MeshStandardMaterial({ color: 0x1d1a28, roughness: 0.85, metalness: 0.05 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    const grid = new THREE.GridHelper(8, 16, 0x3a3550, 0x24212f);
    grid.position.y = 0.002;
    this.scene.add(grid);

    // A mark where the fighter stands, so you can see how far you have drifted.
    const mark = new THREE.Mesh(
      new THREE.RingGeometry(0.44, 0.47, 48),
      new THREE.MeshBasicMaterial({ color: 0x6f7dff, transparent: true, opacity: 0.5 }),
    );
    mark.rotation.x = -Math.PI / 2;
    mark.position.y = 0.004;
    this.scene.add(mark);
  }

  private bindPointer(): void {
    const down = (event: PointerEvent): void => {
      this.dragging = event.pointerId;
      this.lastX = event.clientX;
      this.lastY = event.clientY;
      this.canvas.setPointerCapture(event.pointerId);
    };
    const move = (event: PointerEvent): void => {
      if (this.dragging !== event.pointerId) return;
      const dx = event.clientX - this.lastX;
      const dy = event.clientY - this.lastY;
      this.lastX = event.clientX;
      this.lastY = event.clientY;
      this.wanted.yaw -= dx * 0.006;
      this.wanted.pitch = clamp(this.wanted.pitch + dy * 0.004, -0.35, MAX_PITCH);
    };
    const up = (event: PointerEvent): void => {
      if (this.dragging !== event.pointerId) return;
      this.dragging = null;
      if (this.canvas.hasPointerCapture(event.pointerId)) {
        this.canvas.releasePointerCapture(event.pointerId);
      }
    };
    const wheel = (event: WheelEvent): void => {
      event.preventDefault();
      this.wanted.distance = clamp(
        this.wanted.distance * (1 + Math.sign(event.deltaY) * 0.12),
        MIN_DISTANCE,
        MAX_DISTANCE,
      );
    };
    const touch = (event: TouchEvent): void => {
      if (event.touches.length !== 2) {
        this.pinchFrom = null;
        return;
      }
      const [a, b] = [event.touches[0], event.touches[1]];
      if (!a || !b) return;
      const spread = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      if (this.pinchFrom !== null && spread > 0) {
        this.wanted.distance = clamp(
          this.wanted.distance * (this.pinchFrom / spread),
          MIN_DISTANCE,
          MAX_DISTANCE,
        );
      }
      this.pinchFrom = spread;
    };

    this.canvas.addEventListener('pointerdown', down);
    this.canvas.addEventListener('pointermove', move);
    this.canvas.addEventListener('pointerup', up);
    this.canvas.addEventListener('pointercancel', up);
    this.canvas.addEventListener('wheel', wheel, { passive: false });
    this.canvas.addEventListener('touchmove', touch, { passive: true });
    this.canvas.addEventListener('touchend', touch, { passive: true });

    this.detach.push(() => {
      this.canvas.removeEventListener('pointerdown', down);
      this.canvas.removeEventListener('pointermove', move);
      this.canvas.removeEventListener('pointerup', up);
      this.canvas.removeEventListener('pointercancel', up);
      this.canvas.removeEventListener('wheel', wheel);
      this.canvas.removeEventListener('touchmove', touch);
      this.canvas.removeEventListener('touchend', touch);
    });
  }

  private resize(): void {
    const width = this.canvas.clientWidth || window.innerWidth;
    const height = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
  }
}

const clamp = (value: number, lo: number, hi: number): number =>
  value < lo ? lo : value > hi ? hi : value;
