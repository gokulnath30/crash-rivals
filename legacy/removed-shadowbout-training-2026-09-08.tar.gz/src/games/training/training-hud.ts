import { clear, el } from '@ui/dom.ts';
import type { ViewPreset } from './training-stage.ts';

/**
 * The instrument panel.
 *
 * A training space is only useful if it shows you what the machine is
 * actually reading, not just the result. Every meter here is fed by the same
 * domain code the fight uses, so what lights up here is exactly what would
 * have landed in a match — which makes this the place to find out why a punch
 * of yours does not register.
 */
export type SignalName =
  | 'punchL'
  | 'punchR'
  | 'kickL'
  | 'kickR'
  | 'guard'
  | 'turn'
  | 'fistL'
  | 'fistR'
  | 'face';

const SIGNAL_LABELS: Readonly<Record<SignalName, string>> = {
  punchL: 'Left hand',
  punchR: 'Right hand',
  kickL: 'Left leg',
  kickR: 'Right leg',
  guard: 'Guard',
  turn: 'Body turn',
  // From the holistic tracker only. A closed fist reads low, a flat hand
  // high, and `face` is simply how much expression is coming through.
  fistL: 'Left fist',
  fistR: 'Right fist',
  face: 'Face',
};

export interface TrainingHudHandlers {
  readonly onStartCamera: () => void;
  readonly onView: (preset: ViewPreset) => void;
  readonly onMode: (mode: TrainingMode) => void;
  readonly onExit: () => void;
}

/**
 * Live mirrors your body; the reference modes play an animation baked into
 * the export, so you can watch the movement before trying it.
 */
export type TrainingMode = 'live' | 'reference-a' | 'reference-b';

const MODE_LABELS: Readonly<Record<TrainingMode, string>> = {
  live: 'Your body',
  'reference-a': 'Reference 1',
  'reference-b': 'Reference 2',
};

export class TrainingHud {
  readonly root: HTMLElement;
  readonly canvas: HTMLCanvasElement;

  private readonly meters = new Map<SignalName, { lamp: HTMLElement; bar: HTMLElement; value: HTMLElement }>();
  private readonly camNote: HTMLElement;
  private readonly camWrap: HTMLElement;
  private readonly overlay: HTMLCanvasElement;
  private readonly overlayCtx: CanvasRenderingContext2D | null;
  private readonly status: HTMLElement;
  private readonly log: HTMLElement;
  private readonly modeButtons = new Map<TrainingMode, HTMLButtonElement>();
  private readonly viewButtons = new Map<ViewPreset, HTMLButtonElement>();
  private readonly startPanel: HTMLElement;
  private readonly timers = new Set<ReturnType<typeof setTimeout>>();

  constructor(mount: HTMLElement, handlers: TrainingHudHandlers) {
    this.canvas = el('canvas', { className: 'tr__canvas' });
    this.status = el('div', { className: 'tr__status', attrs: { role: 'status' } });
    this.camNote = el('div', { className: 'tr__cam-note', text: 'camera off' });
    this.overlay = el('canvas', { attrs: { width: '320', height: '240' } });
    this.overlayCtx = this.overlay.getContext('2d');
    this.camWrap = el('div', { className: 'tr__cam' }, [this.overlay, this.camNote]);
    this.log = el('div', { className: 'tr__log', attrs: { 'aria-live': 'polite' } });

    const meterRows = (Object.keys(SIGNAL_LABELS) as SignalName[]).map((name) => {
      const lamp = el('i', { className: 'tr__lamp' });
      const bar = el('i', { className: 'tr__bar-fill' });
      const value = el('span', { className: 'tr__meter-value', text: '0.00' });
      this.meters.set(name, { lamp, bar, value });
      return el('div', { className: 'tr__meter' }, [
        lamp,
        el('span', { className: 'tr__meter-name', text: SIGNAL_LABELS[name] }),
        el('span', { className: 'tr__bar' }, [bar]),
        value,
      ]);
    });

    const modeRow = el(
      'div',
      { className: 'tr__seg', attrs: { role: 'group', 'aria-label': 'What to show' } },
      (Object.keys(MODE_LABELS) as TrainingMode[]).map((mode) => {
        const node = el('button', {
          className: 'tr__seg-btn',
          text: MODE_LABELS[mode],
          attrs: { type: 'button', 'aria-pressed': String(mode === 'live') },
        });
        node.addEventListener('click', () => {
          handlers.onMode(mode);
        });
        this.modeButtons.set(mode, node);
        return node;
      }),
    );

    const viewRow = el(
      'div',
      { className: 'tr__seg', attrs: { role: 'group', 'aria-label': 'Camera framing' } },
      (['full', 'upper', 'face'] as ViewPreset[]).map((preset) => {
        const node = el('button', {
          className: 'tr__seg-btn',
          text: preset === 'full' ? 'Whole body' : preset === 'upper' ? 'Upper body' : 'Face',
          attrs: { type: 'button', 'aria-pressed': String(preset === 'full') },
        });
        node.addEventListener('click', () => {
          handlers.onView(preset);
        });
        this.viewButtons.set(preset, node);
        return node;
      }),
    );

    const panel = el('aside', { className: 'tr__panel' }, [
      el('div', { className: 'tr__panel-head' }, [
        el('h2', { className: 'tr__title', text: 'Training space' }),
        el('p', {
          className: 'tr__lead',
          text: 'No score, no rounds. Move and watch what the camera reads.',
        }),
      ]),
      el('div', { className: 'tr__group' }, [
        el('div', { className: 'tr__group-label', text: 'Showing' }),
        modeRow,
      ]),
      el('div', { className: 'tr__group' }, [
        el('div', { className: 'tr__group-label', text: 'Camera' }),
        viewRow,
        el('p', { className: 'tr__hint', text: 'Drag to orbit · scroll or pinch to zoom' }),
      ]),
      el('div', { className: 'tr__group' }, [
        el('div', { className: 'tr__group-label', text: 'What the camera reads' }),
        el('div', { className: 'tr__meters' }, meterRows),
      ]),
      el('div', { className: 'tr__group' }, [
        el('div', { className: 'tr__group-label', text: 'Detected' }),
        this.log,
      ]),
    ]);

    const startButton = el('button', {
      className: 'tr__start',
      text: 'Start the camera',
      attrs: { type: 'button' },
    });
    startButton.addEventListener('click', handlers.onStartCamera);

    const exitButton = el('button', {
      className: 'tr__exit',
      text: 'Back to the store',
      attrs: { type: 'button' },
    });
    exitButton.addEventListener('click', handlers.onExit);

    this.startPanel = el('div', { className: 'tr__gate' }, [
      el('div', { className: 'tr__gate-inner' }, [
        el('h2', { text: 'Training space' }),
        el('p', {
          text:
            'A room with one fighter in it and nothing to win. Stand about two metres back so ' +
            'your hips and feet are in frame, and watch your movement come through.',
        }),
        startButton,
        this.status,
      ]),
    ]);

    this.root = el('div', { className: 'tr' }, [
      this.canvas,
      el('div', { className: 'tr__overlay' }, [this.camWrap, exitButton]),
      panel,
      this.startPanel,
    ]);
    mount.append(this.root);
  }

  hideGate(): void {
    this.startPanel.hidden = true;
  }

  setStatus(text: string): void {
    this.status.textContent = text;
  }

  setCameraNote(text: string): void {
    this.camNote.textContent = text;
  }

  setMode(mode: TrainingMode): void {
    for (const [name, node] of this.modeButtons) {
      node.setAttribute('aria-pressed', String(name === mode));
    }
  }

  setView(preset: ViewPreset): void {
    for (const [name, node] of this.viewButtons) {
      node.setAttribute('aria-pressed', String(name === preset));
    }
  }

  /**
   * @param value 0..1, how strongly the signal is reading.
   * @param hot whether it is over the threshold that would count as a strike.
   */
  setSignal(name: SignalName, value: number, hot: boolean): void {
    const meter = this.meters.get(name);
    if (!meter) return;
    const clamped = Math.max(0, Math.min(1, value));
    meter.bar.style.transform = `scaleX(${clamped})`;
    meter.value.textContent = clamped.toFixed(2);
    meter.lamp.classList.toggle('is-hot', hot);
  }

  /** A short line naming what was just detected, newest first. */
  note(text: string): void {
    const line = el('div', { className: 'tr__log-line', text });
    this.log.prepend(line);
    while (this.log.childElementCount > 6) this.log.lastElementChild?.remove();
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      line.classList.add('is-faded');
    }, 1400);
    this.timers.add(timer);
  }

  attachCamera(video: HTMLVideoElement): void {
    if (video.parentElement === this.camWrap) return;
    this.camWrap.prepend(video);
  }

  drawOverlay(
    bodies: readonly (readonly (readonly [number, number, number])[])[],
    links: readonly (readonly [number, number])[],
  ): void {
    const ctx = this.overlayCtx;
    if (!ctx) return;
    const { width, height } = this.overlay;
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = '#8f9dff';
    ctx.fillStyle = '#8f9dff';
    ctx.lineWidth = 3;
    for (const body of bodies) {
      for (const [from, to] of links) {
        const a = body[from];
        const b = body[to];
        if (!a || !b) continue;
        ctx.beginPath();
        ctx.moveTo(a[0] * width, a[1] * height);
        ctx.lineTo(b[0] * width, b[1] * height);
        ctx.stroke();
      }
      for (const point of [0, 15, 16, 27, 28]) {
        const landmark = body[point];
        if (!landmark) continue;
        ctx.beginPath();
        ctx.arc(landmark[0] * width, landmark[1] * height, 4.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  clearOverlay(): void {
    this.overlayCtx?.clearRect(0, 0, this.overlay.width, this.overlay.height);
  }

  dispose(): void {
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
    clear(this.log);
    this.root.remove();
  }
}
