import { GAME_IDS } from '@adapters/catalog/static-catalog.adapter.ts';
import { ok, type Result } from '@domain/shared/result.ts';
import type { GameContext, GameHandle, GameRuntime } from '@app/ports/game-runtime.port.ts';
import type { PoseSourcePort } from '@app/ports/pose-source.port.ts';
import { ShadowboutSession } from './session.ts';

/**
 * Shadowbout as the store sees it.
 *
 * The game takes its dependencies rather than building them, so the pose
 * source can be a real camera in the browser and a scripted stand-in in a
 * test. The composition root decides; the game does not care.
 */
export function createShadowbout(deps: { pose: PoseSourcePort }): GameRuntime {
  return {
    id: GAME_IDS.shadowbout,

    async launch(context: GameContext): Promise<Result<GameHandle>> {
      const session = new ShadowboutSession(context, deps.pose);
      session.begin();
      return ok(session);
    },
  };
}
