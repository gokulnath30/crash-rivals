import { clamp } from '@domain/shared/mathx.ts';
import type { Fighter } from '@domain/fighting/fighter.ts';
import { RULES, type MoveName } from '@domain/fighting/moves.ts';
import { on } from '@ui/dom.ts';

/**
 * The keyboard fallback.
 *
 * Shadowbout is a camera game, but a camera is the one thing a player might
 * not have — no webcam, permission refused, or a browser that will not hand
 * one over. Rather than a dead end, they get keys. It plays differently, but
 * it plays.
 */
const STRIKE_KEYS: Readonly<Record<string, MoveName>> = {
  j: 'jab',
  k: 'cross',
  l: 'hook',
  i: 'kick',
};

const MOVE_SPEED = 1.6;

export class KeyboardControls {
  readonly hint = 'J K L punch · I kick · Space block · A D step';

  private readonly held = new Set<string>();
  private readonly detach: (() => void)[] = [];

  /**
   * @param onStrike called when a strike key is pressed, so the session can
   *   route it into the fighter and raise the matching event.
   */
  constructor(private readonly onStrike: (move: MoveName) => void) {
    this.detach.push(
      on(window, 'keydown', (event) => {
        const key = event.key.toLowerCase();
        this.held.add(key);
        // Space scrolls the page otherwise, which is a strange thing for a
        // block to do.
        if (key === ' ') event.preventDefault();
        if (event.repeat) return;
        const move = STRIKE_KEYS[key];
        if (move) this.onStrike(move);
      }),
      on(window, 'keyup', (event) => {
        this.held.delete(event.key.toLowerCase());
      }),
      // A focus change can swallow the keyup, leaving a key stuck down.
      on(window, 'blur', () => {
        this.held.clear();
      }),
    );
  }

  apply(fighter: Fighter, dt: number): void {
    const left = this.held.has('a') || this.held.has('arrowleft');
    const right = this.held.has('d') || this.held.has('arrowright');
    const drift = (right ? 1 : 0) - (left ? 1 : 0);
    fighter.strafe = clamp(
      fighter.strafe + drift * MOVE_SPEED * dt,
      -RULES.strafeLimit,
      RULES.strafeLimit,
    );
    // Blocking is refused mid-swing, so you cannot punch and cover at once.
    fighter.blocking = this.held.has(' ') && fighter.animation === null;
  }

  dispose(): void {
    for (const remove of this.detach.splice(0)) remove();
    this.held.clear();
  }
}
