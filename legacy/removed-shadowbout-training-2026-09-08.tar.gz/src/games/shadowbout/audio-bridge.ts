import type { FightEvent, FighterIndex } from '@domain/fighting/events.ts';
import type { AudioPort, SoundCue } from '@app/ports/audio.port.ts';

/**
 * Fight events in, sound out.
 *
 * All of the game's audio decisions live here, in one readable table, because
 * the alternative — an `audio.play(...)` next to every rule that could make a
 * noise — is how a codebase ends up with a punch that plays two sounds on
 * Tuesdays. The fighting rules emit events and know nothing about sound; this
 * listens.
 */
export class FightAudio {
  constructor(private readonly audio: AudioPort) {}

  /**
   * @param panOf where each fighter is on screen, -1..1, so hits come from
   *   the side they happened on.
   */
  handle(events: readonly FightEvent[], panOf: (fighter: FighterIndex) => number): void {
    for (const event of events) {
      switch (event.kind) {
        case 'hit': {
          const cue = cueForHit(event.blocked, event.heavy, event.label);
          // Damage tops out around 20, so this maps a jab to a whisper and a
          // clean kick to the full weight of the voice.
          const intensity = Math.min(1, event.damage / 20);
          this.audio.play(cue, { intensity, pan: panOf(event.defender) });

          // Heavy hits pull the music down briefly so the impact has room.
          if (!event.blocked && event.heavy) this.audio.duck(0.55, 0.4);
          break;
        }

        case 'whiff':
          this.audio.play('whiff', { intensity: 0.4, pan: panOf(event.attacker) });
          break;

        case 'move-thrown':
          // The wind-up, before anyone knows whether it will land.
          this.audio.play('whiff', { intensity: 0.55, pan: panOf(event.attacker) });
          break;

        case 'guard-raised':
          this.audio.play('guard-up', { intensity: 0.5, pan: panOf(event.fighter) });
          break;

        case 'knockout':
          this.audio.play('knockout', { intensity: 1, pan: panOf(event.loser) });
          this.audio.duck(0.85, 1.8);
          break;

        case 'round-start':
          this.audio.play('bell-start', { intensity: 0.9 });
          this.audio.startMusic('fight');
          break;

        case 'round-end':
          this.audio.play('bell-end', { intensity: 0.8 });
          if (event.matchOver) {
            this.audio.stopMusic(0.5);
            this.audio.play(event.winner === 0 ? 'match-won' : 'match-lost', { intensity: 0.9 });
            this.audio.startMusic('victory');
          }
          break;

        case 'time-up':
          this.audio.play('bell-end', { intensity: 1 });
          this.audio.play('crowd-swell', { intensity: 0.5 });
          break;

        case 'announce':
          // Announcements are text on screen; the events above already made
          // whatever noise they needed.
          break;
      }
    }
  }
}

function cueForHit(blocked: boolean, heavy: boolean, label: string): SoundCue {
  if (blocked) return 'block';
  if (label === 'kick') return 'kick';
  return heavy ? 'punch-heavy' : 'punch-light';
}
