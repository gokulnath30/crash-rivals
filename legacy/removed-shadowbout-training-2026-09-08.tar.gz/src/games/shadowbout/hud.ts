import { OVERLAY_LINKS } from '@domain/fighting/skeleton.ts';
import { RULES } from '@domain/fighting/moves.ts';
import type { FighterIndex } from '@domain/fighting/events.ts';
import { el, clear } from '@ui/dom.ts';
import type { CharacterDefinition, CharacterId } from './characters.ts';

export interface HudLabels {
  readonly left: string;
  readonly right: string;
}

/**
 * Everything on top of the 3D view: health, clock, round pips, the camera
 * preview, the announcer, and the two panels.
 *
 * DOM rather than drawn into the canvas, because text laid out by the browser
 * is sharp at every device pixel ratio, respects the player's font size, and
 * can be read by a screen reader. The canvas is for the fight; this is for the
 * information about the fight.
 */
export class Hud {
  readonly root: HTMLElement;
  readonly canvas: HTMLCanvasElement;

  private readonly fills: [HTMLElement, HTMLElement];
  private readonly ghosts: [HTMLElement, HTMLElement];
  private readonly ghostValues: [number, number] = [1, 1];
  private readonly names: [HTMLElement, HTMLElement];
  private readonly hints: [HTMLElement, HTMLElement];
  private readonly clock: HTMLElement;
  private readonly pips: [HTMLElement, HTMLElement];
  private readonly announcer: HTMLElement;
  private readonly flash: HTMLElement;
  private readonly camNote: HTMLElement;
  private readonly camWrap: HTMLElement;
  private readonly overlay: HTMLCanvasElement;
  private readonly overlayCtx: CanvasRenderingContext2D | null;
  private readonly guardHint: HTMLElement;
  private readonly ping: HTMLElement;
  private readonly loading: HTMLElement;
  private readonly rivalWrap: HTMLElement;
  private readonly rivalVideo: HTMLVideoElement;
  private readonly rivalAudio: HTMLAudioElement;
  private readonly callControls: HTMLElement;
  private readonly leftSlot: HTMLElement;
  private readonly rightSlot: HTMLElement;

  private readonly startPanel: HTMLElement;
  private readonly startBody: HTMLElement;
  private readonly chooser: HTMLElement;
  private readonly startActions: HTMLElement;
  private readonly startStatus: HTMLElement;
  private readonly resultPanel: HTMLElement;
  private readonly resultTitle: HTMLElement;
  private readonly resultLine: HTMLElement;
  private readonly resultActions: HTMLElement;

  private lastAnnounced = '';
  private readonly timers = new Set<ReturnType<typeof setTimeout>>();

  constructor(mount: HTMLElement, labels: HudLabels) {
    this.canvas = el('canvas', { className: 'sb__canvas' });

    this.fills = [el('i', { className: 'sb__fill' }), el('i', { className: 'sb__fill' })];
    this.ghosts = [el('i', { className: 'sb__ghost' }), el('i', { className: 'sb__ghost' })];
    this.names = [el('b', { text: labels.left }), el('b', { text: labels.right })];
    this.hints = [el('span'), el('span')];
    this.clock = el('div', { className: 'sb__clock', text: String(RULES.roundSeconds) });
    this.pips = [el('i', { className: 'sb__pip' }), el('i', { className: 'sb__pip' })];
    this.announcer = el('div', { className: 'sb__announce', attrs: { 'aria-live': 'polite' } });
    this.flash = el('div', { className: 'sb__flash' });
    this.camNote = el('div', { className: 'sb__cam-note', text: 'camera off' });
    this.overlay = el('canvas', { attrs: { width: '320', height: '240' } });
    this.overlayCtx = this.overlay.getContext('2d');
    this.guardHint = el('em', { text: 'both hands up' });
    this.ping = el('div', { className: 'sb__ping' });
    this.loading = el('div', { className: 'sb__loading', attrs: { role: 'status' } });
    this.loading.hidden = true;

    // The opponent's camera. `playsinline` so phones do not hijack it into
    // fullscreen, and muted here because their voice comes out of the audio
    // element instead — a muted video element is allowed to autoplay, an
    // unmuted one is not.
    this.rivalVideo = el('video', {
      attrs: { autoplay: '', playsinline: '', muted: '' },
    });
    this.rivalVideo.muted = true;
    this.rivalAudio = el('audio', { attrs: { autoplay: '' } });
    this.rivalWrap = el('div', { className: 'sb__rival' }, [
      this.rivalVideo,
      el('div', { className: 'sb__cam-note', text: 'your rival' }),
    ]);
    this.rivalWrap.hidden = true;
    this.callControls = el('div', { className: 'sb__call' });
    this.callControls.hidden = true;

    this.camWrap = el('div', { className: 'sb__cam' }, [this.overlay, this.camNote]);

    const side = (index: FighterIndex): HTMLElement =>
      el('div', { className: index === 0 ? 'sb__side' : 'sb__side sb__side--right' }, [
        el('div', { className: 'sb__tag' }, [this.names[index], this.hints[index]]),
        el('div', { className: 'sb__track' }, [this.ghosts[index], this.fills[index]]),
      ]);

    // Camera tiles live under the health bars, one per side, so each player's
    // face sits beneath their own name. Which tile goes where depends on which
    // seat you are, and is set by `setSides`.
    this.leftSlot = el('div', { className: 'sb__slot' });
    this.rightSlot = el('div', { className: 'sb__slot sb__slot--right' });

    const bars = el('div', { className: 'sb__bars' }, [
      el('div', {}, [side(0), this.leftSlot]),
      el('div', { className: 'sb__clock-wrap' }, [
        this.clock,
        el('div', { className: 'sb__pips' }, [this.pips[0], this.pips[1]]),
      ]),
      el('div', {}, [side(1), this.rightSlot]),
    ]);

    const moves = el('div', { className: 'sb__moves' }, [
      el('div', {}, [
        document.createTextNode('punch — '),
        el('em', { text: 'reach them, not at them' }),
      ]),
      el('div', {}, [document.createTextNode('kick — '), el('em', { text: 'knee up, drive forward' })]),
      el('div', {}, [document.createTextNode('block — '), this.guardHint]),
      el('div', {}, [document.createTextNode('turn — '), el('em', { text: 'your body turns theirs' })]),
      this.ping,
    ]);

    this.startStatus = el('div', { className: 'sb__status', attrs: { role: 'status' } });
    this.startBody = el('p');
    this.startActions = el('div', { className: 'sb__panel-actions' });
    this.chooser = el('div', {
      className: 'sb__chooser',
      attrs: { role: 'radiogroup', 'aria-label': 'Choose your fighter' },
    });
    this.startPanel = el('div', { className: 'sb__panel' }, [
      el('div', { className: 'sb__panel-inner' }, [
        el('h2', { text: 'Shadowbout' }),
        this.startBody,
        this.chooser,
        this.startActions,
        this.startStatus,
      ]),
    ]);

    this.resultTitle = el('h2');
    this.resultLine = el('p');
    this.resultActions = el('div', { className: 'sb__panel-actions' });
    this.resultPanel = el('div', { className: 'sb__panel', attrs: { hidden: '' } }, [
      el('div', { className: 'sb__panel-inner' }, [
        this.resultTitle,
        this.resultLine,
        this.resultActions,
      ]),
    ]);
    this.resultPanel.hidden = true;

    this.root = el('div', { className: 'sb' }, [
      this.canvas,
      this.flash,
      this.loading,
      el('div', { className: 'sb__hud' }, [
        bars,
        el('div', { className: 'sb__foot' }, [this.callControls, moves]),
      ]),
      this.rivalAudio,
      this.announcer,
      this.startPanel,
      this.resultPanel,
    ]);

    mount.append(this.root);
  }

  // ------------------------------------------------------------ live state

  setHealth(index: FighterIndex, fraction: number): void {
    const clamped = Math.max(0, Math.min(1, fraction));
    this.fills[index].style.transform = `scaleX(${clamped})`;
    // The ghost only ever falls, and slowly, so a hit leaves a visible trace
    // of what it cost.
    if (this.ghostValues[index] > clamped) {
      this.ghostValues[index] = clamped;
      this.ghosts[index].style.transform = `scaleX(${clamped})`;
    }
  }

  resetHealth(): void {
    for (const index of [0, 1] as const) {
      this.ghostValues[index] = 1;
      this.ghosts[index].style.transform = 'scaleX(1)';
      this.fills[index].style.transform = 'scaleX(1)';
    }
  }

  setClock(seconds: number): void {
    this.clock.textContent = String(Math.ceil(Math.max(0, seconds)));
  }

  setWins(wins: readonly [number, number]): void {
    this.pips[0].className = `sb__pip${wins[0] > 0 ? ' sb__pip--p1' : ''}`;
    this.pips[1].className = `sb__pip${wins[1] > 0 ? ' sb__pip--p2' : ''}`;
  }

  setNames(labels: HudLabels): void {
    this.names[0].textContent = labels.left;
    this.names[1].textContent = labels.right;
  }

  setGuarding(guarding: boolean): void {
    this.guardHint.classList.toggle('is-lit', guarding);
  }

  setLatency(ms: number | null): void {
    this.ping.textContent = ms === null ? '' : `${Math.round(ms)} ms to your rival`;
  }

  /** A short, self-clearing note under a fighter's name. */
  setHint(index: FighterIndex, text: string): void {
    const target = this.hints[index];
    target.textContent = text;
    this.after(1100, () => {
      if (target.textContent === text) target.textContent = '';
    });
  }

  /**
   * A corner chip while something is downloading. Shown outside the start
   * panel because the models keep loading after the panel is gone — a fight
   * begins on the practice figure and the character arrives during it.
   */
  setLoading(text: string | null): void {
    this.loading.textContent = text ?? '';
    this.loading.hidden = text === null;
  }

  /**
   * Puts each camera under the fighter it belongs to.
   *
   * Called once the seat is known. Your own face goes beneath your own name
   * and health bar, theirs beneath theirs, so the screen reads the same way
   * the fight does rather than making you work out which tile is whose.
   */
  setSides(self: FighterIndex): void {
    const mine = self === 0 ? this.leftSlot : this.rightSlot;
    const theirs = self === 0 ? this.rightSlot : this.leftSlot;
    mine.append(this.camWrap);
    theirs.append(this.rivalWrap);
  }

  /**
   * Shows the other player's camera and plays their voice.
   *
   * Called once per arriving track, so it may run twice — video first, then
   * audio. Re-attaching the same stream is harmless.
   */
  showRival(stream: MediaStream): void {
    if (this.rivalVideo.srcObject !== stream) this.rivalVideo.srcObject = stream;
    if (this.rivalAudio.srcObject !== stream) this.rivalAudio.srcObject = stream;
    this.rivalWrap.hidden = false;
    // Both are already inside a user gesture by this point, but a rejected
    // play must not take the fight down with it.
    void this.rivalVideo.play().catch(() => undefined);
    void this.rivalAudio.play().catch(() => undefined);
  }

  hideRival(): void {
    this.rivalWrap.hidden = true;
    this.rivalVideo.srcObject = null;
    this.rivalAudio.srcObject = null;
  }

  /**
   * The mute controls.
   *
   * Present whenever a match is sending camera and voice, because someone
   * being able to turn off their own microphone is the least a call owes them.
   */
  showCallControls(handlers: {
    onToggleMic: (muted: boolean) => void;
    onToggleCam: (muted: boolean) => void;
  }): void {
    clear(this.callControls);
    let micMuted = false;
    let camMuted = false;

    const mic = el('button', { className: 'sb__call-btn', attrs: { type: 'button' } });
    const cam = el('button', { className: 'sb__call-btn', attrs: { type: 'button' } });
    const paint = (): void => {
      mic.textContent = micMuted ? 'Unmute mic' : 'Mute mic';
      mic.setAttribute('aria-pressed', String(micMuted));
      cam.textContent = camMuted ? 'Show camera' : 'Hide camera';
      cam.setAttribute('aria-pressed', String(camMuted));
    };
    mic.addEventListener('click', () => {
      micMuted = !micMuted;
      handlers.onToggleMic(micMuted);
      paint();
    });
    cam.addEventListener('click', () => {
      camMuted = !camMuted;
      handlers.onToggleCam(camMuted);
      paint();
    });
    paint();

    this.callControls.append(mic, cam);
    this.callControls.hidden = false;
  }

  setCameraNote(text: string): void {
    this.camNote.textContent = text;
  }

  /** Slots the live camera feed in behind the skeleton overlay. */
  attachCamera(video: HTMLVideoElement): void {
    if (video.parentElement === this.camWrap) return;
    this.camWrap.prepend(video);
  }

  /** Draws the tracked skeletons on the preview. */
  drawOverlay(bodies: readonly (readonly (readonly [number, number, number])[])[]): void {
    const ctx = this.overlayCtx;
    if (!ctx) return;
    const { width, height } = this.overlay;
    ctx.clearRect(0, 0, width, height);

    bodies.forEach((body, index) => {
      ctx.strokeStyle = index === 0 ? '#ff3f6e' : '#3fd0ff';
      ctx.fillStyle = ctx.strokeStyle;
      ctx.lineWidth = 3;

      for (const [from, to] of OVERLAY_LINKS) {
        const a = body[from];
        const b = body[to];
        if (!a || !b) continue;
        ctx.beginPath();
        ctx.moveTo(a[0] * width, a[1] * height);
        ctx.lineTo(b[0] * width, b[1] * height);
        ctx.stroke();
      }

      for (const point of [0, 15, 16, 27, 28]) {
        const landmark = body[point];
        if (!landmark) continue;
        ctx.beginPath();
        ctx.arc(landmark[0] * width, landmark[1] * height, 4.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }

  clearOverlay(): void {
    this.overlayCtx?.clearRect(0, 0, this.overlay.width, this.overlay.height);
  }

  // -------------------------------------------------------------- spectacle

  announce(text: string, holdMs = 900): void {
    this.announcer.textContent = text;
    this.announcer.classList.remove('is-shown');
    // Forces a layout flush. Without it the browser coalesces the class
    // removal and the addition below into one style change, and the slam
    // animation never restarts on a second announcement.
    void this.announcer.getBoundingClientRect();
    this.announcer.classList.add('is-shown');
    this.after(holdMs + 200, () => {
      this.announcer.classList.remove('is-shown');
    });
  }

  /** Announces only if the message changed, for per-frame calibration text. */
  announceOnce(text: string): void {
    if (text === this.lastAnnounced) return;
    this.lastAnnounced = text;
    this.announce(text, 700);
  }

  forgetAnnouncement(): void {
    this.lastAnnounced = '';
  }

  impactFlash(blocked: boolean): void {
    this.flash.style.opacity = blocked ? '0.06' : '0.14';
    this.after(60, () => {
      this.flash.style.opacity = '0';
    });
  }

  damageNumber(at: { x: number; y: number }, amount: number, colour: string): void {
    const node = el('div', { className: 'sb__damage', text: String(amount) });
    node.style.color = colour;
    node.style.left = `${at.x}px`;
    node.style.top = `${at.y}px`;
    document.body.append(node);
    this.after(1000, () => {
      node.remove();
    });
  }

  // ------------------------------------------------------------------ panels

  showStart(input: {
    body: string;
    actions: readonly HTMLElement[];
    status?: string;
  }): void {
    this.startBody.textContent = input.body;
    clear(this.startActions);
    this.startActions.append(...input.actions);
    this.startStatus.textContent = input.status ?? '';
    this.startPanel.hidden = false;
    this.resultPanel.hidden = true;
  }

  /**
   * The character picker, shown on the opening panel.
   *
   * Radio semantics rather than buttons: it is one choice from a set, and a
   * screen reader should say so. Re-rendered on every pick so the selected
   * state stays in one place.
   */
  showCharacterChoice(
    characters: readonly CharacterDefinition[],
    selected: CharacterId,
    onPick: (id: CharacterId) => void,
  ): void {
    clear(this.chooser);
    this.chooser.append(
      el('div', { className: 'sb__chooser-label', text: 'Your fighter' }),
      el(
        'div',
        { className: 'sb__chooser-row' },
        characters.map((character) => {
          const chosen = character.id === selected;
          const card = el(
            'button',
            {
              className: `sb__pick${chosen ? ' is-picked' : ''}`,
              attrs: { type: 'button', role: 'radio', 'aria-checked': String(chosen) },
            },
            [
              el('span', { className: 'sb__pick-name', text: character.name }),
              el('span', { className: 'sb__pick-blurb', text: character.blurb }),
            ],
          );
          card.style.setProperty('--pick-accent', character.accent);
          card.addEventListener('click', () => {
            onPick(character.id);
            this.showCharacterChoice(characters, character.id, onPick);
          });
          return card;
        }),
      ),
    );
  }

  setStartStatus(text: string): void {
    this.startStatus.textContent = text;
  }

  hidePanels(): void {
    this.startPanel.hidden = true;
    this.resultPanel.hidden = true;
  }

  showResult(input: { title: string; line: string; actions: readonly HTMLElement[] }): void {
    this.resultTitle.textContent = input.title;
    this.resultLine.textContent = input.line;
    clear(this.resultActions);
    this.resultActions.append(...input.actions);
    this.resultPanel.hidden = false;
  }

  dispose(): void {
    this.hideRival();
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
    for (const node of document.querySelectorAll('.sb__damage')) node.remove();
    this.root.remove();
  }

  /** A tracked `setTimeout`, so `dispose` can cancel anything still pending. */
  private after(ms: number, run: () => void): void {
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      run();
    }, ms);
    this.timers.add(timer);
  }
}
