import * as THREE from 'three';

/**
 * The room the fight happens in: a lit disc, a gold ring, and a ragged circle
 * of pillars receding into the fog.
 *
 * Built once and never touched again, so it takes a seeded random rather than
 * `Math.random` — a screenshot of the arena looks the same on every run,
 * which makes visual regressions actually visible.
 */
export function buildArena(scene: THREE.Scene, seed = 1337): void {
  const random = seededRandom(seed);

  scene.add(new THREE.HemisphereLight(0x9f7bff, 0x120a22, 0.75));

  const key = new THREE.DirectionalLight(0xfff2d0, 1.15);
  key.position.set(2.5, 5.5, -2.5);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.left = -4;
  key.shadow.camera.right = 4;
  key.shadow.camera.top = 4;
  key.shadow.camera.bottom = -4;
  scene.add(key);

  // One rim light per fighter's colour, on opposite sides, so each fighter is
  // separated from the background by their own hue.
  const rimA = new THREE.PointLight(0xff3f6e, 12, 9, 2);
  rimA.position.set(-2.6, 1.7, -1.4);
  scene.add(rimA);
  const rimB = new THREE.PointLight(0x3fd0ff, 12, 9, 2);
  rimB.position.set(2.6, 1.7, 1.4);
  scene.add(rimB);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(3.4, 64),
    new THREE.MeshStandardMaterial({ color: 0x1a1030, roughness: 0.75, metalness: 0.15 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(3.42, 0.045, 12, 96),
    new THREE.MeshBasicMaterial({ color: 0xffcf5c }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.02;
  scene.add(ring);

  const grid = new THREE.GridHelper(28, 28, 0x2a1c4d, 0x1c1236);
  grid.position.y = -0.02;
  scene.add(grid);

  // Pillars share one geometry and one material, scaled per instance — 26
  // draw calls of the same mesh rather than 26 different ones.
  const pillarGeometry = new THREE.BoxGeometry(0.35, 1, 0.35);
  const pillarMaterial = new THREE.MeshStandardMaterial({
    color: 0x160d2b,
    roughness: 1,
    emissive: 0x2a1550,
    emissiveIntensity: 0.35,
  });
  const pillars = new THREE.InstancedMesh(pillarGeometry, pillarMaterial, PILLAR_COUNT);
  const transform = new THREE.Matrix4();
  for (let i = 0; i < PILLAR_COUNT; i++) {
    const angle = (i / PILLAR_COUNT) * Math.PI * 2;
    const radius = 5.2 + random() * 3.4;
    const height = 1.4 + random() * 2.6;
    transform.makeScale(1, height, 1);
    transform.setPosition(
      Math.cos(angle) * radius,
      height / 2 - 0.4,
      Math.sin(angle) * radius,
    );
    pillars.setMatrixAt(i, transform);
  }
  pillars.instanceMatrix.needsUpdate = true;
  scene.add(pillars);
}

const PILLAR_COUNT = 26;

/**
 * A small deterministic generator (mulberry32). Not cryptographic, and not
 * meant to be — it exists so the scenery is identical on every load.
 */
function seededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
