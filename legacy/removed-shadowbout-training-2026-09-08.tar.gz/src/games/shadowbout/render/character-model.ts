import type * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { clone as cloneSkinned } from 'three/examples/jsm/utils/SkeletonUtils.js';
import type { LoggerPort } from '@app/ports/logger.port.ts';
import { fail, failure, ok, type Result } from '@domain/shared/result.ts';
import type { CharacterDefinition } from '../characters.ts';

/** A posable copy of a character, plus whatever animations it shipped with. */
export interface CharacterInstance {
  readonly scene: THREE.Object3D;
  /**
   * Clips baked into the export. Unused while a body is driving the bones,
   * but they are what the training space plays back as a reference.
   */
  readonly clips: readonly THREE.AnimationClip[];
}

/**
 * Loads character models, once each.
 *
 * A model is a couple of megabytes, and in a two-player match both fighters
 * may be the same character. The file is fetched once and every fighter gets a
 * clone — which for a skinned mesh means `SkeletonUtils.clone`, because the
 * ordinary `Object3D.clone` copies the meshes but leaves them all bound to the
 * *original's* skeleton, so posing one fighter would pose both.
 *
 * In-flight requests are shared too: two fighters asking for the same model at
 * the same moment produce one download, not two.
 */
/** How a download is going, for whatever is showing a loading state. */
export interface LoadProgress {
  readonly name: string;
  /** 0..1 when the server sent a length, null when it did not. */
  readonly fraction: number | null;
  readonly loadedBytes: number;
  readonly done: boolean;
}

export class CharacterModels {
  private readonly loader = new GLTFLoader();
  private readonly loaded = new Map<string, CharacterInstance>();
  private readonly pending = new Map<string, Promise<Result<CharacterInstance>>>();
  private readonly log: LoggerPort;
  private onProgress: ((progress: LoadProgress) => void) | null = null;

  constructor(logger: LoggerPort) {
    this.log = logger.scoped('characters');
  }

  /**
   * Called as a model downloads. A character is megabytes — 13 for the
   * detailed exports — and a silent wait on a blank fighter is
   * indistinguishable from a broken one.
   */
  watchProgress(listener: (progress: LoadProgress) => void): void {
    this.onProgress = listener;
  }

  /**
   * A fresh, independently posable copy of a character.
   *
   * Never throws. A model that will not load returns a failure so the caller
   * can fall back to the stick figure rather than losing the match.
   */
  async instance(character: CharacterDefinition): Promise<Result<CharacterInstance>> {
    const source = await this.source(character);
    if (!source.ok) return source;
    // The clips are keyed by bone *name*, so they drive a clone just as well
    // as they drive the original and do not need copying.
    return ok({ scene: cloneSkinned(source.value.scene), clips: source.value.clips });
  }

  private async source(character: CharacterDefinition): Promise<Result<CharacterInstance>> {
    const cached = this.loaded.get(character.model);
    if (cached) return ok(cached);

    const inFlight = this.pending.get(character.model);
    if (inFlight) return inFlight;

    const url = new URL(character.model, document.baseURI).href;
    const request = this.fetch(character, url);
    this.pending.set(character.model, request);
    const result = await request;
    this.pending.delete(character.model);
    return result;
  }

  private async fetch(
    character: CharacterDefinition,
    url: string,
  ): Promise<Result<CharacterInstance>> {
    try {
      const started = performance.now();
      const gltf = await new Promise<{ scene: THREE.Object3D; animations: THREE.AnimationClip[] }>(
        (resolve, reject) => {
          this.loader.load(
            url,
            resolve,
            (event) => {
              this.onProgress?.({
                name: character.name,
                // `lengthComputable` is false when the server sends no
                // content-length, which is why the fraction is nullable
                // rather than a fake number.
                fraction: event.lengthComputable ? event.loaded / event.total : null,
                loadedBytes: event.loaded,
                done: false,
              });
            },
            reject,
          );
        },
      );
      this.onProgress?.({ name: character.name, fraction: 1, loadedBytes: 0, done: true });
      const instance: CharacterInstance = { scene: gltf.scene, clips: gltf.animations };
      this.loaded.set(character.model, instance);
      this.log.log(
        'info',
        `loaded ${character.name} in ${Math.round(performance.now() - started)}ms`,
      );
      return ok(instance);
    } catch (error: unknown) {
      this.onProgress?.({ name: character.name, fraction: null, loadedBytes: 0, done: true });
      this.log.log('warn', `could not load the model for ${character.name}`, error);
      return fail(
        failure('unavailable', `Could not load ${character.name}. Using the practice figure.`),
      );
    }
  }

  dispose(): void {
    for (const model of this.loaded.values()) {
      model.scene.traverse((object) => {
        // Structural rather than `instanceof`: three's Mesh is generic over
        // its geometry and material, and the narrowed type is unusable.
        const drawable = object as Partial<THREE.Mesh>;
        drawable.geometry?.dispose();
        for (const material of materialsOf(drawable.material)) material.dispose();
      });
    }
    this.loaded.clear();
    this.pending.clear();
  }
}

function materialsOf(
  material: THREE.Material | THREE.Material[] | undefined,
): readonly THREE.Material[] {
  if (!material) return [];
  return Array.isArray(material) ? material : [material];
}
