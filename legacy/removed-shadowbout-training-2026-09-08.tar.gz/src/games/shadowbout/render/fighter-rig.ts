import * as THREE from 'three';
import type { Fighter } from '@domain/fighting/fighter.ts';
import { BONES, JOINTS, radiusOf } from '@domain/fighting/skeleton.ts';
import type { FighterView } from './fighter-view.ts';

/**
 * The meshes for one fighter, driven entirely by reading a `Fighter`.
 *
 * This is the whole point of keeping the simulation free of Three.js: the
 * fighter is a bag of numbers, and this class is one possible way to look at
 * it. Nothing here can change the fight.
 *
 * It is now the fallback rather than the default: `GltfFighterRig` draws a
 * real character when one loads, and this takes over when the model cannot be
 * fetched — a slow connection or a blocked CDN leaves you playing, not
 * staring at an error.
 */
export class FighterRig implements FighterView {
  readonly group = new THREE.Group();

  private readonly skin: THREE.MeshStandardMaterial;
  private readonly joints: Partial<Record<(typeof JOINTS)[number], THREE.Mesh>> = {};
  private readonly bones: THREE.Mesh[] = [];
  private readonly glows: THREE.Mesh[] = [];
  private readonly shadow: THREE.Mesh;
  private readonly up = new THREE.Vector3(0, 1, 0);
  private readonly direction = new THREE.Vector3();

  constructor(
    scene: THREE.Scene,
    private readonly fighter: Fighter,
    colour: number,
  ) {
    this.skin = new THREE.MeshStandardMaterial({
      color: colour,
      roughness: 0.35,
      metalness: 0.25,
      emissive: colour,
      emissiveIntensity: 0.22,
    });

    for (const joint of JOINTS) {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(radiusOf(joint), 16, 12), this.skin);
      mesh.castShadow = true;
      this.group.add(mesh);
      this.joints[joint] = mesh;
    }

    // Bones are unit-length cylinders, stretched and aimed each frame.
    const boneGeometry = new THREE.CylinderGeometry(0.052, 0.052, 1, 10);
    for (let i = 0; i < BONES.length; i++) {
      const mesh = new THREE.Mesh(boneGeometry, this.skin);
      mesh.castShadow = true;
      this.group.add(mesh);
      this.bones.push(mesh);
    }

    // Bright caps on the striking limbs, so a player can see what will hit.
    for (const [joint, radius] of GLOW_JOINTS) {
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(radius, 14, 10),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 }),
      );
      mesh.userData['joint'] = joint;
      this.group.add(mesh);
      this.glows.push(mesh);
    }

    this.shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.42, 24),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.32 }),
    );
    this.shadow.rotation.x = -Math.PI / 2;

    scene.add(this.group);
    scene.add(this.shadow);
  }

  sync(dt: number): void {
    const { fighter } = this;
    this.group.position.set(fighter.position.x, fighter.position.y, fighter.position.z);
    // The same yaw `Fighter.worldOf` uses, so a fist is hittable where it is
    // drawn — squaring up plus however far the player has turned.
    this.group.rotation.y = fighter.yaw;

    for (const joint of JOINTS) {
      // Copied component-wise: the domain's Vec3 is deliberately not a
      // THREE.Vector3, and casting between them would be a lie the compiler
      // could not check.
      const local = fighter.pose[joint];
      this.joints[joint]?.position.set(local.x, local.y, local.z);
    }

    for (let i = 0; i < BONES.length; i++) {
      const link = BONES[i];
      const mesh = this.bones[i];
      if (!link || !mesh) continue;
      const from = fighter.pose[link[0]];
      const to = fighter.pose[link[1]];

      this.direction.set(to.x - from.x, to.y - from.y, to.z - from.z);
      const length = Math.max(0.001, this.direction.length());
      mesh.position.set(
        from.x + this.direction.x * 0.5,
        from.y + this.direction.y * 0.5,
        from.z + this.direction.z * 0.5,
      );
      mesh.scale.set(1, length, 1);
      mesh.quaternion.setFromUnitVectors(this.up, this.direction.normalize());
    }

    for (const glow of this.glows) {
      const joint = glow.userData['joint'] as (typeof JOINTS)[number];
      const position = fighter.pose[joint];
      glow.position.set(position.x, position.y, position.z);
    }

    this.shadow.position.set(fighter.position.x, 0.03, fighter.position.z);

    // Flash on being hit. Eased rather than snapped, so it reads as a pulse.
    const wanted = fighter.hurtFor > 0 ? 0.85 : 0.22;
    this.skin.emissiveIntensity += (wanted - this.skin.emissiveIntensity) * Math.min(1, dt * 12);
  }

  dispose(): void {
    this.group.removeFromParent();
    this.shadow.removeFromParent();
    for (const mesh of [...this.bones, ...this.glows, ...Object.values(this.joints)]) {
      mesh?.geometry.dispose();
    }
    this.skin.dispose();
  }
}

const GLOW_JOINTS = [
  ['wrL', 0.085],
  ['wrR', 0.085],
  ['anR', 0.075],
] as const;
