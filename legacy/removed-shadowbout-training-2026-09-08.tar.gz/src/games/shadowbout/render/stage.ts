import * as THREE from 'three';
import { damp } from '@domain/shared/mathx.ts';

/**
 * The renderer, the camera, and the camera's manners.
 *
 * Two behaviours live here that the fighting rules should never know about:
 * the camera drifts to keep both fighters framed, and it shakes on impact.
 * Both read from numbers the simulation hands over; neither can affect it.
 */
export class Stage {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(46, 1, 0.1, 60);

  private readonly renderer: THREE.WebGLRenderer;
  private readonly base: THREE.Vector3;
  private readonly lookAt: THREE.Vector3;
  private readonly target = new THREE.Vector3();
  /** +1 views from the near fighter's side, -1 from the far one's. */
  private readonly facing: 1 | -1;
  private shake = 0;
  private readonly resizeObserver: ResizeObserver;

  /**
   * @param options.mirrored view the arena from the far fighter's side. The
   *   guest in an online match sets this, so both players see themselves in
   *   the foreground while the two browsers keep identical fighter numbering.
   */
  constructor(
    private readonly canvas: HTMLCanvasElement,
    options: { mirrored?: boolean } = {},
  ) {
    this.facing = options.mirrored ? -1 : 1;
    // Set well off the line between the fighters. Two stick figures could be
    // viewed almost head-on and still both be readable; two solid bodies at
    // the same angle simply stack up on each other.
    this.base = new THREE.Vector3(2.15 * this.facing, 1.72, -2.7 * this.facing);
    this.lookAt = new THREE.Vector3(0, 1.05, 0.1 * this.facing);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    // Capped at 2: a 3x device pixel ratio triples the fragment cost for a
    // difference nobody can see on a moving fighter.
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene.background = new THREE.Color(0x0b0718);
    this.scene.fog = new THREE.Fog(0x0b0718, 5, 16);
    this.camera.position.copy(this.base);

    this.resizeObserver = new ResizeObserver(() => {
      this.resize();
    });
    this.resizeObserver.observe(canvas);
    this.resize();
  }

  /** Adds to the shake already scheduled, so two hits at once rock harder. */
  addShake(amount: number): void {
    this.shake = Math.min(0.5, this.shake + amount);
  }

  /**
   * @param midX the mid-point between the two fighters, so the camera keeps
   *   both of them on screen without ever fully leaving its established angle.
   */
  render(dt: number, midX: number): void {
    // The drift follows the action on screen, which is mirrored too.
    this.target.set(this.base.x + midX * 0.55 * this.facing, this.base.y, this.base.z);
    this.camera.position.lerp(this.target, Math.min(1, dt * 3));

    const shake = this.shake;
    this.shake = damp(this.shake, 0, 0.0015, dt);
    if (shake > 0.001) {
      this.camera.position.x += (Math.random() - 0.5) * shake;
      this.camera.position.y += (Math.random() - 0.5) * shake;
    }

    this.camera.lookAt(this.lookAt.x + midX * 0.4 * this.facing, this.lookAt.y, this.lookAt.z);
    this.renderer.render(this.scene, this.camera);
  }

  /** Projects a world point to CSS pixels, for floating damage numbers. */
  toScreen(point: { x: number; y: number; z: number }): { x: number; y: number } {
    const projected = new THREE.Vector3(point.x, point.y, point.z).project(this.camera);
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: rect.left + (projected.x * 0.5 + 0.5) * rect.width,
      y: rect.top + (-projected.y * 0.5 + 0.5) * rect.height,
    };
  }

  dispose(): void {
    this.resizeObserver.disconnect();
    // WebGL contexts are a limited resource; a few leaked ones and the
    // browser starts refusing to make new ones.
    this.scene.traverse((object) => {
      // Checked structurally rather than with `instanceof Mesh`: it covers
      // Points and Line too, and avoids three's generic Mesh signature.
      const drawable = object as Partial<THREE.Mesh>;
      drawable.geometry?.dispose();
      for (const material of materialsOf(drawable.material)) material.dispose();
    });
    this.renderer.dispose();
  }

  private resize(): void {
    const width = this.canvas.clientWidth || window.innerWidth;
    const height = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
  }
}

function materialsOf(material: THREE.Material | THREE.Material[] | undefined): THREE.Material[] {
  if (!material) return [];
  return Array.isArray(material) ? material : [material];
}
