import * as THREE from 'three';
import type { Fighter } from '@domain/fighting/fighter.ts';
import type { FaceReading } from '@domain/fighting/body-reading.ts';
import type { JointName } from '@domain/fighting/skeleton.ts';
import type { FighterView } from './fighter-view.ts';

/**
 * A skinned character driven by the domain skeleton.
 *
 * The model is a *skin over the simulation*, never the simulation itself. Hit
 * detection, reach and damage all read `Fighter.worldOf`, which knows nothing
 * about bones — so swapping the stick figure for a person changes how the
 * fight looks and nothing about how it plays.
 *
 * ## How the retarget works
 *
 * The domain gives sixteen joint *positions*. A skeleton needs bone
 * *rotations*. The bridge is that a bone's job is to point at its child: for
 * each mapped bone we take the direction its child sits in at rest, take the
 * direction the corresponding pair of domain joints sit in now, and rotate the
 * bone by the difference.
 *
 * Matching directions rather than copying rotations is what makes this work
 * against an arbitrary export: the model is in a T-pose and the game's stance
 * is not, and neither has to know about the other. It ignores twist along the
 * bone's own axis, which is invisible on a forearm and not worth the cost of
 * solving.
 *
 * Bones are processed root-first, because a bone's rotation is expressed
 * relative to its parent and the parent must already be in its final pose.
 */

/** Which bone follows which pair of domain joints. */
interface Segment {
  /** The bone to rotate. */
  readonly bone: string;
  /**
   * The bone whose rest offset defines this bone's forward direction. Named
   * explicitly because several bones have more than one child — `Spine2`
   * carries the neck and both shoulders, and only the neck should steer it.
   */
  readonly child: string;
  readonly from: JointName;
  readonly to: JointName;
}

/**
 * Root-first. `Spine1` and the shoulders are deliberately left at their rest
 * pose: the domain has no joints that correspond to them, and inventing
 * rotations for them would be guessing.
 */
const SEGMENTS: readonly Segment[] = [
  { bone: 'Spine', child: 'Spine1', from: 'pelvis', to: 'chest' },
  { bone: 'Spine2', child: 'Neck', from: 'chest', to: 'neck' },
  { bone: 'Neck', child: 'Head', from: 'neck', to: 'head' },

  { bone: 'LeftArm', child: 'LeftForeArm', from: 'shL', to: 'elL' },
  { bone: 'LeftForeArm', child: 'LeftHand', from: 'elL', to: 'wrL' },
  { bone: 'RightArm', child: 'RightForeArm', from: 'shR', to: 'elR' },
  { bone: 'RightForeArm', child: 'RightHand', from: 'elR', to: 'wrR' },

  { bone: 'LeftUpLeg', child: 'LeftLeg', from: 'hipL', to: 'knL' },
  { bone: 'LeftLeg', child: 'LeftFoot', from: 'knL', to: 'anL' },
  { bone: 'RightUpLeg', child: 'RightLeg', from: 'hipR', to: 'knR' },
  { bone: 'RightLeg', child: 'RightFoot', from: 'knR', to: 'anR' },
];

/** The bone the whole character hangs from. */
const ROOT_BONE = 'Hips';

interface PreparedSegment {
  /**
   * Typed as Object3D, not Bone: everything used here (`position`,
   * `quaternion`, `parent`, `updateMatrixWorld`) lives on Object3D, and
   * three's Bone is generic in a way that fights every call site.
   */
  readonly bone: THREE.Object3D;
  /** The bone's rest rotation, which every frame's result is composed onto. */
  readonly restQuaternion: THREE.Quaternion;
  /** Rest direction of the segment, in the bone's *parent* space. */
  readonly restDirection: THREE.Vector3;
  readonly from: JointName;
  readonly to: JointName;
}

export class GltfFighterRig implements FighterView {
  readonly group = new THREE.Group();

  private readonly segments: PreparedSegment[] = [];
  private readonly materials: THREE.MeshStandardMaterial[] = [];
  /**
   * Every mesh that carries facial morph targets, with the lookup from
   * blendshape name to slot. The Avaturn exports name their targets with the
   * ARKit names MediaPipe emits, so no translation is needed — the face just
   * follows.
   */
  private readonly faces: {
    dictionary: Record<string, number>;
    influences: number[];
  }[] = [];
  private readonly shadow: THREE.Mesh;

  // Scratch, reused every frame so a fight allocates nothing per bone.
  private readonly target = new THREE.Vector3();
  private readonly restDir = new THREE.Vector3();
  private readonly parentQuat = new THREE.Quaternion();
  private readonly groupQuat = new THREE.Quaternion();
  private readonly delta = new THREE.Quaternion();

  private flash = REST_GLOW;

  constructor(
    scene: THREE.Scene,
    private readonly fighter: Fighter,
    model: THREE.Object3D,
    options: {
      tint: number | null;
      /**
       * A faint emissive edge in the fighter's colour, to keep two bodies
       * readable against a dark arena. Pass null to leave the materials
       * exactly as exported — which is what a close-up of a face needs, since
       * any emissive flattens the shading that makes it look like skin.
       */
      rim: number | null;
    },
  ) {
    this.group.add(model);

    const bones = new Map<string, THREE.Object3D>();
    model.traverse((object) => {
      if (object.type === 'Bone') bones.set(object.name, object);
      if (object instanceof THREE.SkinnedMesh) {
        object.castShadow = true;
        object.frustumCulled = false; // a posed skin can leave its rest bounds

        // three's SkinnedMesh is generic over its material, so `.material`
        // arrives as `any`; narrowed once here rather than at each use.
        const skin = object as Partial<THREE.Mesh>;

        // Cloned per fighter. A skeleton clone shares its materials with the
        // original, so tinting one fighter would otherwise tint both — and in
        // a two-player match both are on screen at once.
        const cloned = materialsOf(skin.material).map((material) => {
          const copy = material.clone();
          if (copy instanceof THREE.MeshStandardMaterial) {
            // The colour multiplies the texture, so setting it tints the
            // model rather than flattening it.
            if (options.tint !== null) copy.color.setHex(options.tint);
            if (options.rim !== null) {
              copy.emissive = new THREE.Color(options.rim);
              copy.emissiveIntensity = REST_GLOW;
              this.materials.push(copy);
            }
          }
          return copy;
        });
        object.material = cloned.length === 1 ? (cloned[0] as THREE.Material) : cloned;

        const dictionary = object.morphTargetDictionary;
        const influences = object.morphTargetInfluences;
        if (dictionary && influences) this.faces.push({ dictionary, influences });
      }
    });

    // Sit the hips on the group's origin. The domain re-centres every pose on
    // the pelvis, so the two origins have to be the same point.
    const hips = bones.get(ROOT_BONE);
    if (hips) {
      const restHips = new THREE.Vector3();
      hips.getWorldPosition(restHips);
      model.position.y -= restHips.y;
    }

    for (const segment of SEGMENTS) {
      const bone = bones.get(segment.bone);
      const child = bones.get(segment.child);
      if (!bone || !child) continue;

      // `child.position` is the child's offset in this bone's own space, so
      // rotating it by the bone's rest rotation puts it in the parent's space
      // — the space the bone's own quaternion lives in.
      const restDirection = child.position
        .clone()
        .applyQuaternion(bone.quaternion)
        .normalize();
      if (restDirection.lengthSq() < 1e-8) continue;

      this.segments.push({
        bone,
        restQuaternion: bone.quaternion.clone(),
        restDirection,
        from: segment.from,
        to: segment.to,
      });
    }

    this.shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.42, 24),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.32 }),
    );
    this.shadow.rotation.x = -Math.PI / 2;

    scene.add(this.group);
    scene.add(this.shadow);
  }

  /**
   * Applies facial blendshape weights straight from the tracker.
   *
   * Eased rather than assigned: the face tracker is noisy frame to frame, and
   * copying it verbatim gives a character that twitches. Anything the model
   * does not have a target for is simply skipped.
   */
  setFace(weights: FaceReading | null): void {
    for (const face of this.faces) {
      for (const [name, slot] of Object.entries(face.dictionary)) {
        const wanted = weights?.[name] ?? 0;
        const current = face.influences[slot] ?? 0;
        face.influences[slot] = current + (wanted - current) * FACE_BLEND;
      }
    }
  }

  sync(dt: number): void {
    const { fighter } = this;
    this.group.position.set(fighter.position.x, fighter.position.y, fighter.position.z);
    // The same yaw the domain uses for hit detection.
    this.group.rotation.y = fighter.yaw;
    this.group.updateMatrixWorld(true);
    this.group.getWorldQuaternion(this.groupQuat);
    // Everything below is expressed in the group's space, which is the space
    // the domain pose is already in.
    this.groupQuat.invert();

    for (const segment of this.segments) {
      const from = fighter.pose[segment.from];
      const to = fighter.pose[segment.to];
      this.target.set(to.x - from.x, to.y - from.y, to.z - from.z);
      if (this.target.lengthSq() < 1e-8) continue;
      this.target.normalize();

      const parent = segment.bone.parent;
      if (!parent) continue;
      // The parent is already in its final pose for this frame, because
      // SEGMENTS runs root-first.
      parent.getWorldQuaternion(this.parentQuat);
      this.parentQuat.premultiply(this.groupQuat).invert();
      this.target.applyQuaternion(this.parentQuat);

      this.restDir.copy(segment.restDirection);
      this.delta.setFromUnitVectors(this.restDir, this.target);
      segment.bone.quaternion.copy(this.delta).multiply(segment.restQuaternion);
      segment.bone.updateMatrixWorld(true);
    }

    this.shadow.position.set(fighter.position.x, 0.03, fighter.position.z);

    // Pulse on being hit, matching the stick figure's behaviour.
    const wanted = fighter.hurtFor > 0 ? HIT_GLOW : REST_GLOW;
    this.flash += (wanted - this.flash) * Math.min(1, dt * 12);
    for (const material of this.materials) material.emissiveIntensity = this.flash;
  }

  /**
   * Releases only what this rig created.
   *
   * Emphatically *not* the model's geometry. `SkeletonUtils.clone` shares
   * geometry with the cached original — the same reason the materials have to
   * be cloned above — so disposing it here would pull the buffers out from
   * under the cache and every other clone of the same character. That is what
   * made the fighter vanish: the second rig disposed the geometry the first
   * had just been built on, and everything drawn afterwards was drawing
   * nothing. The cache owns the geometry and frees it in `CharacterModels`.
   */
  dispose(): void {
    this.group.removeFromParent();
    this.shadow.removeFromParent();
    this.shadow.geometry.dispose();
    (this.shadow.material as THREE.Material).dispose();
    // The cloned materials are ours, so those do go.
    for (const material of this.materials) material.dispose();
    this.segments.length = 0;
    this.materials.length = 0;
    this.faces.length = 0;
  }
}

/** A subtle rim at rest, a bright flare when hit. */
const REST_GLOW = 0.12;
/** How fast the face follows the tracker. Low, because the tracker is jumpy. */
const FACE_BLEND = 0.4;
const HIT_GLOW = 0.7;

function materialsOf(
  material: THREE.Material | THREE.Material[] | undefined,
): readonly THREE.Material[] {
  if (!material) return [];
  return Array.isArray(material) ? material : [material];
}
