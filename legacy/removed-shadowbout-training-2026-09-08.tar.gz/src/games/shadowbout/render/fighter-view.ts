/**
 * Something that shows a fighter.
 *
 * Two implementations: the original stick figure of spheres and cylinders,
 * and a skinned character. Both read the domain `Fighter` and neither can
 * write to it, so the choice is purely what the player looks at — the fight
 * itself is identical either way.
 */
export interface FighterView {
  /** Called once per rendered frame, after the simulation has settled. */
  sync(dt: number): void;
  /**
   * Facial blendshape weights, when the tracker supplies them and the model
   * has targets to drive. The stick figure has no face, so this is optional.
   */
  setFace?(weights: Readonly<Record<string, number>> | null): void;
  dispose(): void;
}
