import type { BoutPhase } from '@domain/fighting/bout.ts';
import type { FighterIndex, HitZone } from '@domain/fighting/events.ts';
import type { Triple } from '@domain/fighting/skeleton.ts';
import { JOINTS } from '@domain/fighting/skeleton.ts';

/**
 * The wire format.
 *
 * Two shapes, for the two channels:
 *
 *  - Pose frames are *binary*, on the unreliable channel. One frame is 104
 *    bytes: sixteen joints as quantised 16-bit integers, plus a few scalars.
 *    JSON would be roughly 900 bytes for the same information, and at 24
 *    frames a second that difference is the whole reason this is hand-packed.
 *
 *  - Everything else is JSON on the reliable channel, where clarity is worth
 *    more than bytes because these messages are rare.
 *
 * Nothing arriving over either channel is trusted. Every decoder validates
 * and returns null rather than throwing, because the far end is another
 * browser and a malformed frame must cost one frame, not the match.
 */

// ----------------------------------------------------------------- binary

// Bumped when the frame layout changes, so a client on the previous build
// has its frames rejected outright instead of silently misread.
const POSE_MAGIC = 0xa3;
/**
 * Local joint coordinates live within roughly ±1.6 metres of the hips.
 * 20000 units per metre puts the extremes at ±32000, just inside an int16,
 * with a resolution of 0.05 mm — far finer than the tracking behind it.
 */
const POSITION_SCALE = 20000;
const SCALAR_SCALE = 10000;

const FLAG_BLOCKING = 1 << 0;
const FLAG_DOWN = 1 << 1;

/** Header, then the joints, then the two knuckle offsets. */
export const POSE_FRAME_BYTES = 10 + (JOINTS.length + 2) * 3 * 2;

export interface PoseFrameMessage {
  readonly sequence: number;
  readonly joints: readonly Triple[];
  readonly strafe: number;
  readonly standingY: number;
  /** How far the player has turned, in radians. */
  readonly facing: number;
  /**
   * Wrist-to-knuckles offsets, left then right. Sent because the *host*
   * judges every hit, so it needs to know where the guest's fists actually
   * are — not where their wrists are.
   */
  readonly knuckles: readonly [Triple, Triple];
  readonly blocking: boolean;
  readonly down: boolean;
}

export function encodePoseFrame(frame: PoseFrameMessage): ArrayBuffer {
  const buffer = new ArrayBuffer(POSE_FRAME_BYTES);
  const view = new DataView(buffer);

  view.setUint8(0, POSE_MAGIC);
  view.setUint8(
    1,
    (frame.blocking ? FLAG_BLOCKING : 0) | (frame.down ? FLAG_DOWN : 0),
  );
  view.setUint16(2, frame.sequence & 0xffff);
  view.setInt16(4, quantise(frame.strafe, SCALAR_SCALE));
  view.setInt16(6, quantise(frame.standingY, SCALAR_SCALE));
  view.setInt16(8, quantise(frame.facing, SCALAR_SCALE));

  let offset = 10;
  for (let i = 0; i < JOINTS.length; i++) {
    const joint = frame.joints[i] ?? ZERO;
    view.setInt16(offset, quantise(joint[0], POSITION_SCALE));
    view.setInt16(offset + 2, quantise(joint[1], POSITION_SCALE));
    view.setInt16(offset + 4, quantise(joint[2], POSITION_SCALE));
    offset += 6;
  }
  for (const hand of frame.knuckles) {
    view.setInt16(offset, quantise(hand[0], POSITION_SCALE));
    view.setInt16(offset + 2, quantise(hand[1], POSITION_SCALE));
    view.setInt16(offset + 4, quantise(hand[2], POSITION_SCALE));
    offset += 6;
  }

  return buffer;
}

export function decodePoseFrame(data: ArrayBuffer): PoseFrameMessage | null {
  if (data.byteLength !== POSE_FRAME_BYTES) return null;
  const view = new DataView(data);
  if (view.getUint8(0) !== POSE_MAGIC) return null;

  const flags = view.getUint8(1);
  const joints: Triple[] = [];
  let offset = 10;
  for (let i = 0; i < JOINTS.length; i++) {
    joints.push([
      view.getInt16(offset) / POSITION_SCALE,
      view.getInt16(offset + 2) / POSITION_SCALE,
      view.getInt16(offset + 4) / POSITION_SCALE,
    ]);
    offset += 6;
  }

  const hand = (): Triple => {
    const point: Triple = [
      view.getInt16(offset) / POSITION_SCALE,
      view.getInt16(offset + 2) / POSITION_SCALE,
      view.getInt16(offset + 4) / POSITION_SCALE,
    ];
    offset += 6;
    return point;
  };

  return {
    sequence: view.getUint16(2),
    strafe: view.getInt16(4) / SCALAR_SCALE,
    standingY: view.getInt16(6) / SCALAR_SCALE,
    facing: view.getInt16(8) / SCALAR_SCALE,
    blocking: (flags & FLAG_BLOCKING) !== 0,
    down: (flags & FLAG_DOWN) !== 0,
    joints,
    knuckles: [hand(), hand()],
  };
}

/**
 * Sequence numbers wrap at 65536. A frame is newer than the last one if it is
 * within half the range ahead of it — the standard trick, and the reason a
 * wrap does not freeze the opponent for two seconds.
 */
export function isNewer(sequence: number, previous: number): boolean {
  return ((sequence - previous) & 0xffff) < 0x8000;
}

const ZERO: Triple = [0, 0, 0];

function quantise(value: number, scale: number): number {
  const scaled = Math.round(value * scale);
  return scaled < -32768 ? -32768 : scaled > 32767 ? 32767 : scaled;
}

// ------------------------------------------------------------------- JSON

/** A hit or knockout, flattened for the wire. */
export interface WireHit {
  readonly attacker: FighterIndex;
  readonly defender: FighterIndex;
  readonly damage: number;
  readonly blocked: boolean;
  readonly heavy: boolean;
  readonly zone: HitZone;
  readonly contact: Triple;
  readonly label: string;
}

/**
 * The host owns the fight. It sends snapshots and effects; the guest sends
 * its pose and its requests. Anything else is a protocol error and ignored.
 */
export type NetMessage =
  /** Sent once on connect: who you are and which character you picked. */
  | { readonly t: 'hello'; readonly name: string; readonly character: string }
  /** Authoritative match state, from the host. */
  | {
      readonly t: 'state';
      readonly hp: readonly [number, number];
      readonly wins: readonly [number, number];
      readonly round: number;
      readonly timeLeft: number;
      readonly phase: BoutPhase;
      readonly down: readonly [boolean, boolean];
    }
  /** Things that happened, so the guest can make the same noise and sparks. */
  | { readonly t: 'fx'; readonly hits: readonly WireHit[]; readonly knockout: FighterIndex | null }
  | { readonly t: 'announce'; readonly text: string; readonly holdMs: number }
  /** The host declaring a round over, so the guest never has to infer it. */
  | {
      readonly t: 'round';
      readonly winner: FighterIndex | null;
      readonly wins: readonly [number, number];
      readonly round: number;
      readonly matchOver: boolean;
    }
  /** Either side asking to start the next round. */
  | { readonly t: 'advance' }
  | { readonly t: 'bye' };

export const encodeMessage = (message: NetMessage): string => JSON.stringify(message);

/**
 * Parses a reliable-channel message, validating the fields each variant
 * actually uses. Returns null for anything unrecognised.
 */
export function decodeMessage(raw: string): NetMessage | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== 'object') return null;
  const message = parsed as Record<string, unknown>;

  switch (message['t']) {
    case 'hello': {
      const name = message['name'];
      const character = message['character'];
      if (typeof name !== 'string') return null;
      return {
        t: 'hello',
        name: name.slice(0, 40),
        character: typeof character === 'string' ? character.slice(0, 24) : '',
      };
    }

    case 'state': {
      const hp = pair(message['hp'], isFiniteNumber);
      const wins = pair(message['wins'], isFiniteNumber);
      const down = pair(message['down'], isBoolean);
      const round = message['round'];
      const timeLeft = message['timeLeft'];
      const phase = message['phase'];
      if (!hp || !wins || !down) return null;
      if (!isFiniteNumber(round) || !isFiniteNumber(timeLeft) || !isPhase(phase)) return null;
      return { t: 'state', hp, wins, down, round, timeLeft, phase };
    }

    case 'fx': {
      const hits = Array.isArray(message['hits'])
        ? message['hits'].map(toWireHit).filter((hit): hit is WireHit => hit !== null)
        : [];
      const knockout = message['knockout'];
      return {
        t: 'fx',
        hits,
        knockout: knockout === 0 || knockout === 1 ? knockout : null,
      };
    }

    case 'announce':
      return typeof message['text'] === 'string' && isFiniteNumber(message['holdMs'])
        ? { t: 'announce', text: message['text'].slice(0, 60), holdMs: message['holdMs'] }
        : null;

    case 'round': {
      const wins = pair(message['wins'], isFiniteNumber);
      const winner = message['winner'];
      if (!wins || !isFiniteNumber(message['round'])) return null;
      if (winner !== 0 && winner !== 1 && winner !== null) return null;
      return {
        t: 'round',
        winner,
        wins,
        round: message['round'],
        matchOver: message['matchOver'] === true,
      };
    }

    case 'advance':
      return { t: 'advance' };

    case 'bye':
      return { t: 'bye' };

    default:
      return null;
  }
}

const PHASES: readonly BoutPhase[] = [
  'waiting',
  'fighting',
  'settling',
  'round-over',
  'match-over',
];

const isPhase = (value: unknown): value is BoutPhase =>
  PHASES.some((phase) => phase === value);

const isFiniteNumber = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);

const isBoolean = (value: unknown): value is boolean => typeof value === 'boolean';

/** Validates a `[x, y, z]` from the wire, element by element. */
function toTriple(value: unknown): Triple | null {
  if (!Array.isArray(value) || value.length !== 3) return null;
  const parts = value as readonly unknown[];
  const x = parts[0];
  const y = parts[1];
  const z = parts[2];
  if (!isFiniteNumber(x) || !isFiniteNumber(y) || !isFiniteNumber(z)) return null;
  return [x, y, z];
}

function pair<T>(value: unknown, check: (item: unknown) => item is T): readonly [T, T] | null {
  if (!Array.isArray(value) || value.length !== 2) return null;
  const parts = value as readonly unknown[];
  const first = parts[0];
  const second = parts[1];
  return check(first) && check(second) ? [first, second] : null;
}

function toWireHit(value: unknown): WireHit | null {
  if (!value || typeof value !== 'object') return null;
  const hit = value as Record<string, unknown>;
  const attacker = hit['attacker'];
  const defender = hit['defender'];
  const contact = hit['contact'];
  const zone = hit['zone'];

  if (attacker !== 0 && attacker !== 1) return null;
  if (defender !== 0 && defender !== 1) return null;
  if (zone !== 'head' && zone !== 'body' && zone !== 'low') return null;
  const point = toTriple(contact);
  if (!point) return null;
  if (!isFiniteNumber(hit['damage'])) return null;

  return {
    attacker,
    defender,
    zone,
    contact: point,
    // Clamped: a peer claiming a 9000-damage jab gets a 40-damage jab, and
    // the host's own health numbers are authoritative regardless.
    damage: Math.max(0, Math.min(40, hit['damage'])),
    blocked: hit['blocked'] === true,
    heavy: hit['heavy'] === true,
    label: typeof hit['label'] === 'string' ? hit['label'].slice(0, 24) : 'hit',
  };
}
