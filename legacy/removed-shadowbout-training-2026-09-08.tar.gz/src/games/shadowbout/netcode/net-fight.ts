import type { Fighter } from '@domain/fighting/fighter.ts';
import { HOST_SEAT, type SeatIndex } from '@domain/lobby/match.ts';
import type { LoggerPort } from '@app/ports/logger.port.ts';
import type { PeerLinkPort } from '@app/ports/peer-link.port.ts';
import type { Listener, Unsubscribe } from '@app/ports/types.ts';
import {
  decodeMessage,
  decodePoseFrame,
  encodeMessage,
  encodePoseFrame,
  isNewer,
  type NetMessage,
  type PoseFrameMessage,
} from './protocol.ts';

/**
 * How often a pose goes out. The camera produces roughly 30 readings a second
 * and 24 is enough to look continuous, so this throttle mostly stops a
 * 144 Hz display from sending six times more data than a 24 Hz one for no
 * visible gain.
 */
const SEND_HZ = 24;
const SEND_INTERVAL = 1 / SEND_HZ;

/**
 * The network side of a fight: pose frames out, pose frames in, and the
 * reliable messages that carry the score.
 *
 * The host is authoritative. It runs the only copy of the rules that counts,
 * and the guest renders what it is told. That is a deliberate trade: it costs
 * the guest half a round trip of input latency, and it buys a match that
 * cannot disagree with itself about who won — which is the failure players
 * actually notice.
 */
export class NetFight {
  readonly isHost: boolean;

  private sequence = 0;
  private lastSequence = -1;
  private incoming: PoseFrameMessage | null = null;
  private sinceLastSend = 0;
  private readonly messageListeners = new Set<Listener<NetMessage>>();
  private readonly stop: Unsubscribe;
  private readonly log: LoggerPort;

  constructor(
    private readonly link: PeerLinkPort,
    seat: SeatIndex,
    logger: LoggerPort,
  ) {
    this.isHost = seat === HOST_SEAT;
    this.log = logger.scoped('netfight');

    this.stop = this.link.onData((payload) => {
      if (payload.channel === 'fast' && payload.data instanceof ArrayBuffer) {
        this.receivePose(payload.data);
        return;
      }
      if (payload.channel === 'sure' && typeof payload.data === 'string') {
        const message = decodeMessage(payload.data);
        if (!message) {
          this.log.log('debug', 'discarded a malformed message');
          return;
        }
        for (const listener of this.messageListeners) listener(message);
      }
    });
  }

  get latencyMs(): number | null {
    return this.link.latencyMs;
  }

  get connected(): boolean {
    return this.link.state === 'open';
  }

  onMessage(listener: Listener<NetMessage>): Unsubscribe {
    this.messageListeners.add(listener);
    return () => this.messageListeners.delete(listener);
  }

  send(message: NetMessage): void {
    this.link.send('sure', encodeMessage(message));
  }

  /**
   * Sends this browser's own fighter, at most `SEND_HZ` times a second.
   * Call once per frame with the frame's delta; the throttle is internal so
   * the game loop does not have to keep its own timer.
   */
  publishPose(fighter: Fighter, dt: number): void {
    this.sinceLastSend += dt;
    if (this.sinceLastSend < SEND_INTERVAL) return;
    this.sinceLastSend = 0;

    this.sequence = (this.sequence + 1) & 0xffff;
    this.link.send(
      'fast',
      encodePoseFrame({
        sequence: this.sequence,
        joints: fighter.snapshotPose(),
        strafe: fighter.strafe,
        standingY: fighter.position.y,
        facing: fighter.facing,
        knuckles: [
          [fighter.knuckles.wrL.x, fighter.knuckles.wrL.y, fighter.knuckles.wrL.z],
          [fighter.knuckles.wrR.x, fighter.knuckles.wrR.y, fighter.knuckles.wrR.z],
        ],
        blocking: fighter.blocking,
        down: fighter.down,
      }),
    );
  }

  /**
   * The newest pose that has arrived since this was last called, or null.
   *
   * Consuming it clears it, so a frame in which nothing arrived leaves the
   * remote fighter holding their last known pose rather than snapping to a
   * default — which is what makes a brief packet loss invisible.
   */
  takeRemotePose(): PoseFrameMessage | null {
    const frame = this.incoming;
    this.incoming = null;
    return frame;
  }

  dispose(): void {
    this.messageListeners.clear();
    this.stop();
  }

  private receivePose(data: ArrayBuffer): void {
    const frame = decodePoseFrame(data);
    if (!frame) {
      this.log.log('debug', 'discarded a malformed pose frame');
      return;
    }
    // The channel is unordered, so an older frame can arrive after a newer
    // one. Rendering it would jerk the opponent backwards in time.
    if (this.lastSequence >= 0 && !isNewer(frame.sequence, this.lastSequence)) return;
    this.lastSequence = frame.sequence;
    this.incoming = frame;
  }
}
