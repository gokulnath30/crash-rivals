/**
 * The fighters you can pick from.
 *
 * Adding one means adding an entry here and dropping a `.glb` next to the
 * others in `public/characters/`. Nothing else in the game needs to change:
 * the rig maps bones by name, and every model exported from Avaturn (or any
 * Mixamo-named rig) carries the same skeleton.
 *
 * The model is only ever a *skin*. Reach, damage and hit detection all come
 * from the domain's own skeleton, so choosing a character cannot make you
 * better at the game.
 */
export interface CharacterDefinition {
  readonly id: CharacterId;
  readonly name: string;
  /** One line, shown under the name on the select screen. */
  readonly blurb: string;
  /** Path to the model, relative to the deployed base. */
  readonly model: string;
  /**
   * Multiplied into the body material. `null` leaves the model exactly as it
   * was exported.
   */
  readonly tint: number | null;
  /** CSS colour for the select screen's highlight. */
  readonly accent: string;
}

export type CharacterId = 'vale' | 'shade' | 'ranger' | 'ranger-alt';

export const CHARACTERS: readonly CharacterDefinition[] = [
  {
    id: 'vale',
    name: 'Vale',
    blurb: 'Stands square, hits straight. The model as exported.',
    model: 'characters/fighter-a.glb',
    tint: null,
    accent: '#ff3f6e',
  },
  {
    id: 'shade',
    name: 'Shade',
    blurb: 'The same fighter, cast in cold light.',
    // Deliberately the same file. A second Avaturn export dropped in here
    // replaces it with no code change; until then the tint is what tells the
    // two apart.
    model: 'characters/fighter-a.glb',
    tint: 0x6fb7ff,
    accent: '#3fd0ff',
  },
  {
    id: 'ranger',
    name: 'Ranger',
    blurb: 'Detailed face and hands. 13 MB, worth the wait.',
    model: 'characters/trainer-a.glb',
    tint: null,
    accent: '#ffcf5c',
  },
  {
    id: 'ranger-alt',
    name: 'Ranger II',
    blurb: 'The same fighter, carrying the second reference action.',
    model: 'characters/trainer-b.glb',
    tint: null,
    accent: '#9d7bff',
  },
];

/**
 * What a fight starts with.
 *
 * The light export, on purpose. The detailed ones look better close up, but a
 * fight is viewed from across the arena where that detail does not read, and
 * they cost 13 MB against 2.3 — so the fight opens on the one that was already
 * good and the detailed pair stay a choice.
 */
export const DEFAULT_CHARACTER: CharacterId = 'vale';

/**
 * What the training space shows.
 *
 * Deliberately not `DEFAULT_CHARACTER`: that room exists to look closely at a
 * face, so it always uses the export that has a real one — a separate head
 * mesh with its own textures and 72 facial morph targets.
 */
export const TRAINING_CHARACTER: CharacterId = 'ranger';

export function findCharacter(id: string | null): CharacterDefinition {
  return (
    CHARACTERS.find((character) => character.id === id) ??
    CHARACTERS.find((character) => character.id === DEFAULT_CHARACTER) ??
    (CHARACTERS[0] as CharacterDefinition)
  );
}

/**
 * Versioned, so changing which character a fight opens on actually takes
 * effect. Without the bump, anyone who had already been given the detailed
 * export would keep it from their last session and never see the revert.
 */
const STORAGE_KEY = 'shadowbout.character.v2';

/** Remembers the pick, so it does not have to be made again every round. */
export function readSavedCharacter(): CharacterId {
  try {
    return findCharacter(localStorage.getItem(STORAGE_KEY)).id;
  } catch {
    return DEFAULT_CHARACTER;
  }
}

export function saveCharacter(id: CharacterId): void {
  try {
    localStorage.setItem(STORAGE_KEY, id);
  } catch {
    // Private browsing. The choice simply will not persist.
  }
}
