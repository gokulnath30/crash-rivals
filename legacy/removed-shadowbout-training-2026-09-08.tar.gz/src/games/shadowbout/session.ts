import { Bout } from '@domain/fighting/bout.ts';
import { applyHit, judgeContact, shakeFor, type Strike } from '@domain/fighting/combat.ts';
import {
  EventBuffer,
  otherFighter,
  type FightEvent,
  type FighterIndex,
} from '@domain/fighting/events.ts';
import { Fighter } from '@domain/fighting/fighter.ts';
import { detectGestureStrikes, scriptedStrike } from '@domain/fighting/gestures.ts';
import { RULES } from '@domain/fighting/moves.ts';
import { OpponentAi } from '@domain/fighting/opponent-ai.ts';
import { Vec3 } from '@domain/shared/vec3.ts';
import { HOST_SEAT, type SeatIndex } from '@domain/lobby/match.ts';
import { linkToHost, type GameContext, type GameHandle } from '@app/ports/game-runtime.port.ts';
import type { LinkState } from '@app/ports/peer-link.port.ts';
import type { PoseSourcePort, PoseStatus } from '@app/ports/pose-source.port.ts';
import { button } from '@ui/dom.ts';
import { openMicrophone } from '@adapters/pose/camera.ts';
import { FightAudio } from './audio-bridge.ts';
import {
  CHARACTERS,
  findCharacter,
  readSavedCharacter,
  saveCharacter,
  type CharacterId,
} from './characters.ts';
import { CharacterModels } from './render/character-model.ts';
import { GltfFighterRig } from './render/gltf-fighter-rig.ts';
import type { FighterView } from './render/fighter-view.ts';
import { KeyboardControls } from './controls/keyboard.ts';
import { Hud } from './hud.ts';
import { NetFight } from './netcode/net-fight.ts';
import type { NetMessage, WireHit } from './netcode/protocol.ts';
import { buildArena } from './render/arena.ts';
import { FighterRig } from './render/fighter-rig.ts';
import { Sparks } from './render/sparks.ts';
import { Stage } from './render/stage.ts';
import './shadowbout.css';

/** Longest frame the simulation will accept. A tab left in the background
 * resumes with a delta of several seconds, and integrating that in one step
 * teleports fists through people. */
const MAX_FRAME = 0.05;
/** How long both fighters must be in frame before the round starts. */
const CALIBRATION_SECONDS = 1.4;
/** How often the host tells the guest the score. */
const SNAPSHOT_HZ = 10;

const COLOURS: readonly [number, number] = [0xff3f6e, 0x3fd0ff];
const CSS_COLOURS: readonly [string, string] = ['#ff3f6e', '#3fd0ff'];
const BLOCKED_COLOUR = '#9fb4ff';

type Phase = 'menu' | 'calibrating' | 'fighting' | 'between';
type InputKind = 'camera' | 'keyboard';

/**
 * One playable session of Shadowbout.
 *
 * The layering, top to bottom: this class owns the loop and the wiring; the
 * `Fighter`, `Bout` and combat rules under `@domain/fighting` own what is
 * true; `render/`, `Hud` and `FightAudio` own how it looks and sounds; and
 * `NetFight` owns how it reaches the other player. Only this file knows about
 * more than one of those.
 *
 * Online play is host-authoritative. Seat 0 runs the rules and broadcasts;
 * seat 1 sends its body and renders what it is told. There is exactly one
 * place a hit is decided, so the two screens cannot disagree about the score.
 */
export class ShadowboutSession implements GameHandle {
  private readonly fighters: readonly [Fighter, Fighter];
  /**
   * What is on screen for each fighter. Starts as the stick figure so the
   * fight is playable the instant the camera is up, and is replaced by the
   * skinned character once its model has downloaded.
   */
  private readonly views: [FighterView, FighterView];
  private readonly models: CharacterModels;
  /** Which character each fighter is wearing. */
  private readonly chosen: [CharacterId, CharacterId];
  private readonly stage: Stage;
  private readonly sparks: Sparks;
  private readonly hud: Hud;
  private readonly audio: FightAudio;
  private readonly bout = new Bout();
  private readonly events = new EventBuffer();

  /** Which fighter this browser is playing. */
  private readonly self: FighterIndex;
  private readonly opponent: FighterIndex;
  private readonly ai: OpponentAi | null;
  private readonly net: NetFight | null;

  private keyboard: KeyboardControls | null = null;
  /** Held so the microphone can be released on the way out. */
  private micStream: MediaStream | null = null;
  private input: InputKind = 'camera';
  private phase: Phase = 'menu';
  private calibratedFor = 0;
  private bodiesInFrame = 0;
  private sinceSnapshot = 0;
  private lastFrameAt: number;
  private frameHandle: number | null = null;
  private stopped = false;
  private readonly detach: (() => void)[] = [];

  constructor(
    private readonly context: GameContext,
    private readonly pose: PoseSourcePort,
  ) {
    const online = context.online;
    /*
     * Shadowbout is a duel, so a room for it holds two and the seat index is
     * also the fighter index. `asFighter` is the one place that assumption is
     * written down: rooms can now be four wide, and if this game is ever put
     * in one of those it should fail here rather than quietly fight the wrong
     * body.
     */
    this.self = asFighter(online ? online.seat : HOST_SEAT);
    this.opponent = otherFighter(this.self);
    // A duel has exactly one connection: to the other fighter.
    const rival = online ? (linkToHost(online) ?? online.links.get(this.opponent) ?? null) : null;

    const names: [string, string] = ['', ''];
    names[this.self] = context.labels.self;
    names[this.opponent] = context.labels.opponent;

    this.fighters = [
      new Fighter({ name: names[0], side: -1 }),
      new Fighter({ name: names[1], side: 1 }),
    ];

    // Solo is the only mode with an opponent that needs thinking for.
    this.ai = context.mode === 'solo' ? new OpponentAi(this.opponent) : null;

    this.hud = new Hud(context.mount, { left: names[0], right: names[1] });
    // The guest looks in from the other side, so each player sees themselves
    // in the foreground while both browsers keep the same fighter numbering.
    this.hud.setSides(this.self);
    this.stage = new Stage(this.hud.canvas, { mirrored: this.self !== HOST_SEAT });
    buildArena(this.stage.scene);
    this.sparks = new Sparks(this.stage.scene);
    this.views = [
      new FighterRig(this.stage.scene, this.fighters[0], COLOURS[0]),
      new FighterRig(this.stage.scene, this.fighters[1], COLOURS[1]),
    ];
    this.models = new CharacterModels(context.logger);
    this.models.watchProgress((progress) => {
      this.hud.setLoading(describeProgress(progress));
    });

    const mine = readSavedCharacter();
    const theirs = CHARACTERS.find((c) => c.id !== mine)?.id ?? mine;
    this.chosen = [mine, mine];
    // Solo picks the other character for the opponent so the
    // two are told apart at a glance; online waits to be told what they chose.
    this.chosen[this.opponent] = theirs;
    this.audio = new FightAudio(context.audio);

    if (online && rival) {
      const net = new NetFight(rival, online.seat, context.logger);
      this.net = net;
      // Tell them who we are and what we are wearing. Sent immediately: the
      // link is already open by the time a session exists.
      net.send({ t: 'hello', name: context.labels.self, character: readSavedCharacter() });
      this.detach.push(
        net.onMessage((message) => {
          this.receive(message);
        }),
        rival.onStateChange((state: LinkState) => {
          if (state === 'closed' || state === 'failed') this.opponentLeft();
        }),
        // Their camera and voice, whenever the tracks turn up.
        rival.onRemoteMedia((stream: MediaStream) => {
          this.hud.showRival(stream);
        }),
      );
    } else {
      this.net = null;
    }

    this.detach.push(
      this.pose.onStatusChange((status) => {
        this.hud.setCameraNote(cameraNoteFor(status));
        // The tracking model is 6-13 MB with no progress events of its own,
        // so its own status line is the loading state.
        if (status.kind === 'starting') this.hud.setLoading(status.message);
        else if (status.kind === 'tracking') this.hud.setLoading(null);
      }),
    );

    this.lastFrameAt = context.clock.elapsed();
  }

  /** Shows the opening panel. Nothing runs until the player presses a button. */
  begin(): void {
    this.showMenu();
    this.loop();
  }

  stop(): void {
    if (this.stopped) return;
    this.stopped = true;
    if (this.frameHandle !== null) cancelAnimationFrame(this.frameHandle);
    for (const remove of this.detach.splice(0)) remove();

    this.net?.send({ t: 'bye' });
    this.net?.dispose();
    // The microphone is ours, unlike the camera, so we have to let it go.
    for (const track of this.micStream?.getTracks() ?? []) track.stop();
    this.micStream = null;
    this.keyboard?.dispose();
    this.pose.stop();
    this.context.audio.stopMusic(0.4);

    for (const view of this.views) view.dispose();
    this.models.dispose();
    this.sparks.dispose();
    this.stage.dispose();
    this.hud.dispose();
  }

  // ------------------------------------------------------------------ menus

  private showMenu(): void {
    this.phase = 'menu';
    const mode = this.context.mode;
    const body =
      mode === 'online-versus'
        ? 'Your rival is connected. Stand back so your hips and feet are in frame, and put your hands up.'
        : 'Stand about two metres back so your hips and feet are in frame. Turn your body and your fighter turns too. Shade will not wait for you.';

    const actions = [
      button({
        label: 'Start the camera',
        onClick: () => {
          void this.launch('camera');
        },
      }),
    ];
    // Keyboard is a fallback for one player, so it is offered only where a
    // single set of keys makes sense.
    if (mode === 'solo') {
      actions.push(
        button({
          label: 'Play with keys instead',
          tone: 'ghost',
          onClick: () => {
            void this.launch('keyboard');
          },
        }),
      );
    }
    actions.push(button({ label: 'Back to the store', tone: 'ghost', onClick: this.context.exit }));

    this.hud.showStart({ body, actions });
    this.hud.showCharacterChoice(CHARACTERS, this.chosen[this.self], (id) => {
      this.chosen[this.self] = id;
      saveCharacter(id);
      // Swap the model straight away, so the pick is visible behind the panel
      // rather than being a promise about the next round.
      void this.dressFighter(this.self);
      this.net?.send({ t: 'hello', name: this.context.labels.self, character: id });
    });
  }

  private async launch(input: InputKind): Promise<void> {
    // Audio needs a user gesture, and this click is one.
    await this.context.audio.unlock();
    this.input = input;
    // Started here, before the camera, so the character is downloading while
    // permission is being granted. Called once: two passes raced each other,
    // and the loser disposed the winner's rig.
    void this.dressFighters();

    if (input === 'keyboard') {
      this.keyboard = new KeyboardControls((move) => {
        if (this.phase !== 'fighting') return;
        const me = this.fighters[this.self];
        if (me.throwMove(move)) {
          this.events.emit({ kind: 'move-thrown', attacker: this.self, move });
        }
      });
      this.hud.setCameraNote(this.keyboard.hint);
      this.hud.hidePanels();
      this.startRound();
      return;
    }

    this.hud.setStartStatus('Asking for the camera…');
    /*
     * One body, always. Two-on-one-camera play is gone, and asking the tracker
     * for a second body is not free: the pose model that can see two people is
     * the *only* one that can, and it is the one without hands or a face. One
     * body means the holistic tracker, which is what makes a fist readable.
     */
    const started = await this.pose.start(1);
    if (this.stopped) return;

    if (!started.ok) {
      this.hud.setStartStatus(started.error.message);
      this.context.audio.play('ui-error');
      return;
    }

    const video = this.pose.videoElement();
    if (video) this.hud.attachCamera(video);

    void this.openCall();

    this.hud.setStartStatus('');
    this.hud.hidePanels();
    this.hud.forgetAnnouncement();
    this.phase = 'calibrating';
    this.calibratedFor = 0;
  }

  /**
   * Everything that must be true before a round can run.
   *
   * Shared by the first round and every one after it. It used to be written
   * out twice, and the copy behind "Next round" was missing `hidePanels` — so
   * the fight resumed correctly underneath a result panel that never went
   * away. One copy, no drift.
   */
  private resetForRound(): void {
    for (const fighter of this.fighters) fighter.reset();
    this.hud.resetHealth();
    this.hud.hidePanels();
    this.ai?.reset();
    this.phase = 'fighting';
  }

  /**
   * Turns an online match into a call: your camera and voice go to the other
   * player, theirs come back.
   *
   * Best effort by design. A refused microphone, or none at all, costs the
   * voice and nothing else — the fight does not depend on it. The camera is
   * the one the tracker already opened, because a device generally will not
   * open twice.
   */
  private async openCall(): Promise<void> {
    const online = this.context.online;
    if (!online) return;

    const camera = this.pose.mediaStream();
    const outgoing = new MediaStream();
    for (const track of camera?.getVideoTracks() ?? []) outgoing.addTrack(track);

    const microphone = await openMicrophone();
    if (this.stopped) return;
    if (microphone.ok) {
      for (const track of microphone.value.getAudioTracks()) outgoing.addTrack(track);
      this.micStream = microphone.value;
    } else {
      this.context.logger.log('info', 'playing without voice', microphone.error);
      this.hud.setLoading(microphone.error.message);
      // Clear the notice after a moment; it is information, not a failure.
      setTimeout(() => {
        if (!this.stopped) this.hud.setLoading(null);
      }, 4000);
    }

    if (outgoing.getTracks().length === 0) return;
    const rival = linkToHost(online) ?? online.links.get(this.opponent);
    if (!rival) return;
    rival.attachLocalMedia(outgoing);
    this.hud.showCallControls({
      onToggleMic: (muted) => {
        rival.setMicrophoneMuted(muted);
      },
      onToggleCam: (muted) => {
        rival.setCameraMuted(muted);
      },
    });
  }

  private startRound(): void {
    this.resetForRound();
    this.events.emitAll(this.bout.beginRound());
  }

  /**
   * Puts both fighters in their chosen characters. Failures are not fatal:
   * a model that will not download leaves that fighter as the stick figure,
   * and the match carries on.
   */
  private async dressFighters(): Promise<void> {
    await Promise.all(BOTH.map((index) => this.dressFighter(index)));
  }

  private async dressFighter(index: FighterIndex): Promise<void> {
    const character = findCharacter(this.chosen[index]);
    const loaded = await this.models.instance(character);
    // The player may have left, or picked again, while this was downloading.
    if (this.stopped) return;
    if (!loaded.ok) {
      this.hud.setStartStatus(loaded.error.message);
      return;
    }
    if (findCharacter(this.chosen[index]).id !== character.id) return;

    this.views[index].dispose();
    this.views[index] = new GltfFighterRig(
      this.stage.scene,
      this.fighters[index],
      loaded.value.scene,
      { tint: character.tint, rim: COLOURS[index] },
    );
  }

  // ------------------------------------------------------------------- loop

  private loop(): void {
    const step = (): void => {
      if (this.stopped) return;
      this.frameHandle = requestAnimationFrame(step);
      this.frame();
    };
    this.frameHandle = requestAnimationFrame(step);
  }

  private frame(): void {
    const now = this.context.clock.elapsed();
    const wall = Math.min(MAX_FRAME, Math.max(0, (now - this.lastFrameAt) / 1000));
    this.lastFrameAt = now;

    this.readCamera();

    // Hitstop slows the whole simulation, so a hit lands with weight rather
    // than just flashing.
    const dt = this.bout.scaleFrameTime(wall);

    if (this.phase === 'calibrating') this.updateCalibration(wall);
    if (this.phase === 'fighting' || this.phase === 'between') this.updateFight(dt, now);

    this.receiveRemotePose();
    this.animateUntracked(dt, now);

    for (const fighter of this.fighters) fighter.integrate(dt);
    for (const index of BOTH) this.views[index].sync(dt);

    this.sparks.update(dt);
    this.presentEvents();
    this.paintHud();

    if (this.net && this.phase !== 'menu') {
      this.net.publishPose(this.fighters[this.self], wall);
      if (this.isAuthority) this.broadcastSnapshot(wall);
    }

    const midX = (this.fighters[0].position.x + this.fighters[1].position.x) / 2;
    this.stage.render(dt, midX);
  }

  private get isAuthority(): boolean {
    // Offline, this browser is the only authority there is.
    return this.net === null || this.net.isHost;
  }

  private readCamera(): void {
    if (this.input !== 'camera') return;
    const frame = this.pose.read();
    if (!frame) return;

    this.bodiesInFrame = frame.bodies.length;
    this.hud.drawOverlay(frame.forOverlay);

    const mine = frame.bodies[0];
    if (!mine) return;
    this.fighters[this.self].applyBodyReading(mine);
    // Your own face only. Sending 52 blendshape weights 24 times a second
    // would cost more bandwidth than the entire rest of the protocol, for a
    // face the opponent sees from across an arena.
    this.views[this.self].setFace?.(mine.face ?? null);
  }

  private updateCalibration(dt: number): void {
    this.calibratedFor = this.bodiesInFrame >= 1 ? this.calibratedFor + dt : 0;
    this.hud.announceOnce(
      this.calibratedFor === 0
        ? 'Get in frame'
        : 'Ready',
    );
    if (this.calibratedFor > CALIBRATION_SECONDS) this.startRound();
  }

  private updateFight(dt: number, now: number): void {
    if (this.input === 'keyboard' && this.keyboard) {
      this.keyboard.apply(this.fighters[this.self], dt);
    }

    if (!this.isAuthority) {
      // The guest simulates nothing that decides the match; the host's
      // snapshots are the truth and its `fx` messages are the spectacle.
      return;
    }

    if (this.bout.isFighting) {
      if (this.ai) {
        this.events.emitAll(this.ai.update(this.fighters[this.opponent], this.fighters[this.self], dt, now));
      }
      this.resolveStrikes();
    }

    this.events.emitAll(
      this.bout.tick(dt, [this.fighters[0].hp, this.fighters[1].hp]),
    );
  }

  /**
   * Turns intent into damage. Body-tracked fighters are read from their pose;
   * scripted ones (the AI, or a keyboard player) land on their animation's
   * contact frame.
   */
  private resolveStrikes(): void {
    for (const index of BOTH) {
      const attacker = this.fighters[index];
      const defender = this.fighters[otherFighter(index)];
      if (defender.down || attacker.down) continue;

      const scripted = this.isScripted(index);
      const strikes: readonly Strike[] = scripted
        ? withoutNull(scriptedStrike(attacker))
        : detectGestureStrikes(attacker);

      for (const strike of strikes) {
        this.land(index, strike);
      }
    }
  }

  private land(attackerIndex: FighterIndex, strike: Strike): void {
    const attacker = this.fighters[attackerIndex];
    const defender = this.fighters[otherFighter(attackerIndex)];
    const judgement = judgeContact(attacker, defender, strike);

    if (!judgement.landed) {
      this.events.emit({ kind: 'whiff', attacker: attackerIndex, at: judgement.at, hint: judgement.hint });
      return;
    }

    const hits = applyHit({ attacker, defender, attackerIndex, strike, judgement });
    this.events.emitAll(hits);

    // Give the AI a beat after it connects, rather than letting it stun-lock.
    if (this.ai && attackerIndex === this.opponent) this.ai.holdAfterLanding();

    for (const event of hits) {
      if (event.kind === 'knockout') this.events.emitAll(this.bout.recordKnockout(event.loser));
    }
  }

  /** Is this fighter driven by an animation rather than by a live body? */
  private isScripted(index: FighterIndex): boolean {
    if (index === this.self) return this.input === 'keyboard';
    if (this.ai) return true;
    // A networked or same-screen opponent is a real body.
    return false;
  }

  /**
   * A fighter whose pose is not coming from a body this frame needs the
   * animation blender — and so does a tracked one who is staggered or downed,
   * so the flinch and the knockdown actually play.
   */
  private animateUntracked(dt: number, now: number): void {
    for (const index of BOTH) {
      const fighter = this.fighters[index];
      const bodyDriven =
        !this.isScripted(index) && fighter.tracked && fighter.hurtFor <= 0 && !fighter.down;
      if (!bodyDriven) fighter.blendAnimation(dt, now);
    }
  }

  private receiveRemotePose(): void {
    const frame = this.net?.takeRemotePose();
    if (!frame) return;
    this.fighters[this.opponent].adoptPose({
      joints: frame.joints,
      strafe: frame.strafe,
      standingY: frame.standingY,
      facing: frame.facing,
      knuckles: { left: frame.knuckles[0], right: frame.knuckles[1] },
      blocking: frame.blocking,
    });
  }

  // ------------------------------------------------------------ presentation

  /** Drains the event buffer into sound, sparks, numbers and the HUD. */
  private presentEvents(): void {
    const events = this.events.drain();
    if (events.length === 0) return;

    this.audio.handle(events, (index) => this.panOf(index));

    const outgoing: WireHit[] = [];
    let knockout: FighterIndex | null = null;

    for (const event of events) {
      switch (event.kind) {
        case 'hit':
          this.showHit(event);
          if (this.net && this.isAuthority) {
            outgoing.push({
              attacker: event.attacker,
              defender: event.defender,
              damage: event.damage,
              blocked: event.blocked,
              heavy: event.heavy,
              zone: event.zone,
              contact: [event.contact.x, event.contact.y, event.contact.z],
              label: event.label,
            });
          }
          break;

        case 'whiff':
          this.sparks.burst(event.at, 0x6b5aa8, 5, 1.4);
          if (event.attacker === this.self) this.hud.setHint(this.self, event.hint);
          break;

        case 'knockout':
          knockout = event.loser;
          break;

        case 'announce':
          this.hud.announce(event.text, event.holdMs);
          if (this.net && this.isAuthority) {
            this.net.send({ t: 'announce', text: event.text, holdMs: event.holdMs });
          }
          break;

        case 'round-end':
          this.showResult(event.winner, event.matchOver, event.wins);
          if (this.net && this.isAuthority) {
            this.net.send({
              t: 'round',
              winner: event.winner,
              wins: [event.wins[0], event.wins[1]],
              round: event.round,
              matchOver: event.matchOver,
            });
          }
          break;

        case 'round-start':
        case 'time-up':
        case 'move-thrown':
        case 'guard-raised':
          break;
      }
    }

    if (this.net && this.isAuthority && (outgoing.length > 0 || knockout !== null)) {
      this.net.send({ t: 'fx', hits: outgoing, knockout });
    }
  }

  private showHit(event: Extract<FightEvent, { kind: 'hit' }>): void {
    this.sparks.burst(
      event.contact,
      event.blocked ? 0x9fb4ff : 0xffcf5c,
      event.blocked ? 8 : 16,
      event.blocked ? 2.2 : 3.8,
    );
    this.hud.damageNumber(
      this.stage.toScreen(event.contact),
      event.damage,
      event.blocked ? BLOCKED_COLOUR : CSS_COLOURS[event.attacker],
    );
    this.hud.impactFlash(event.blocked);
    this.stage.addShake(shakeFor(event.blocked, event.heavy));
    this.bout.registerImpact(event.blocked, event.heavy);
    if (event.attacker === this.self) this.hud.setHint(this.self, hintFor(event.zone, event.label));
  }

  private paintHud(): void {
    for (const index of BOTH) this.hud.setHealth(index, this.fighters[index].healthFraction);
    this.hud.setClock(this.bout.timeLeft);
    this.hud.setWins([this.bout.wins[0], this.bout.wins[1]]);
    this.hud.setGuarding(this.fighters[this.self].blocking);
    if (this.net) this.hud.setLatency(this.net.latencyMs);
  }

  /** Where a fighter sits in the stereo field, from where they are on screen. */
  private panOf(index: FighterIndex): number {
    const x = this.fighters[index].position.x;
    const mirrored = this.self === HOST_SEAT ? 1 : -1;
    return Math.max(-1, Math.min(1, (x * mirrored) / 1.2));
  }

  private showResult(
    winner: FighterIndex | null,
    matchOver: boolean,
    wins: readonly [number, number],
  ): void {
    this.phase = 'between';
    const iWon = winner === this.self;
    const title = matchOver
      ? iWon
        ? 'You win'
        : 'You lose'
      : `Round ${this.bout.round}`;
    const line = matchOver
      ? `Final score ${wins[this.self]}–${wins[this.opponent]}.`
      : winner === null
        ? 'Level on health. That round goes again.'
        : `${this.fighters[winner].name} takes the round. ${wins[this.self]}–${wins[this.opponent]}.`;

    const actions: HTMLElement[] = [];
    if (this.isAuthority) {
      actions.push(
        button({
          label: matchOver ? 'Fight again' : 'Next round',
          onClick: () => {
            this.advance();
          },
        }),
      );
    } else {
      actions.push(
        button({
          label: matchOver ? 'Ask for a rematch' : 'Ready',
          onClick: () => {
            this.net?.send({ t: 'advance' });
            this.hud.announce('Waiting for your rival', 900);
          },
        }),
      );
    }
    actions.push(button({ label: 'Leave', tone: 'ghost', onClick: this.context.exit }));

    this.hud.showResult({ title, line, actions });
  }

  private advance(): void {
    this.resetForRound();
    this.events.emitAll(this.bout.advance());
  }

  // ---------------------------------------------------------------- network

  private receive(message: NetMessage): void {
    switch (message.t) {
      case 'state':
        // Only the guest takes state; a host receiving one is a bug or a
        // hostile peer, and either way it is not the truth.
        if (this.isAuthority) return;
        this.applySnapshot(message);
        break;

      case 'fx':
        if (this.isAuthority) return;
        for (const hit of message.hits) this.replayHit(hit);
        if (message.knockout !== null) {
          this.fighters[message.knockout].putDown();
          this.context.audio.play('knockout', { intensity: 1 });
        }
        break;

      case 'announce':
        if (!this.isAuthority) this.hud.announce(message.text, message.holdMs);
        break;

      case 'round':
        if (this.isAuthority) return;
        this.bout.wins[0] = message.wins[0];
        this.bout.wins[1] = message.wins[1];
        this.bout.round = message.round;
        this.showResult(message.winner, message.matchOver, message.wins);
        break;

      case 'advance':
        // Either side can ask; only the host actually starts the round.
        if (this.isAuthority && this.phase === 'between') this.advance();
        break;

      case 'bye':
        this.opponentLeft();
        break;

      case 'hello': {
        this.context.audio.play('peer-joined');
        const theirs = findCharacter(message.character).id;
        if (theirs !== this.chosen[this.opponent]) {
          this.chosen[this.opponent] = theirs;
          void this.dressFighter(this.opponent);
        }
        break;
      }
    }
  }

  private applySnapshot(message: Extract<NetMessage, { t: 'state' }>): void {
    for (const index of BOTH) {
      this.fighters[index].hp = Math.max(0, Math.min(RULES.maxHp, message.hp[index]));
      if (message.down[index]) this.fighters[index].putDown();
    }
    this.bout.wins[0] = message.wins[0];
    this.bout.wins[1] = message.wins[1];
    this.bout.round = message.round;
    this.bout.timeLeft = message.timeLeft;

    // The result panel is driven by the explicit 'round' message rather than
    // inferred from a snapshot; this only has to notice the round restarting.
    if (message.phase === 'fighting' && this.phase !== 'fighting') {
      this.hud.hidePanels();
      this.hud.resetHealth();
      this.phase = 'fighting';
    }
    this.bout.phase = message.phase;
  }

  private broadcastSnapshot(dt: number): void {
    this.sinceSnapshot += dt;
    if (this.sinceSnapshot < 1 / SNAPSHOT_HZ) return;
    this.sinceSnapshot = 0;
    this.net?.send({
      t: 'state',
      hp: [this.fighters[0].hp, this.fighters[1].hp],
      wins: [this.bout.wins[0], this.bout.wins[1]],
      round: this.bout.round,
      timeLeft: this.bout.timeLeft,
      phase: this.bout.phase,
      down: [this.fighters[0].down, this.fighters[1].down],
    });
  }

  /** Re-creates the guest's sparks, sound and stagger from a host's report. */
  private replayHit(hit: WireHit): void {
    const contact = new Vec3(hit.contact[0], hit.contact[1], hit.contact[2]);
    const defender = this.fighters[hit.defender];
    if (!hit.blocked) defender.stagger(hit.damage);
    else defender.knockback = 0.05;

    this.audio.handle(
      [
        {
          kind: 'hit',
          attacker: hit.attacker,
          defender: hit.defender,
          damage: hit.damage,
          blocked: hit.blocked,
          heavy: hit.heavy,
          zone: hit.zone,
          contact,
          label: hit.label,
        },
      ],
      (index) => this.panOf(index),
    );

    this.sparks.burst(
      contact,
      hit.blocked ? 0x9fb4ff : 0xffcf5c,
      hit.blocked ? 8 : 16,
      hit.blocked ? 2.2 : 3.8,
    );
    this.hud.damageNumber(
      this.stage.toScreen(contact),
      hit.damage,
      hit.blocked ? BLOCKED_COLOUR : CSS_COLOURS[hit.attacker],
    );
    this.hud.impactFlash(hit.blocked);
    this.stage.addShake(shakeFor(hit.blocked, hit.heavy));
    this.bout.registerImpact(hit.blocked, hit.heavy);
  }

  private opponentLeft(): void {
    if (this.phase === 'menu') return;
    this.phase = 'between';
    this.context.audio.play('peer-left');
    this.hud.showResult({
      title: 'Rival left',
      line: 'The connection to the other player is gone.',
      actions: [button({ label: 'Back to the store', onClick: this.context.exit })],
    });
  }
}

const BOTH: readonly FighterIndex[] = [0, 1];

const withoutNull = <T>(value: T | null): readonly T[] => (value === null ? [] : [value]);

function hintFor(zone: 'head' | 'body' | 'low', label: string): string {
  if (zone === 'head') return 'head shot';
  if (zone === 'low') return 'body shot';
  return label;
}

/** The corner chip while a model downloads. Null once nothing is pending. */
function describeProgress(progress: {
  name: string;
  fraction: number | null;
  loadedBytes: number;
  done: boolean;
}): string | null {
  if (progress.done) return null;
  if (progress.fraction !== null) {
    return `Loading ${progress.name}… ${Math.round(progress.fraction * 100)}%`;
  }
  return `Loading ${progress.name}… ${(progress.loadedBytes / 1048576).toFixed(1)} MB`;
}

/** The line under the camera preview. */
function cameraNoteFor(status: PoseStatus): string {
  switch (status.kind) {
    case 'off':
      return 'camera off';
    case 'starting':
      return status.message;
    case 'tracking':
      return status.bodies > 1 ? 'tracking both fighters' : 'tracking you';
    case 'no-body':
      return 'no body in frame — step back';
    case 'failed':
      return status.message;
  }
}

/**
 * A seat index, checked against being a fighter index.
 *
 * `FighterIndex` is `0 | 1` because a bout has two corners, while a room's
 * seat is now any number up to four. Shadowbout declares two seats, so the two
 * always coincide — and this is where that is asserted rather than assumed, so
 * putting the fight in a wider room fails loudly instead of aiming punches at
 * a fighter that does not exist.
 */
function asFighter(seat: SeatIndex): FighterIndex {
  if (seat !== 0 && seat !== 1) {
    throw new Error(`Shadowbout is a duel; seat ${seat} cannot fight in it.`);
  }
  return seat;
}
