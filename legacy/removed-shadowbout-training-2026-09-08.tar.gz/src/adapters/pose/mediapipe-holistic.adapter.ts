import type { BodyReading, HandReading } from '@domain/fighting/body-reading.ts';
import { fail, failure, ok, type Result } from '@domain/shared/result.ts';
import type { LoggerPort } from '@app/ports/logger.port.ts';
import type { PoseFrame, PoseSourcePort, PoseStatus } from '@app/ports/pose-source.port.ts';
import type { Listener, Unsubscribe } from '@app/ports/types.ts';
import { TASKS_BASE, openCamera } from './camera.ts';

/**
 * Body tracking with MediaPipe's *holistic* landmarker: pose, both hands and
 * the face in one pass.
 *
 * What the extra two buy, concretely:
 *
 *  - **Hands.** The pose model stops at the wrist, so a punch was aimed from
 *    the wrist — the better part of a hand short of where it actually lands.
 *    The hand landmarks give the knuckles, and whether the hand is a fist at
 *    all.
 *  - **Face.** It emits ARKit blendshape weights, and the Avaturn exports use
 *    those exact names for their morph targets, so the character's face
 *    follows yours with no mapping in between.
 *
 * The cost is that it tracks exactly one person — there is no `numPoses`
 * option — and the model is 13 MB against the pose model's 6. So the store
 * keeps both, and `AdaptivePoseSource` picks.
 */
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/latest/holistic_landmarker.task';

type Triple = readonly [number, number, number];

interface Landmark {
  x: number;
  y: number;
  z: number;
  /** How sure the model is that it actually saw this point. */
  visibility?: number;
}

interface Category {
  categoryName?: string;
  displayName?: string;
  score: number;
}

interface HolisticResult {
  poseWorldLandmarks: Landmark[][];
  poseLandmarks: Landmark[][];
  leftHandWorldLandmarks: Landmark[][];
  rightHandWorldLandmarks: Landmark[][];
  faceBlendshapes: { categories: Category[] }[];
}

interface Holistic {
  detectForVideo(video: HTMLVideoElement, timestampMs: number): HolisticResult | undefined;
  close(): void;
}

interface VisionModule {
  FilesetResolver: { forVisionTasks(base: string): Promise<unknown> };
  HolisticLandmarker: { createFromOptions(fileset: unknown, options: unknown): Promise<Holistic> };
}

interface Attempt {
  readonly delegate: 'GPU' | 'CPU';
  readonly blendshapes: boolean;
}

/**
 * Tried in order until one actually infers.
 *
 * The face is worth more than the delegate here, so a working CPU
 * configuration beats a GPU one that cannot report expressions. The last
 * entry is the bare minimum: pose and hands, however it can get them.
 */
const ATTEMPTS: readonly Attempt[] = [
  { delegate: 'GPU', blendshapes: true },
  { delegate: 'CPU', blendshapes: true },
  { delegate: 'GPU', blendshapes: false },
  { delegate: 'CPU', blendshapes: false },
];

const describe = (attempt: Attempt): string =>
  `${attempt.delegate}${attempt.blendshapes ? ' with faces' : ' without faces'}`;

/** Hand landmark indices. 0 is the wrist; 5 and 9 are the two lead knuckles. */
const HAND = { wrist: 0, indexKnuckle: 5, middleKnuckle: 9, tips: [4, 8, 12, 16, 20] } as const;

export class MediaPipeHolisticSource implements PoseSourcePort {
  status: PoseStatus = { kind: 'off' };

  private video: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  private landmarker: Holistic | null = null;
  private blendshapes = false;
  private stopped = false;
  private latest: PoseFrame | null = null;
  private lastVideoTime = -1;
  private readonly statusListeners = new Set<Listener<PoseStatus>>();
  private readonly log: LoggerPort;

  constructor(logger: LoggerPort) {
    this.log = logger.scoped('holistic');
  }

  async start(): Promise<Result<void>> {
    if (this.landmarker) return ok(undefined);

    this.setStatus({ kind: 'starting', message: 'Asking for the camera…' });
    const camera = await openCamera();
    if (!camera.ok) {
      this.setStatus({ kind: 'failed', message: camera.error.message });
      return camera;
    }
    this.stream = camera.value.stream;
    this.video = camera.value.video;

    this.setStatus({ kind: 'starting', message: 'Loading the tracking model (13 MB)…' });
    let vision: VisionModule;
    let fileset: unknown;
    try {
      vision = (await import(/* @vite-ignore */ `${TASKS_BASE}/vision_bundle.mjs`)) as VisionModule;
      fileset = await vision.FilesetResolver.forVisionTasks(`${TASKS_BASE}/wasm`);
    } catch (error: unknown) {
      this.log.log('error', 'could not load the vision bundle', error);
      const message = 'Could not load the tracking model. Check the connection and retry.';
      this.setStatus({ kind: 'failed', message });
      this.releaseCamera();
      return fail(failure('unavailable', message));
    }

    // Wait for a frame, because a configuration can only be *proved* to work
    // by running one.
    await this.waitForFrame();

    for (const attempt of ATTEMPTS) {
      if (this.stopped) return fail(failure('unavailable', 'Tracking was cancelled.'));
      const candidate = await this.tryAttempt(vision, fileset, attempt);
      if (!candidate) continue;
      this.landmarker = candidate;
      this.blendshapes = attempt.blendshapes;
      this.log.log(
        'info',
        `tracking on ${attempt.delegate}, face ${attempt.blendshapes ? 'on' : 'off'}`,
      );
      this.setStatus({ kind: 'tracking', bodies: 0 });
      return ok(undefined);
    }

    const message = 'This device cannot run full-body tracking.';
    this.setStatus({ kind: 'failed', message });
    this.releaseCamera();
    return fail(failure('unavailable', message));
  }

  /** True once a configuration that reports facial blendshapes is running. */
  get facesTracked(): boolean {
    return this.blendshapes;
  }

  /**
   * Builds one configuration and *runs a frame through it* before accepting it.
   *
   * Creation is not proof. Face blendshapes on the GPU delegate construct
   * perfectly happily and then fail on every single inference with
   * `UNIMPLEMENTED` — which presents as a model that downloads and a camera
   * that never tracks anything, with no error at the point of setup to
   * explain it. So each candidate has to earn its place by actually working.
   */
  private async tryAttempt(
    vision: VisionModule,
    fileset: unknown,
    attempt: Attempt,
  ): Promise<Holistic | null> {
    let candidate: Holistic;
    try {
      candidate = await vision.HolisticLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate: attempt.delegate },
        runningMode: 'VIDEO',
        outputFaceBlendshapes: attempt.blendshapes,
      });
    } catch (error: unknown) {
      this.log.log('info', `holistic ${describe(attempt)} could not be created`, error);
      return null;
    }

    const video = this.video;
    if (!video) return candidate;
    try {
      candidate.detectForVideo(video, performance.now());
      return candidate;
    } catch (error: unknown) {
      this.log.log('warn', `holistic ${describe(attempt)} cannot infer; trying the next`, error);
      try {
        candidate.close();
      } catch {
        // Already broken; nothing useful to do about a failed close.
      }
      return null;
    }
  }

  /** Gives the camera a moment to produce a frame worth testing against. */
  private async waitForFrame(): Promise<void> {
    const video = this.video;
    if (!video) return;
    for (let i = 0; i < 40 && video.readyState < 2; i++) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }

  read(): PoseFrame | null {
    const video = this.video;
    const landmarker = this.landmarker;
    if (!video || !landmarker || video.readyState < 2) return null;
    if (video.currentTime === this.lastVideoTime) return null;
    this.lastVideoTime = video.currentTime;

    let result: HolisticResult | undefined;
    try {
      result = landmarker.detectForVideo(video, performance.now());
    } catch (error: unknown) {
      this.log.log('debug', 'inference failed for a frame', error);
      return null;
    }

    const world = result?.poseWorldLandmarks[0];
    const normalised = result?.poseLandmarks[0];
    if (!result || !world || !normalised) {
      if (this.status.kind !== 'no-body') this.setStatus({ kind: 'no-body' });
      this.latest = null;
      return null;
    }

    if (this.status.kind !== 'tracking' || this.status.bodies !== 1) {
      this.setStatus({ kind: 'tracking', bodies: 1 });
    }

    // MediaPipe reports hands as the *subject's* left and right, which is the
    // same sense the game's skeleton uses, so they map straight across.
    const reading: BodyReading = {
      world: world.map(toGameTriple),
      normalised: normalised.map(toImageTriple),
      // Taken from the *normalised* set: the world landmarks carry the same
      // scores, but the image-space ones are what the model is actually
      // confident or unconfident about seeing.
      visibility: normalised.map((l) => l.visibility ?? 1),
      hands: {
        left: toHand(result.leftHandWorldLandmarks[0]),
        right: toHand(result.rightHandWorldLandmarks[0]),
      },
      face: toFace(result.faceBlendshapes[0]?.categories),
    };

    this.latest = {
      bodies: [reading],
      forOverlay: [normalised.map(toImageTriple)],
      atMs: performance.now(),
    };
    return this.latest;
  }

  onStatusChange(listener: Listener<PoseStatus>): Unsubscribe {
    this.statusListeners.add(listener);
    listener(this.status);
    return () => this.statusListeners.delete(listener);
  }

  videoElement(): HTMLVideoElement | null {
    return this.video;
  }

  mediaStream(): MediaStream | null {
    return this.stream;
  }

  stop(): void {
    this.stopped = true;
    this.releaseCamera();
    this.landmarker?.close();
    this.landmarker = null;
    this.latest = null;
    this.lastVideoTime = -1;
    this.setStatus({ kind: 'off' });
    this.statusListeners.clear();
  }

  private releaseCamera(): void {
    // The hardware light stays on otherwise, and the player is entitled to
    // see it go out when they leave.
    for (const track of this.stream?.getTracks() ?? []) track.stop();
    this.stream = null;
    if (this.video) {
      this.video.srcObject = null;
      this.video = null;
    }
  }

  private setStatus(status: PoseStatus): void {
    this.status = status;
    for (const listener of this.statusListeners) listener(status);
  }
}

/**
 * The vision model's Y grows downward and its Z grows away from the camera;
 * the game's Y grows up and Z grows toward the opponent.
 */
const toGameTriple = (l: Landmark): Triple => [l.x, -l.y, -l.z];

/** Normalised landmarks stay in image space, for the preview overlay. */
const toImageTriple = (l: Landmark): Triple => [l.x, l.y, l.z];

/**
 * Reduces a 21-point hand to the two facts a fight needs: where the knuckles
 * are relative to the wrist, and whether the hand is closed.
 *
 * Both are differences between landmarks, so neither depends on where the
 * hand model happens to put its origin.
 */
function toHand(hand: Landmark[] | undefined): HandReading | null {
  const wrist = hand?.[HAND.wrist];
  const index = hand?.[HAND.indexKnuckle];
  const middle = hand?.[HAND.middleKnuckle];
  if (!hand || !wrist || !index || !middle) return null;

  // Midway between the index and middle knuckles: the part of a fist that
  // actually lands.
  const knuckles: Triple = [
    (index.x + middle.x) / 2 - wrist.x,
    -((index.y + middle.y) / 2 - wrist.y),
    -((index.z + middle.z) / 2 - wrist.z),
  ];

  // Palm length is the hand's own yardstick, so openness holds for any hand.
  const palm = Math.hypot(knuckles[0], knuckles[1], knuckles[2]);
  if (palm < 1e-4) return { knuckles, openness: 0.5 };

  let reach = 0;
  let counted = 0;
  for (const tip of HAND.tips) {
    const point = hand[tip];
    if (!point) continue;
    reach += Math.hypot(point.x - wrist.x, point.y - wrist.y, point.z - wrist.z);
    counted += 1;
  }
  if (counted === 0) return { knuckles, openness: 0.5 };

  // A closed fist keeps the tips about a palm from the wrist; a flat hand puts
  // them nearer two. Mapped so 0 is a fist and 1 is spread.
  const spread = reach / counted / palm;
  return { knuckles, openness: clamp01((spread - 1.05) / 0.95) };
}

/** Blendshape categories to a plain name → weight map. */
function toFace(categories: Category[] | undefined): Record<string, number> | undefined {
  if (!categories || categories.length === 0) return undefined;
  const weights: Record<string, number> = {};
  for (const category of categories) {
    const name = category.categoryName ?? category.displayName;
    // `_neutral` is the absence of expression and drives nothing.
    if (!name || name === '_neutral') continue;
    weights[name] = category.score;
  }
  return weights;
}

const clamp01 = (value: number): number => (value < 0 ? 0 : value > 1 ? 1 : value);
