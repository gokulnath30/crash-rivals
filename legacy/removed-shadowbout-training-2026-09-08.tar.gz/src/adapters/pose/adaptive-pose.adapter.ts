import type { Result } from '@domain/shared/result.ts';
import type { LoggerPort } from '@app/ports/logger.port.ts';
import type { PoseFrame, PoseSourcePort, PoseStatus } from '@app/ports/pose-source.port.ts';
import type { Listener, Unsubscribe } from '@app/ports/types.ts';
import { MediaPipeHolisticSource } from './mediapipe-holistic.adapter.ts';
import { MediaPipePoseSource } from './mediapipe-pose.adapter.ts';

/**
 * Picks the right tracker for the job, once, when tracking starts.
 *
 * The holistic tracker is the better one — it adds the hands and the face —
 * but it sees exactly one person. Shared-screen play puts two people in front
 * of one camera, and only the pose-only tracker can follow both. Rather than
 * make every caller know that, this decides on the body count it is handed and
 * forwards everything afterwards.
 *
 * Nothing above this knows which one it got. The extra hand and face data on a
 * reading is optional precisely so the game reads the same either way.
 */
export class AdaptivePoseSource implements PoseSourcePort {
  private active: PoseSourcePort | null = null;
  private fellBack = false;
  private readonly listeners = new Set<Listener<PoseStatus>>();
  private readonly log: LoggerPort;

  constructor(private readonly logger: LoggerPort) {
    this.log = logger.scoped('pose');
  }

  get status(): PoseStatus {
    return this.active?.status ?? { kind: 'off' };
  }

  async start(bodies: 1 | 2): Promise<Result<void>> {
    if (this.active) return this.active.start(bodies);

    // Two bodies means the pose tracker, with no choice about it.
    if (bodies === 2) {
      this.log.log('info', 'using the pose tracker: two bodies, no hands or face');
      return this.adopt(new MediaPipePoseSource(this.logger), bodies);
    }

    this.log.log('info', 'using the holistic tracker: pose, hands and face');
    const holistic = await this.adopt(new MediaPipeHolisticSource(this.logger), bodies);
    if (holistic.ok) return holistic;

    // The holistic tracker is the better one but it is also the bigger and
    // newer one: a 13 MB model, a WASM bundle and a browser that has to
    // support both. If any of that fails, tracking still has to work — so
    // fall back rather than leaving the player with a dead camera.
    this.log.log('warn', 'holistic tracking unavailable, falling back to pose only', holistic.error);
    this.release();
    this.fellBack = true;
    return this.adopt(new MediaPipePoseSource(this.logger), bodies);
  }

  /** True when the hands and face are unavailable for this session. */
  get poseOnly(): boolean {
    return this.fellBack || this.active instanceof MediaPipePoseSource;
  }

  private async adopt(source: PoseSourcePort, bodies: 1 | 2): Promise<Result<void>> {
    this.active = source;
    // Listeners registered before the tracker existed still have to hear from
    // it, so they are forwarded on rather than lost.
    for (const listener of this.listeners) source.onStatusChange(listener);
    return source.start(bodies);
  }

  private release(): void {
    this.active?.stop();
    this.active = null;
  }

  read(): PoseFrame | null {
    return this.active?.read() ?? null;
  }

  onStatusChange(listener: Listener<PoseStatus>): Unsubscribe {
    this.listeners.add(listener);
    const stop = this.active?.onStatusChange(listener);
    listener(this.status);
    return () => {
      this.listeners.delete(listener);
      stop?.();
    };
  }

  videoElement(): HTMLVideoElement | null {
    return this.active?.videoElement() ?? null;
  }

  mediaStream(): MediaStream | null {
    return this.active?.mediaStream() ?? null;
  }

  stop(): void {
    this.release();
    this.fellBack = false;
    this.listeners.clear();
  }
}
