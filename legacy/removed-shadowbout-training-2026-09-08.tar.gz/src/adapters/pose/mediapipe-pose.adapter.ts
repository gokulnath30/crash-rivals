import { LANDMARK } from '@domain/fighting/skeleton.ts';
import type { BodyReading } from '@domain/fighting/body-reading.ts';
import { fail, failure, ok, type Result } from '@domain/shared/result.ts';
import type { LoggerPort } from '@app/ports/logger.port.ts';
import type { PoseFrame, PoseSourcePort, PoseStatus } from '@app/ports/pose-source.port.ts';
import type { Listener, Unsubscribe } from '@app/ports/types.ts';
import { TASKS_BASE, describeCameraError } from './camera.ts';

/**
 * Body tracking with MediaPipe's pose landmarker.
 *
 * The library is imported dynamically, and only when somebody actually starts
 * a camera game: it pulls a WASM bundle and a model file, and there is no
 * reason for a player who only wants the racing game to download either.
 *
 * The adapter is deliberately *pull-based*. The camera runs at its own rate
 * and the game loop at another; letting the game ask "anything new?" once a
 * frame keeps the two from fighting, and means a slow model degrades into
 * lower-rate tracking rather than a stuttering render.
 */
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';

type Triple = readonly [number, number, number];

/** The shape of the bits of the MediaPipe API this adapter touches. */
interface Landmark {
  x: number;
  y: number;
  z: number;
  /** How sure the model is that it actually saw this point. */
  visibility?: number;
}
interface PoseResult {
  worldLandmarks: Landmark[][];
  landmarks: Landmark[][];
}
interface Landmarker {
  detectForVideo(video: HTMLVideoElement, timestampMs: number): PoseResult | undefined;
  close(): void;
}

export class MediaPipePoseSource implements PoseSourcePort {
  status: PoseStatus = { kind: 'off' };

  private video: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  private landmarker: Landmarker | null = null;
  private latest: PoseFrame | null = null;
  private lastVideoTime = -1;
  private readonly statusListeners = new Set<Listener<PoseStatus>>();
  private readonly log: LoggerPort;

  constructor(logger: LoggerPort) {
    this.log = logger.scoped('pose');
  }

  async start(bodies: 1 | 2): Promise<Result<void>> {
    if (this.landmarker) return ok(undefined);

    // Browsers only hand over a camera on a secure origin. Saying so is far
    // more useful than the NotAllowedError the player would otherwise see.
    if (!window.isSecureContext) {
      return this.failWith(
        'Browsers only allow camera access on https:// or localhost. Run `npm run dev`, or deploy the site.',
      );
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      return this.failWith('This browser has no camera API. Try Chrome, Edge or Safari.');
    }

    this.setStatus({ kind: 'starting', message: 'Asking for the camera…' });

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
        audio: false,
      });
    } catch (error: unknown) {
      return this.failWith(describeCameraError(error));
    }

    const video = document.createElement('video');
    video.playsInline = true;
    video.muted = true;
    video.srcObject = this.stream;
    this.video = video;
    try {
      await video.play();
    } catch {
      // Some browsers resolve this late; the read loop waits on readyState.
    }

    this.setStatus({ kind: 'starting', message: 'Loading the pose model…' });

    try {
      const vision = (await import(/* @vite-ignore */ `${TASKS_BASE}/vision_bundle.mjs`)) as {
        FilesetResolver: { forVisionTasks(base: string): Promise<unknown> };
        PoseLandmarker: {
          createFromOptions(fileset: unknown, options: unknown): Promise<Landmarker>;
        };
      };
      const fileset = await vision.FilesetResolver.forVisionTasks(`${TASKS_BASE}/wasm`);
      const create = (delegate: 'GPU' | 'CPU'): Promise<Landmarker> =>
        vision.PoseLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: MODEL_URL, delegate },
          runningMode: 'VIDEO',
          numPoses: bodies,
        });

      // GPU is much faster but unavailable on some drivers and in some
      // browsers; CPU is the honest fallback rather than a hard failure.
      try {
        this.landmarker = await create('GPU');
      } catch (gpuError: unknown) {
        this.log.log('info', 'GPU inference unavailable, falling back to CPU', gpuError);
        this.landmarker = await create('CPU');
      }
    } catch (error: unknown) {
      this.log.log('error', 'could not load the pose model', error);
      return this.failWith('Could not load the pose model. Check the connection and retry.');
    }

    this.setStatus({ kind: 'tracking', bodies: 0 });
    return ok(undefined);
  }

  /**
   * Runs inference if the video has a frame we have not seen, and returns it.
   * Returns null when there is nothing new, which the game reads as "keep the
   * pose you already have".
   */
  read(): PoseFrame | null {
    const video = this.video;
    const landmarker = this.landmarker;
    if (!video || !landmarker || video.readyState < 2) return null;
    if (video.currentTime === this.lastVideoTime) return null;
    this.lastVideoTime = video.currentTime;

    let result: PoseResult | undefined;
    try {
      result = landmarker.detectForVideo(video, performance.now());
    } catch (error: unknown) {
      this.log.log('debug', 'inference failed for a frame', error);
      return null;
    }

    if (!result?.worldLandmarks.length) {
      if (this.status.kind !== 'no-body') this.setStatus({ kind: 'no-body' });
      this.latest = null;
      return null;
    }

    // Sort by hip position across the frame, so "the fighter on the left" is
    // stable even when the model reorders the people it found.
    const order = result.landmarks
      .map((body, index) => ({ index, x: midHipX(body) }))
      .sort((a, b) => a.x - b.x);

    const bodies: BodyReading[] = [];
    const forOverlay: Triple[][] = [];
    for (const { index } of order) {
      const world = result.worldLandmarks[index];
      const normalised = result.landmarks[index];
      if (!world || !normalised) continue;
      bodies.push({
        world: world.map(toTriple),
        normalised: normalised.map(toTriple),
        visibility: normalised.map((l) => l.visibility ?? 1),
      });
      forOverlay.push(normalised.map(toTriple));
    }
    if (bodies.length === 0) return null;

    if (this.status.kind !== 'tracking' || this.status.bodies !== bodies.length) {
      this.setStatus({ kind: 'tracking', bodies: bodies.length });
    }

    this.latest = { bodies, forOverlay, atMs: performance.now() };
    return this.latest;
  }

  onStatusChange(listener: Listener<PoseStatus>): Unsubscribe {
    this.statusListeners.add(listener);
    listener(this.status);
    return () => this.statusListeners.delete(listener);
  }

  videoElement(): HTMLVideoElement | null {
    return this.video;
  }

  mediaStream(): MediaStream | null {
    return this.stream;
  }

  stop(): void {
    // Releasing the camera matters: the hardware light stays on otherwise, and
    // the player is entitled to see it go off when they leave the game.
    for (const track of this.stream?.getTracks() ?? []) track.stop();
    this.stream = null;
    this.landmarker?.close();
    this.landmarker = null;
    if (this.video) {
      this.video.srcObject = null;
      this.video = null;
    }
    this.latest = null;
    this.lastVideoTime = -1;
    this.setStatus({ kind: 'off' });
    this.statusListeners.clear();
  }

  private failWith(message: string): Result<void> {
    this.setStatus({ kind: 'failed', message });
    this.stopStreamOnly();
    return fail(failure('unavailable', message));
  }

  private stopStreamOnly(): void {
    for (const track of this.stream?.getTracks() ?? []) track.stop();
    this.stream = null;
  }

  private setStatus(status: PoseStatus): void {
    this.status = status;
    for (const listener of this.statusListeners) listener(status);
  }
}

const toTriple = (landmark: Landmark): Triple => [landmark.x, landmark.y, landmark.z];

function midHipX(body: readonly Landmark[]): number {
  const left = body[LANDMARK.hipL];
  const right = body[LANDMARK.hipR];
  if (!left || !right) return 0.5;
  return (left.x + right.x) / 2;
}

