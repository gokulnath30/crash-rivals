import { fail, failure, ok, type Result } from '@domain/shared/result.ts';

/**
 * Getting hold of a webcam, and the MediaPipe bundle both trackers load from.
 *
 * Shared because the pose-only and holistic adapters need exactly the same
 * things here, and the camera failure messages are worth writing once — a
 * player who has refused permission needs telling *that*, not `NotAllowedError`.
 */
/**
 * Pinned to the same version as the `@mediapipe/tasks-vision` dependency in
 * package.json, and it has to stay that way.
 *
 * The code is written against the *typed* API of the installed package, but at
 * runtime it loads the bundle from a CDN. When those two versions disagreed,
 * `HolisticLandmarker` existed in the types and was a stub at runtime — so
 * tracking failed at the point of creating it, with nothing in the types to
 * warn about it.
 */
export const TASKS_VERSION = '@mediapipe/tasks-vision@1.0.1';
export const TASKS_BASE = `https://cdn.jsdelivr.net/npm/${TASKS_VERSION}`;

export interface OpenCamera {
  readonly stream: MediaStream;
  readonly video: HTMLVideoElement;
}

/**
 * Asks for the camera and returns a playing video element.
 *
 * The secure-context check comes first because it is the failure people
 * actually hit, and the browser's own error for it is unhelpful.
 */
export async function openCamera(): Promise<Result<OpenCamera>> {
  if (!window.isSecureContext) {
    return fail(
      failure(
        'unavailable',
        'Browsers only allow camera access on https:// or localhost. Run `npm run dev`, or use the deployed site.',
      ),
    );
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    return fail(failure('unavailable', 'This browser has no camera API. Try Chrome, Edge or Safari.'));
  }

  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      audio: false,
    });
  } catch (error: unknown) {
    return fail(failure('unavailable', describeCameraError(error)));
  }

  const video = document.createElement('video');
  video.playsInline = true;
  video.muted = true;
  video.srcObject = stream;
  try {
    await video.play();
  } catch {
    // Some browsers resolve this late; the read loop waits on readyState.
  }
  return ok({ stream, video });
}

/**
 * Asks for the microphone, for the voice side of an online match.
 *
 * Requested separately from the camera, and only when a match is actually
 * online, so a solo player is never asked for a microphone they have no use
 * for. Echo cancellation is essential rather than optional here: both players
 * have speakers on and each other's audio playing.
 */
export async function openMicrophone(): Promise<Result<MediaStream>> {
  if (!navigator.mediaDevices?.getUserMedia) {
    return fail(failure('unavailable', 'This browser has no microphone API.'));
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false,
    });
    return ok(stream);
  } catch (error: unknown) {
    return fail(failure('unavailable', describeMicrophoneError(error)));
  }
}

function describeMicrophoneError(error: unknown): string {
  const name = error instanceof Error ? error.name : 'error';
  switch (name) {
    case 'NotAllowedError':
    case 'SecurityError':
      return 'Microphone permission was refused — you can still play, just without voice.';
    case 'NotFoundError':
      return 'No microphone found. You can still play, just without voice.';
    case 'NotReadableError':
      return 'The microphone is busy in another app. Playing without voice.';
    default:
      return `The microphone is unavailable (${name}). Playing without voice.`;
  }
}

export function describeCameraError(error: unknown): string {
  const name = error instanceof Error ? error.name : 'error';
  switch (name) {
    case 'NotAllowedError':
    case 'SecurityError':
      return 'Camera permission was refused. Allow it from the address bar, then try again.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No camera found on this device.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'The camera is busy — another app may have it. Close that and retry.';
    case 'OverconstrainedError':
      return 'This camera cannot provide the resolution the game asked for.';
    default:
      return `The camera is unavailable (${name}).`;
  }
}
