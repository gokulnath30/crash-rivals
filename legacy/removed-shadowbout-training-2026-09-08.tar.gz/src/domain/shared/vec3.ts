/**
 * A mutable 3-component vector owned by the domain.
 *
 * Mutable on purpose: the fighting simulation touches 16 joints on 2 fighters
 * every frame, and an immutable vector would allocate roughly two thousand
 * short-lived objects per second straight into the garbage collector's lap.
 * Methods that mutate say so (`addTo`, `lerpTo`); methods that do not, return
 * a fresh vector or a number.
 */
export class Vec3 {
  constructor(
    public x = 0,
    public y = 0,
    public z = 0,
  ) {}

  static of(x: number, y: number, z: number): Vec3 {
    return new Vec3(x, y, z);
  }

  static zero(): Vec3 {
    return new Vec3(0, 0, 0);
  }

  clone(): Vec3 {
    return new Vec3(this.x, this.y, this.z);
  }

  set(x: number, y: number, z: number): this {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }

  copyFrom(v: Vec3): this {
    return this.set(v.x, v.y, v.z);
  }

  addTo(v: Vec3): this {
    this.x += v.x;
    this.y += v.y;
    this.z += v.z;
    return this;
  }

  addScaled(v: Vec3, s: number): this {
    this.x += v.x * s;
    this.y += v.y * s;
    this.z += v.z * s;
    return this;
  }

  subTo(v: Vec3): this {
    this.x -= v.x;
    this.y -= v.y;
    this.z -= v.z;
    return this;
  }

  scaleTo(s: number): this {
    this.x *= s;
    this.y *= s;
    this.z *= s;
    return this;
  }

  lerpTo(v: Vec3, t: number): this {
    this.x += (v.x - this.x) * t;
    this.y += (v.y - this.y) * t;
    this.z += (v.z - this.z) * t;
    return this;
  }

  /** Lerp toward loose components, so callers can blend without allocating. */
  lerpToXYZ(x: number, y: number, z: number, t: number): this {
    this.x += (x - this.x) * t;
    this.y += (y - this.y) * t;
    this.z += (z - this.z) * t;
    return this;
  }

  /** Midpoint of two vectors, as a new vector. */
  static mid(a: Vec3, b: Vec3): Vec3 {
    return new Vec3((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
  }

  static sub(a: Vec3, b: Vec3): Vec3 {
    return new Vec3(a.x - b.x, a.y - b.y, a.z - b.z);
  }

  length(): number {
    return Math.hypot(this.x, this.y, this.z);
  }

  distanceTo(v: Vec3): number {
    return Math.hypot(this.x - v.x, this.y - v.y, this.z - v.z);
  }

  normalise(): this {
    const len = this.length();
    return len > 1e-6 ? this.scaleTo(1 / len) : this;
  }
}
