import { gestureDamage, type Strike } from './combat.ts';
import type { Fighter } from './fighter.ts';
import { RULES } from './moves.ts';

/**
 * Reading real punches and kicks off a body-tracked pose.
 *
 * Two signals are combined, because either alone gives false positives: how
 * far the limb is extended past the chest, and how fast it is moving — both
 * its speed through the room and its speed *toward the opponent*. A hand held
 * out still is not a punch; a hand swung sideways is not a punch either.
 */

/** Thresholds for "that was a punch". Either pair firing counts. */
const PUNCH = {
  farExtension: 0.3,
  farSpeed: 1.1,
  nearExtension: 0.18,
  nearForwardSpeed: 1.4,
} as const;

/**
 * What separates a kick from a step.
 *
 * The old thresholds asked only that the foot be somewhere above ankle height
 * and moving, which a brisk walk forward satisfies — so the game threw kicks
 * the player had not. A real kick does three things at once: the foot leaves
 * the floor properly, the *knee* comes up with it, and the whole leg drives
 * toward the opponent. All three are required.
 *
 * Heights are relative to the hips, so they hold for a tall player and a
 * short one. Ankles rest near -0.84 and knees near -0.42.
 */
const KICK = {
  /** Foot clearly off the floor, not merely lifted off the heel. */
  minLift: -0.42,
  /** Knee raised. This is the one that rules out walking. */
  minKneeLift: -0.3,
  /** Driven toward the opponent, rather than just up. */
  minExtension: 0.2,
  minSpeed: 1.35,
} as const;

/** A kick commits the whole body, so the hands go quiet briefly afterwards. */
const PUNCH_LOCKOUT_AFTER_KICK_MS = 220;

/**
 * Detects the strikes a body-tracked fighter has just thrown, putting the
 * matching limb on cooldown so one swing cannot land twice.
 *
 * Mutates only the fighter's own cooldowns; judging and damage happen
 * elsewhere.
 */
export function detectGestureStrikes(fighter: Fighter): readonly Strike[] {
  // Guarding is not attacking, and a downed fighter throws nothing.
  if (fighter.down || fighter.blocking) return NONE;

  const strikes: Strike[] = [];
  const chestZ = fighter.pose.chest.z;

  if (fighter.cooldownMs.punch <= 0) {
    for (const [joint, label] of HANDS) {
      const extension = fighter.pose[joint].z - chestZ;
      const speed = fighter.speed[joint];
      const forward = fighter.forwardSpeed[joint];
      const thrown =
        (extension > PUNCH.farExtension && speed > PUNCH.farSpeed) ||
        (extension > PUNCH.nearExtension && forward > PUNCH.nearForwardSpeed);
      if (!thrown) continue;
      // A flat, spread hand is a reach or a slap, not a punch. Only checked
      // when hand tracking actually saw the hand, so the pose-only tracker
      // behaves exactly as it did before.
      if (fighter.isFlatHand(joint)) continue;

      fighter.holdCooldown('punch', RULES.cooldownMs.punch);
      strikes.push({
        joint,
        reach: RULES.contact.punch,
        damage: gestureDamage('punch', Math.max(speed, forward)),
        heavy: false,
        label,
      });
      // One punch per cooldown window, even if both hands are out.
      break;
    }
  }

  if (fighter.cooldownMs.kick <= 0) {
    for (const [joint, knee] of LEGS) {
      const hipHeight = fighter.pose.pelvis.y;
      const lift = fighter.pose[joint].y - hipHeight;
      const kneeLift = fighter.pose[knee].y - hipHeight;
      const extension = fighter.pose[joint].z - chestZ;
      const speed = fighter.speed[joint];
      const forward = fighter.forwardSpeed[joint];
      const kicked =
        lift > KICK.minLift &&
        kneeLift > KICK.minKneeLift &&
        extension > KICK.minExtension &&
        (speed > KICK.minSpeed || forward > KICK.minSpeed);
      if (!kicked) continue;

      fighter.holdCooldown('kick', RULES.cooldownMs.kick);
      fighter.holdCooldown('punch', PUNCH_LOCKOUT_AFTER_KICK_MS);
      strikes.push({
        joint,
        reach: RULES.contact.kick,
        damage: gestureDamage('kick', Math.max(speed, forward)),
        heavy: true,
        label: 'kick',
      });
      break;
    }
  }

  return strikes;
}

/**
 * The strike a scripted move lands, once its animation reaches the contact
 * frame. Returns null until then, and only ever once per move.
 */
export function scriptedStrike(fighter: Fighter): Strike | null {
  const active = fighter.animation;
  if (!active || active.hasStruck) return null;
  const { move } = active;
  // Contact lands a little way into the held extension, not on the first frame
  // of the wind-up — otherwise the blow arrives before the fist does.
  if (active.elapsed < move.wind + move.hold * 0.35) return null;

  active.hasStruck = true;
  return {
    joint: move.joint,
    reach: move.reach,
    damage: move.damage,
    heavy: move.heavy,
    label: active.name,
  };
}

/**
 * Is this fighter visibly winding up a punch right now? The AI uses it to
 * decide whether to raise a guard, so it reads a punch instead of eating
 * everything thrown at it.
 */
export function isTelegraphingPunch(fighter: Fighter): boolean {
  const chestZ = fighter.pose.chest.z;
  const reach = Math.max(fighter.pose.wrL.z - chestZ, fighter.pose.wrR.z - chestZ);
  const pace = Math.max(
    fighter.speed.wrL,
    fighter.speed.wrR,
    fighter.forwardSpeed.wrL,
    fighter.forwardSpeed.wrR,
  );
  return reach > 0.26 && pace > 1.2;
}

const HANDS = [
  ['wrL', 'left hand'],
  ['wrR', 'right hand'],
] as const;

/** Each foot with the knee above it, since a kick needs both to come up. */
const LEGS = [
  ['anL', 'knL'],
  ['anR', 'knR'],
] as const;

const NONE: readonly Strike[] = Object.freeze([]);
