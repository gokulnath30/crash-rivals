import { clamp, lerp } from '../shared/mathx.ts';
import type { FightEvent, FighterIndex } from './events.ts';
import type { Fighter } from './fighter.ts';
import { isTelegraphingPunch } from './gestures.ts';
import { MOVE_NAMES, RULES, type MoveName } from './moves.ts';

/**
 * The solo opponent — "Shade".
 *
 * It is not trying to be unbeatable. It is trying to be a sparring partner:
 * it closes the distance, throws more often as its own health drops, blocks in
 * short bursts rather than permanently, and refuses to hit a staggered player
 * over and over. Every decision is driven by an injected `random`, so a seeded
 * run is reproducible.
 */
export class OpponentAi {
  /** Seconds until the next decision. */
  private thinkIn = 0.9;
  /** Seconds of guard left, and how long until it may guard again. */
  private guardFor = 0;
  private guardCooldown = 0;

  constructor(
    private readonly index: FighterIndex,
    private readonly random: () => number = Math.random,
  ) {}

  reset(): void {
    this.thinkIn = 0.9;
    this.guardFor = 0;
    this.guardCooldown = 0;
  }

  /**
   * Stops the opponent from stun-locking a player it has just caught: after
   * landing a blow it waits before choosing again.
   */
  holdAfterLanding(): void {
    this.thinkIn = Math.max(this.thinkIn, 0.55);
  }

  /**
   * @param nowMs a monotonic clock, injected so the idle sway is reproducible.
   */
  update(self: Fighter, foe: Fighter, dt: number, nowMs: number): readonly FightEvent[] {
    if (self.down || foe.down) return NONE;

    this.drift(self, foe, dt, nowMs);

    const pressure = this.pressure(self, foe);
    const aggression = 0.35 + (1 - self.healthFraction) * 0.5;

    const events = this.manageGuard(self, foe, dt);

    this.thinkIn -= dt;
    if (this.thinkIn > 0) return events;

    // A more aggressive Shade thinks faster; the jitter keeps it unpredictable.
    this.thinkIn = lerp(1.15, 0.42, aggression) * (0.7 + this.random() * 0.7);

    // Out of range: spend this beat repositioning rather than swinging at air.
    if (pressure < 0.35) return events;

    if (this.random() > aggression + pressure * 0.35) {
      self.blocking = true;
      return events;
    }

    self.blocking = false;
    const move = this.pickMove();
    if (self.throwMove(move)) {
      return [...events, { kind: 'move-thrown', attacker: this.index, move }];
    }
    return events;
  }

  /** Slide toward the player, with a slow sway so it never looks glued on. */
  private drift(self: Fighter, foe: Fighter, dt: number, nowMs: number): void {
    const sway = Math.sin(nowMs / 1400) * 0.18;
    const want = clamp(-foe.strafe * 0.85 + sway, -RULES.strafeLimit, RULES.strafeLimit);
    self.strafe += (want - self.strafe) * dt * 1.8;
  }

  /** 0 when far apart, 1 when right on top of each other. */
  private pressure(self: Fighter, foe: Fighter): number {
    const gap = Math.abs(self.position.x - foe.position.x);
    return 1 - Math.min(1, gap / 1.1);
  }

  /**
   * Guards in bursts with a cooldown. A permanent block would be unbeatable
   * and dull; this way it reads a punch, covers up, then has to drop its hands.
   */
  private manageGuard(self: Fighter, foe: Fighter, dt: number): readonly FightEvent[] {
    this.guardCooldown -= dt;

    if (this.guardFor > 0) {
      this.guardFor -= dt;
      // Throwing a punch takes priority over holding the guard up.
      self.blocking = self.animation === null;
      return NONE;
    }

    self.blocking = false;
    const shouldGuard =
      isTelegraphingPunch(foe) &&
      this.guardCooldown <= 0 &&
      self.animation === null &&
      this.random() < 0.35;

    if (!shouldGuard) return NONE;

    this.guardFor = 0.32;
    this.guardCooldown = 1.4;
    self.blocking = true;
    return [{ kind: 'guard-raised', fighter: this.index }];
  }

  /**
   * Weighted toward the quick, cheap punches. The heavy kick is the rare one,
   * which is what makes it land.
   */
  private pickMove(): MoveName {
    const roll = this.random();
    const index = roll < 0.34 ? 0 : roll < 0.62 ? 1 : roll < 0.84 ? 2 : 3;
    return MOVE_NAMES[index] ?? 'jab';
  }
}

const NONE: readonly FightEvent[] = Object.freeze([]);
