import { clamp, lerp } from '../shared/mathx.ts';
import type { Vec3 } from '../shared/vec3.ts';
import type { FightEvent, FighterIndex, HitZone } from './events.ts';
import type { Fighter } from './fighter.ts';
import { RULES } from './moves.ts';
import type { JointName } from './skeleton.ts';

/** A blow the attacker has committed to, awaiting a verdict on whether it connected. */
export interface Strike {
  readonly joint: JointName;
  readonly reach: number;
  readonly damage: number;
  readonly heavy: boolean;
  /** What to show the player: "jab", "kick", "left hand". */
  readonly label: string;
}

export type ContactJudgement =
  | { readonly landed: true; readonly zone: HitZone; readonly contact: Vec3 }
  | {
      readonly landed: false;
      readonly at: Vec3;
      readonly hint: string;
    };

/**
 * Geometry only: did this strike connect, and where? Pure — it reads both
 * fighters and mutates neither, so it is straightforward to test.
 *
 * The test is a real distance from the striking limb to the nearest target on
 * the body. It used to be a much looser thing — "are they roughly lined up,
 * and roughly close enough" — which was defensible while both fighters were
 * stick figures, and stopped being defensible the moment they became people:
 * a fist landing half a metre from a visible jaw reads as broken.
 *
 * Depth is still the weak axis on a single webcam, so it is weighted rather
 * than trusted or discarded. `depthTrust` below 1 means a strike that is
 * lined up and at the right height forgives some error in how far away the
 * camera thinks the hand is.
 */
export function judgeContact(attacker: Fighter, defender: Fighter, strike: Strike): ContactJudgement {
  // The knuckles when hand tracking knows where they are, the joint itself
  // otherwise. This is the difference between a punch that connects where you
  // saw it connect and one that lands a hand's length short.
  const fist = attacker.strikePointOf(strike.joint);
  const head = defender.worldOf('head');
  const chest = defender.worldOf('chest');
  const pelvis = defender.worldOf('pelvis');

  const toHead = weightedDistance(fist, head);
  const toChest = weightedDistance(fist, chest);
  const toBelt = weightedDistance(fist, pelvis);

  const nearest = Math.min(toHead, toChest, toBelt);
  if (nearest > strike.reach) {
    // Say which way they were wrong about, so the hint is actionable.
    const sideways = Math.abs(fist.x - chest.x);
    return {
      landed: false,
      at: fist,
      hint: sideways > strike.reach ? 'line up with them' : 'too far — step in',
    };
  }

  const zone: HitZone = nearest === toHead ? 'head' : nearest === toChest ? 'body' : 'low';
  const target = zone === 'head' ? head : zone === 'body' ? chest : pelvis;

  // The contact point sits on the line between them, biased toward the fist,
  // so the spark appears where the hand is rather than inside the torso.
  const contact = target.clone();
  contact.x = lerp(contact.x, fist.x, 0.55);
  contact.y = lerp(contact.y, fist.y, 0.55);
  contact.z = lerp(contact.z, fist.z, 0.55);
  return { landed: true, zone, contact };
}

/**
 * Distance between two points with the depth axis scaled down, because a
 * webcam knows where your hand is sideways far better than how far away it is.
 */
function weightedDistance(a: Vec3, b: Vec3): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = (a.z - b.z) * RULES.depthTrust;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}


/**
 * Applies a judged hit: damage, block reduction, stagger, knockback, and the
 * events that drive sound and spectacle. This is the one function in the
 * fighting rules that mutates both fighters, which keeps the mutation easy to
 * find.
 *
 * @returns the events raised, ending in a `knockout` if this blow finished it.
 */
export function applyHit(input: {
  attacker: Fighter;
  defender: Fighter;
  attackerIndex: FighterIndex;
  strike: Strike;
  judgement: Extract<ContactJudgement, { landed: true }>;
}): readonly FightEvent[] {
  const { defender, attackerIndex, strike, judgement } = input;
  const defenderIndex = attackerIndex === 0 ? 1 : 0;

  const zoned = strike.damage * RULES.zoneScale[judgement.zone];
  const blocked = defender.blocking;
  const damage = Math.round(blocked ? zoned * RULES.blockedDamageScale : zoned);
  // A head shot always reads as heavy, whatever threw it.
  const heavy = strike.heavy || judgement.zone === 'head';

  const finished = defender.takeDamage(damage);
  if (blocked) {
    // Blocking still rocks them a little, but it does not break their stance.
    defender.knockback = 0.05;
  } else {
    defender.stagger(zoned);
  }

  const events: FightEvent[] = [
    {
      kind: 'hit',
      attacker: attackerIndex,
      defender: defenderIndex,
      damage,
      blocked,
      heavy,
      zone: judgement.zone,
      contact: judgement.contact,
      label: strike.label,
    },
  ];
  if (finished) {
    defender.putDown();
    events.push({ kind: 'knockout', loser: defenderIndex });
  }
  return events;
}

/** How long the picture freezes on impact, in seconds. Sells the weight. */
export function hitstopFor(blocked: boolean, heavy: boolean): number {
  if (blocked) return 0.05;
  return heavy ? 0.11 : 0.075;
}

/** How hard the camera shakes on impact. */
export function shakeFor(blocked: boolean, heavy: boolean): number {
  if (blocked) return 0.05;
  return heavy ? 0.22 : 0.13;
}

/**
 * The damage a body-tracked punch or kick carries, scaled by how fast the limb
 * was actually travelling. Clamped at both ends so a tracking glitch cannot
 * produce a one-frame knockout, and a slow reach still counts for something.
 */
export function gestureDamage(kind: 'punch' | 'kick', speed: number): number {
  return kind === 'punch'
    ? clamp(5 + speed * 2, 6, 15)
    : clamp(9 + speed * 1.8, 10, 20);
}
