import type { JointName, StrikingJoint, Triple } from './skeleton.ts';

/**
 * Attack shapes: partial poses blended on top of the neutral stance. A shape
 * only names the joints it moves, so a jab leaves the legs alone and the
 * blender keeps them in stance.
 */
export type ShapeName = 'jab' | 'cross' | 'hook' | 'kick' | 'guard' | 'hurt' | 'down';

export const SHAPES: Readonly<Record<ShapeName, Readonly<Partial<Record<JointName, Triple>>>>> = {
  jab: {
    wrL: [0.09, 0.46, 0.74],
    elL: [0.16, 0.4, 0.42],
    chest: [0.02, 0.29, 0.1],
    head: [0.02, 0.67, 0.06],
  },
  cross: {
    wrR: [-0.04, 0.45, 0.8],
    elR: [-0.15, 0.38, 0.44],
    chest: [-0.03, 0.29, 0.12],
    shR: [-0.14, 0.46, 0.14],
    head: [-0.02, 0.67, 0.08],
  },
  hook: {
    wrL: [-0.02, 0.52, 0.6],
    elL: [0.34, 0.44, 0.34],
    chest: [0.04, 0.29, 0.08],
    shL: [0.22, 0.47, 0.12],
  },
  kick: {
    anR: [-0.05, 0.14, 0.78],
    knR: [-0.09, -0.06, 0.38],
    chest: [0, 0.28, -0.12],
    head: [0, 0.66, -0.16],
    wrL: [0.3, 0.3, 0.02],
    wrR: [-0.3, 0.3, 0.02],
    pelvis: [0, -0.04, -0.06],
  },
  guard: {
    wrL: [0.11, 0.6, 0.26],
    wrR: [-0.11, 0.6, 0.26],
    elL: [0.24, 0.3, 0.2],
    elR: [-0.24, 0.3, 0.2],
    chest: [0, 0.28, -0.02],
    head: [0, 0.66, -0.04],
  },
  hurt: {
    chest: [0, 0.28, -0.14],
    head: [0, 0.66, -0.22],
    neck: [0, 0.49, -0.16],
    wrL: [0.34, 0.3, 0.02],
    wrR: [-0.34, 0.3, 0.02],
  },
  down: {
    pelvis: [0, -0.55, -0.3],
    chest: [0, -0.35, -0.55],
    neck: [0, -0.28, -0.75],
    head: [0, -0.22, -0.92],
    shL: [0.2, -0.3, -0.58],
    shR: [-0.2, -0.3, -0.58],
    elL: [0.34, -0.42, -0.4],
    elR: [-0.34, -0.42, -0.4],
    wrL: [0.4, -0.55, -0.2],
    wrR: [-0.4, -0.55, -0.2],
    knL: [0.16, -0.6, 0.18],
    knR: [-0.16, -0.6, 0.18],
    anL: [0.18, -0.72, 0.5],
    anR: [-0.18, -0.72, 0.5],
  },
};

export type MoveName = 'jab' | 'cross' | 'hook' | 'kick';
export const MOVE_NAMES = ['jab', 'cross', 'hook', 'kick'] as const;

export interface Move {
  readonly shape: ShapeName;
  /** The joint that carries the blow. */
  readonly joint: StrikingJoint;
  readonly damage: number;
  /** Seconds of wind-up, of held extension, and of recovery. */
  readonly wind: number;
  readonly hold: number;
  readonly recover: number;
  readonly reach: number;
  /** Heavy hits shake the camera harder and thud lower. */
  readonly heavy: boolean;
}

export const RULES = {
  /** Half the distance between the two fighters, in metres. */
  separation: 0.5,
  /** A round is a proper bout, not a skirmish. */
  roundSeconds: 99,
  roundsToWin: 2,
  /**
   * Health. Generous on purpose: with strikes doing 6-20, this is roughly ten
   * clean hits, so a round is a fight rather than an exchange.
   */
  maxHp: 150,
  strafeLimit: 0.62,
  /**
   * How close the striking limb must actually get to the target, in metres.
   *
   * This is a distance from fist to body — not, as it used to be, a loose
   * allowance on the gap between the two fighters. A blow now lands when the
   * hand is genuinely on them, which is the only version that reads correctly
   * once real characters are on screen instead of stick figures.
   */
  contact: { punch: 0.3, kick: 0.42 },
  /**
   * How much the depth axis counts toward that distance.
   *
   * A single webcam measures left/right and up/down well and depth poorly, so
   * z is trusted a little over half as much as x and y. Trusting it fully
   * would make hits miss for reasons the player cannot see; ignoring it
   * entirely is how a punch thrown into thin air used to connect.
   */
  depthTrust: 0.55,
  /** Milliseconds before the same limb can throw again. */
  cooldownMs: { punch: 340, kick: 700 },
  /** A blocked blow still stings, but only just. */
  blockedDamageScale: 0.22,
  /** Damage multipliers by where the blow lands. */
  zoneScale: { head: 1.2, body: 1, low: 0.85 },
  /**
   * How far, in radians, a fighter may turn away from facing their opponent.
   * About 150 degrees — enough to turn side-on and past it.
   */
  turnLimit: 2.6,
} as const;

export const MOVES: Readonly<Record<MoveName, Move>> = {
  jab: {
    shape: 'jab',
    joint: 'wrL',
    damage: 7,
    wind: 0.09,
    hold: 0.09,
    recover: 0.16,
    reach: RULES.contact.punch,
    heavy: false,
  },
  cross: {
    shape: 'cross',
    joint: 'wrR',
    damage: 9,
    wind: 0.12,
    hold: 0.1,
    recover: 0.22,
    reach: RULES.contact.punch,
    heavy: false,
  },
  hook: {
    shape: 'hook',
    joint: 'wrL',
    damage: 11,
    wind: 0.16,
    hold: 0.11,
    recover: 0.28,
    reach: RULES.contact.punch,
    heavy: false,
  },
  kick: {
    shape: 'kick',
    joint: 'anR',
    damage: 14,
    wind: 0.18,
    hold: 0.13,
    recover: 0.34,
    reach: RULES.contact.kick,
    heavy: true,
  },
};

export const totalDuration = (move: Move): number => move.wind + move.hold + move.recover;
