import type { Triple } from './skeleton.ts';

/**
 * One frame of body tracking, in the shape the domain wants it.
 *
 * The pose adapter converts whatever its vision library produced into this;
 * the fighting rules never see a MediaPipe type. `world` is metres relative to
 * the subject's hips, `normalised` is 0..1 across the video frame and is what
 * tells us where in the room the player is standing.
 *
 * `hands` and `face` are present only when the tracker supplies them. The
 * holistic tracker does; the pose-only one does not, and the game has to work
 * either way: the holistic tracker is the only one that reports hands and a
 * face, and it is also the one most likely to be unavailable, so the fight has
 * to stay playable on the pose-only fallback.
 */
export interface BodyReading {
  readonly world: readonly Triple[];
  readonly normalised: readonly Triple[];
  /**
   * How confident the tracker is about each landmark, 0..1, same order as
   * `world`.
   *
   * This matters more than it sounds. A pose model returns all thirty-three
   * landmarks whether or not it can see them — sit close to the camera and it
   * will still report your ankles, by guessing. Following that guess is what
   * puts a fighter face-down on the floor with its legs in the air. When the
   * scores are absent every landmark is trusted, which is the old behaviour.
   */
  readonly visibility?: readonly number[] | undefined;
  readonly hands?: HandsReading | undefined;
  readonly face?: FaceReading | undefined;
}

export interface HandsReading {
  readonly left: HandReading | null;
  readonly right: HandReading | null;
}

/**
 * What a tracked hand tells us that a wrist alone cannot.
 *
 * Two things matter to a fight. The knuckles are where a punch actually
 * connects, and they sit the better part of a hand's length past the wrist —
 * so aiming at the wrist aims short. And a punch is thrown with a closed fist;
 * an open hand reaching out is a different gesture that should not score.
 */
export interface HandReading {
  /** Wrist to knuckles, in the game's own axes and metres. */
  readonly knuckles: Triple;
  /**
   * How open the hand is: roughly 0 for a closed fist, 1 for a flat spread
   * hand. Measured against the hand's own size, so it holds for any hand.
   */
  readonly openness: number;
}

/**
 * Facial blendshape weights by name, 0..1.
 *
 * MediaPipe emits the ARKit names (`jawOpen`, `eyeBlinkLeft`,
 * `mouthSmileLeft`, …) and the Avaturn exports happen to use exactly those
 * names for their morph targets — so this map drives a face with no
 * translation table in between.
 */
export type FaceReading = Readonly<Record<string, number>>;

/**
 * Below this, a landmark is a guess rather than an observation.
 *
 * Chosen low rather than high: the cost of trusting a bad landmark is a
 * mangled body, but the cost of rejecting a good one is only a limb that
 * holds its stance, so the threshold leans toward accepting.
 */
export const MIN_VISIBILITY = 0.5;

/** A tracked body is only usable if it carries every landmark the game reads. */
export const MIN_LANDMARKS = 29;

export const isUsableReading = (reading: BodyReading): boolean =>
  reading.world.length >= MIN_LANDMARKS && reading.normalised.length >= MIN_LANDMARKS;

/**
 * Above this, the hand is too open to be a punch.
 *
 * Generous on purpose: hand tracking is the least reliable part of the
 * pipeline, and a threshold that rejects real punches is far worse than one
 * that lets a loose fist through. Only a clearly flat hand is turned away.
 */
export const MAX_PUNCH_OPENNESS = 0.78;
