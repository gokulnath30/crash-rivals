import { clamp, damp } from '../shared/mathx.ts';
import { Vec3 } from '../shared/vec3.ts';
import { MAX_PUNCH_OPENNESS, MIN_VISIBILITY, type BodyReading } from './body-reading.ts';
import { MOVES, RULES, SHAPES, totalDuration, type Move, type MoveName } from './moves.ts';
import {
  JOINTS,
  LANDMARK,
  STANCE,
  STRIKING_JOINTS,
  type JointName,
  type StrikingJoint,
  type Triple,
} from './skeleton.ts';

/** -1 stands nearest the camera, +1 stands across from them. */
export type FighterSide = -1 | 1;

/** A scripted move partway through its wind-up, extension and recovery. */
export interface ActiveMove {
  readonly name: MoveName;
  readonly move: Move;
  readonly total: number;
  elapsed: number;
  /** A move lands at most once, however long it is held out. */
  hasStruck: boolean;
}

/** How fast the rendered pose chases the blended animation target. */
const ANIM_FOLLOW_RATE = 0.0006;
/**
 * How hard a fresh camera reading pulls the pose. Applied per *video* frame
 * (~30/s) rather than per render frame, so it is a plain constant rather than
 * a dt-scaled one.
 */
const TRACKING_BLEND = 0.46;
const STRAFE_BLEND = 0.12;
/** How quickly the fighter's turn follows the player's. Per video frame. */
const TURN_BLEND = 0.22;
/**
 * Below this, the shoulder line is too foreshortened to carry an angle — the
 * player is side-on, or tracking has partly lost them.
 */
const MIN_SHOULDER_SPAN = 0.12;
/** How fast the knuckle offset follows the hand tracker, per video frame. */
const HAND_BLEND = 0.35;
/** How fast it returns to the wrist when a hand is lost. Slower, on purpose. */
const HAND_DECAY = 0.06;
/**
 * A reading that moves a wrist further than this in one frame means tracking
 * was just re-acquired. Swinging on that jump would register as a punch the
 * player never threw, so the limbs go on cooldown instead.
 */
const REACQUIRE_JUMP = 0.45;
const REACQUIRE_COOLDOWN_MS = 250;
/** How firmly the fighter is pushed back onto the floor each reading. */
const FOOT_PLANT_BLEND = 0.2;
const FOOT_CLEARANCE = 0.06;

const HIP_HEIGHT = 0.9;
/**
 * How far the hips may travel from that. Wide enough for a deep crouch or a
 * stretch, tight enough that a hallucinated ankle cannot post the fighter
 * through the floor — which is what an unclamped foot plant did.
 */
const MIN_HIP_HEIGHT = 0.55;
const MAX_HIP_HEIGHT = 1.15;
/** How fast an unseen limb returns to its stance. Slow, so it does not snap. */
const UNSEEN_BLEND = 0.08;
/**
 * How far the torso may lean from upright, in radians — about twenty degrees.
 * Enough to duck and weave, not enough to fold over.
 */
const MAX_TORSO_TILT = 0.35;
/** Where the chest sits along the hips-to-neck line. */
const CHEST_ALONG_SPINE = 0.58;
const IDLE_BOB_PERIOD_MS = 320;
const IDLE_BOB_AMOUNT = 0.018 * 0.35;

export class Fighter {
  readonly side: FighterSide;
  name: string;

  /** Live joint positions, in the fighter's own local space. */
  readonly pose: Record<JointName, Vec3>;
  /** Where the fighter is standing. The local pose hangs off this. */
  readonly position = new Vec3();

  hp: number = RULES.maxHp;
  strafe = 0;
  /**
   * How far the fighter has turned away from squaring up, in radians.
   *
   * Read from the player's shoulder line, so turning your body turns your
   * fighter. Zero means facing the opponent.
   */
  facing = 0;
  blocking = false;
  down = false;
  /** True once a camera has actually seen this fighter. */
  tracked = false;

  /** Seconds of stagger left, and how far the last blow shoved them back. */
  hurtFor = 0;
  knockback = 0;

  animation: ActiveMove | null = null;
  readonly cooldownMs: Record<'punch' | 'kick', number> = { punch: 0, kick: 0 };

  /**
   * Wrist-to-knuckles offsets, in local space, when hand tracking supplies
   * them. Zero when it does not, which puts the strike point back on the
   * wrist — the old behaviour.
   */
  readonly knuckles: Record<'wrL' | 'wrR', Vec3>;
  /**
   * How open each hand is, or null when unknown. A flat hand reaching out is
   * not a punch, and this is what lets the detector say so.
   */
  readonly handOpenness: Record<'wrL' | 'wrR', number | null> = { wrL: null, wrR: null };

  /** World-space and forward-reach speed of each striking joint, in m/s. */
  readonly speed: Record<StrikingJoint, number>;
  readonly forwardSpeed: Record<StrikingJoint, number>;

  private readonly previousWorld: Record<StrikingJoint, Vec3>;
  private readonly previousLocalZ: Record<StrikingJoint, number>;
  private readonly scratch = new Vec3();

  constructor(options: { name: string; side: FighterSide }) {
    this.name = options.name;
    this.side = options.side;

    this.pose = {} as Record<JointName, Vec3>;
    for (const joint of JOINTS) {
      const [x, y, z] = STANCE[joint];
      this.pose[joint] = new Vec3(x, y, z);
    }

    this.knuckles = { wrL: new Vec3(), wrR: new Vec3() };
    this.speed = {} as Record<StrikingJoint, number>;
    this.forwardSpeed = {} as Record<StrikingJoint, number>;
    this.previousWorld = {} as Record<StrikingJoint, Vec3>;
    this.previousLocalZ = {} as Record<StrikingJoint, number>;
    for (const joint of STRIKING_JOINTS) {
      this.speed[joint] = 0;
      this.forwardSpeed[joint] = 0;
      this.previousWorld[joint] = new Vec3();
      this.previousLocalZ[joint] = STANCE[joint][2];
    }

    this.reset({ forgetTracking: true });
  }

  reset(options: { forgetTracking?: boolean } = {}): void {
    this.hp = RULES.maxHp;
    this.strafe = 0;
    this.facing = 0;
    this.blocking = false;
    this.down = false;
    this.hurtFor = 0;
    this.knockback = 0;
    this.animation = null;
    this.cooldownMs.punch = 0;
    this.cooldownMs.kick = 0;
    this.knuckles.wrL.set(0, 0, 0);
    this.knuckles.wrR.set(0, 0, 0);
    this.handOpenness.wrL = null;
    this.handOpenness.wrR = null;
    this.position.set(0, HIP_HEIGHT, RULES.separation * this.side);
    if (options.forgetTracking) this.tracked = false;
  }

  get healthFraction(): number {
    return this.hp / RULES.maxHp;
  }

  /**
   * The fighter's total rotation about the vertical: squaring up to the
   * opponent, plus however far the player has turned.
   *
   * Both the renderers and `worldOf` read this, which is what keeps what you
   * see and what can be hit from ever disagreeing.
   */
  get yaw(): number {
    return (this.side < 0 ? 0 : Math.PI) + this.facing;
  }

  /** Applies damage, and reports whether this blow put them down. */
  takeDamage(amount: number): boolean {
    this.hp = Math.max(0, this.hp - amount);
    return this.hp <= 0;
  }

  /**
   * Starts a scripted move. Refused while downed, staggered, or while an
   * earlier move is still mid-swing — which is what stops the AI and the
   * keyboard from machine-gunning jabs.
   */
  throwMove(name: MoveName): boolean {
    if (this.down || this.hurtFor > 0) return false;
    if (this.animation && this.animation.elapsed < this.animation.total * 0.82) return false;
    const move = MOVES[name];
    this.animation = { name, move, elapsed: 0, hasStruck: false, total: totalDuration(move) };
    return true;
  }

  /** Cancels whatever they were doing and plays the flinch. */
  stagger(power: number): void {
    this.animation = null;
    this.hurtFor = Math.min(0.35, 0.14 + power * 0.01);
    this.knockback = Math.min(0.34, 0.06 + power * 0.012);
  }

  putDown(): void {
    this.down = true;
  }

  holdCooldown(kind: 'punch' | 'kick', ms: number): void {
    this.cooldownMs[kind] = Math.max(this.cooldownMs[kind], ms);
  }

  /**
   * Drives the pose from the scripted animation stack: downed beats staggered,
   * beats mid-move, beats guarding, beats plain stance.
   *
   * @param nowMs a monotonic clock, injected so the idle bob stays reproducible.
   */
  blendAnimation(dt: number, nowMs: number): void {
    let overlay: Readonly<Partial<Record<JointName, Triple>>> | null = null;
    let weight = 0;

    if (this.down) {
      overlay = SHAPES.down;
      weight = 1;
    } else if (this.hurtFor > 0) {
      this.hurtFor -= dt;
      overlay = SHAPES.hurt;
      weight = Math.min(1, this.hurtFor * 5);
      if (this.hurtFor <= 0) {
        // The live camera pose snaps back the instant the stagger ends. Don't
        // let that snap read as a thrown punch.
        this.holdCooldown('punch', 200);
        this.holdCooldown('kick', 200);
      }
    } else if (this.animation) {
      const active = this.animation;
      active.elapsed += dt;
      const { wind, hold, recover } = active.move;
      if (active.elapsed < wind) weight = active.elapsed / wind;
      else if (active.elapsed < wind + hold) weight = 1;
      else weight = Math.max(0, 1 - (active.elapsed - wind - hold) / recover);
      overlay = SHAPES[active.move.shape];
      if (active.elapsed >= active.total) this.animation = null;
    } else if (this.blocking) {
      overlay = SHAPES.guard;
      weight = 1;
    }

    const follow = 1 - Math.pow(ANIM_FOLLOW_RATE, dt);
    const bob = this.down ? 0 : Math.sin(nowMs / IDLE_BOB_PERIOD_MS) * IDLE_BOB_AMOUNT;

    for (const joint of JOINTS) {
      const rest = STANCE[joint];
      const shaped = overlay?.[joint];
      // Only the joints a shape actually names get blended; the rest sit in stance.
      const tx = shaped ? rest[0] + (shaped[0] - rest[0]) * weight : rest[0];
      const ty = shaped ? rest[1] + (shaped[1] - rest[1]) * weight : rest[1];
      const tz = shaped ? rest[2] + (shaped[2] - rest[2]) * weight : rest[2];
      const lift = joint === 'anL' || joint === 'anR' ? 0 : bob;
      this.pose[joint].lerpToXYZ(tx, ty + lift, tz, follow);
    }
  }

  /**
   * Drives the pose straight from a camera reading. Ignored while downed or
   * staggered, so a knockdown plays out instead of being overwritten by the
   * player standing there looking puzzled.
   */
  applyBodyReading(reading: BodyReading): void {
    if (this.down || this.hurtFor > 0) {
      this.tracked = true;
      return;
    }
    const target = localPoseFromReading(reading);
    if (!target) return;
    const seen = confidentJoints(reading);

    const jump = Math.max(
      this.pose.wrL.distanceTo(target.wrL),
      this.pose.wrR.distanceTo(target.wrR),
    );
    if (jump > REACQUIRE_JUMP) {
      this.holdCooldown('punch', REACQUIRE_COOLDOWN_MS);
      this.holdCooldown('kick', REACQUIRE_COOLDOWN_MS);
    }

    for (const joint of JOINTS) {
      if (seen[joint]) {
        this.pose[joint].lerpTo(target[joint], TRACKING_BLEND);
        continue;
      }
      // Not visible: settle into the fighting stance rather than following a
      // guess. A limb the camera cannot see should stand, not flail.
      const [x, y, z] = STANCE[joint];
      this.pose[joint].lerpToXYZ(x, y, z, UNSEEN_BLEND);
    }

    // Keep the feet on the floor rather than skating above it or sinking
    // through. Only meaningful when the feet are actually in frame; otherwise
    // return to a normal standing height.
    const footed = seen.anL && seen.anR;
    const lowestFoot = Math.min(this.pose.anL.y, this.pose.anR.y);
    const standingY = footed
      ? clamp(-lowestFoot + FOOT_CLEARANCE, MIN_HIP_HEIGHT, MAX_HIP_HEIGHT)
      : HIP_HEIGHT;
    this.position.y += (standingY - this.position.y) * FOOT_PLANT_BLEND;

    const hipLeft = reading.normalised[LANDMARK.hipL];
    const hipRight = reading.normalised[LANDMARK.hipR];
    if (hipLeft && hipRight) {
      const hipX = (hipLeft[0] + hipRight[0]) / 2;
      // The preview is mirrored and the far fighter faces the other way, so
      // stepping left in the room always means stepping left on screen.
      const want = clamp((0.5 - hipX) * 2.2, -RULES.strafeLimit, RULES.strafeLimit) * -this.side;
      this.strafe += (want - this.strafe) * STRAFE_BLEND;
    }

    this.readTurn(target);
    this.readHands(reading);
    this.blocking = this.readsAsGuard();
    this.tracked = true;
  }

  /**
   * Takes whatever the hand tracker managed to see.
   *
   * Eased rather than copied: hand tracking drops in and out, and a knuckle
   * offset that snaps to zero the moment a hand is lost would make the strike
   * point jump by most of a hand's length mid-punch.
   */
  private readHands(reading: BodyReading): void {
    const hands = reading.hands;
    if (!hands) return;
    for (const [joint, hand] of [
      ['wrL', hands.left],
      ['wrR', hands.right],
    ] as const) {
      if (!hand) {
        // Decay toward the wrist rather than jumping there.
        this.knuckles[joint].lerpToXYZ(0, 0, 0, HAND_DECAY);
        this.handOpenness[joint] = null;
        continue;
      }
      const [x, y, z] = hand.knuckles;
      this.knuckles[joint].lerpToXYZ(x, y, z, HAND_BLEND);
      this.handOpenness[joint] = hand.openness;
    }
  }

  /** True when the hand is known to be too open to be throwing a punch. */
  isFlatHand(joint: 'wrL' | 'wrR'): boolean {
    const openness = this.handOpenness[joint];
    return openness !== null && openness > MAX_PUNCH_OPENNESS;
  }

  /**
   * Reads how far the player has turned, from the line across their shoulders.
   *
   * At rest that line runs along the fighter's own X. Turn, and it swings into
   * Z — so its angle in the XZ plane *is* the body's rotation, with no
   * calibration needed.
   *
   * A single camera cannot honestly tell a player facing away from one facing
   * forward; past a certain angle the shoulders foreshorten to nothing and the
   * reading becomes noise. Hence both the span check, which ignores a
   * degenerate reading, and `turnLimit`.
   */
  private readTurn(target: Record<JointName, Vec3>): void {
    const acrossX = target.shL.x - target.shR.x;
    const acrossZ = target.shL.z - target.shR.z;
    const span = Math.hypot(acrossX, acrossZ);
    if (span < MIN_SHOULDER_SPAN) return;

    const seen = clamp(Math.atan2(-acrossZ, acrossX), -RULES.turnLimit, RULES.turnLimit);
    // Approach along the shorter arc, so passing through the atan2 wrap does
    // not send the fighter spinning the long way round.
    let delta = seen - this.facing;
    while (delta > Math.PI) delta -= Math.PI * 2;
    while (delta < -Math.PI) delta += Math.PI * 2;
    this.facing = clamp(this.facing + delta * TURN_BLEND, -RULES.turnLimit, RULES.turnLimit);
  }

  /**
   * Adopts a pose that arrived from somewhere else — the other player's
   * browser, over the network.
   *
   * Set directly rather than eased: the sender already smoothed it against
   * their own camera, and smoothing a second time here would just add
   * latency to a fight that has little to spare. Speeds are still derived by
   * `integrate`, so strike detection works identically on a remote fighter
   * and a local one.
   */
  adoptPose(input: {
    joints: readonly Triple[];
    strafe: number;
    standingY: number;
    facing: number;
    blocking: boolean;
    knuckles?: { readonly left: Triple; readonly right: Triple } | undefined;
  }): void {
    if (input.joints.length < JOINTS.length) return;
    JOINTS.forEach((joint, index) => {
      const value = input.joints[index];
      if (value) this.pose[joint].set(value[0], value[1], value[2]);
    });
    this.strafe = clamp(input.strafe, -RULES.strafeLimit, RULES.strafeLimit);
    this.facing = clamp(input.facing, -RULES.turnLimit, RULES.turnLimit);
    this.position.y = input.standingY;
    this.blocking = input.blocking;
    if (input.knuckles) {
      const { left, right } = input.knuckles;
      this.knuckles.wrL.set(left[0], left[1], left[2]);
      this.knuckles.wrR.set(right[0], right[1], right[2]);
    }
    this.tracked = true;
  }

  /** This fighter's live pose, for sending over the network. */
  snapshotPose(): Triple[] {
    return JOINTS.map((joint) => {
      const p = this.pose[joint];
      return [p.x, p.y, p.z] as Triple;
    });
  }

  /** Both hands up by the face and pulled in — not reaching out. */
  private readsAsGuard(): boolean {
    const chinHeight = this.pose.neck.y + 0.02;
    const chestZ = this.pose.chest.z;
    const tucked = (wrist: Vec3): boolean =>
      wrist.y > chinHeight && Math.abs(wrist.x) < 0.32 && wrist.z - chestZ < 0.42;
    return tucked(this.pose.wrL) && tucked(this.pose.wrR);
  }

  /**
   * Advances position, joint speeds and cooldowns. Call once per render frame,
   * after this frame's pose has settled.
   */
  integrate(dt: number): void {
    this.position.x = this.strafe * (this.side < 0 ? 1 : -1);
    const restingZ = RULES.separation * this.side + this.knockback * this.side;
    this.position.z += (restingZ - this.position.z) * Math.min(1, dt * 9);
    this.knockback = damp(this.knockback, 0, 0.02, dt);

    for (const joint of STRIKING_JOINTS) {
      const world = this.worldOf(joint, this.scratch);
      const travelled = world.distanceTo(this.previousWorld[joint]);
      this.speed[joint] = dt > 0 ? travelled / dt : 0;
      this.previousWorld[joint].copyFrom(world);

      const z = this.pose[joint].z;
      this.forwardSpeed[joint] = dt > 0 ? (z - this.previousLocalZ[joint]) / dt : 0;
      this.previousLocalZ[joint] = z;
    }

    this.cooldownMs.punch = Math.max(0, this.cooldownMs.punch - dt * 1000);
    this.cooldownMs.kick = Math.max(0, this.cooldownMs.kick - dt * 1000);
  }

  /**
   * Where a strike actually connects from.
   *
   * For a hand that is the knuckles, which sit the better part of a hand's
   * length past the wrist — aiming at the wrist aims short, which is exactly
   * the complaint that a punch does not reach. For a foot it is the ankle,
   * since that is the closest thing the pose gives to the striking surface.
   */
  strikePointOf(joint: JointName, into = new Vec3()): Vec3 {
    this.worldOf(joint, into);
    if (joint !== 'wrL' && joint !== 'wrR') return into;

    const offset = this.knuckles[joint];
    if (offset.x === 0 && offset.y === 0 && offset.z === 0) return into;

    // The offset is in local space, so it turns with the fighter.
    const yaw = this.yaw;
    const cos = Math.cos(yaw);
    const sin = Math.sin(yaw);
    return into.set(
      into.x + (offset.x * cos + offset.z * sin),
      into.y + offset.y,
      into.z + (-offset.x * sin + offset.z * cos),
    );
  }

  /**
   * Local pose to world: a rotation about Y by `yaw`, then a translation.
   *
   * Written out rather than done with a matrix because it is called for every
   * striking joint every frame, and because the renderers apply the identical
   * rotation — a fist is hittable exactly where it is drawn.
   *
   * @param into optional destination, to avoid allocating in the hot path.
   */
  worldOf(joint: JointName, into = new Vec3()): Vec3 {
    const local = this.pose[joint];
    const yaw = this.yaw;
    const cos = Math.cos(yaw);
    const sin = Math.sin(yaw);
    return into.set(
      this.position.x + (local.x * cos + local.z * sin),
      this.position.y + local.y,
      this.position.z + (-local.x * sin + local.z * cos),
    );
  }
}

/**
 * Which landmarks each joint is derived from.
 *
 * A joint is only trusted when every landmark behind it is. `chest` and `neck`
 * come off the shoulders and hips, so they are as reliable as the torso —
 * which is the part a camera almost always has.
 */
const JOINT_SOURCES: Readonly<Record<JointName, readonly number[]>> = {
  pelvis: [LANDMARK.hipL, LANDMARK.hipR],
  chest: [LANDMARK.shoulderL, LANDMARK.shoulderR, LANDMARK.hipL, LANDMARK.hipR],
  neck: [LANDMARK.shoulderL, LANDMARK.shoulderR],
  head: [LANDMARK.nose, LANDMARK.shoulderL, LANDMARK.shoulderR],
  shL: [LANDMARK.shoulderL],
  elL: [LANDMARK.elbowL],
  wrL: [LANDMARK.wristL],
  shR: [LANDMARK.shoulderR],
  elR: [LANDMARK.elbowR],
  wrR: [LANDMARK.wristR],
  hipL: [LANDMARK.hipL],
  knL: [LANDMARK.kneeL],
  anL: [LANDMARK.ankleL],
  hipR: [LANDMARK.hipR],
  knR: [LANDMARK.kneeR],
  anR: [LANDMARK.ankleR],
};

/** Which joints the tracker actually saw this frame, rather than inferred. */
function confidentJoints(reading: BodyReading): Record<JointName, boolean> {
  const scores = reading.visibility;
  const seen = {} as Record<JointName, boolean>;
  for (const joint of JOINTS) {
    // No scores at all means an older tracker; trust everything, as before.
    seen[joint] =
      !scores ||
      JOINT_SOURCES[joint].every((index) => (scores[index] ?? 1) >= MIN_VISIBILITY);
  }
  return seen;
}

/**
 * Turns a camera reading into a hips-centred local pose, or null when the
 * reading is missing a landmark the skeleton needs.
 */
function localPoseFromReading(reading: BodyReading): Record<JointName, Vec3> | null {
  const at = (index: number): Vec3 | null => {
    const landmark = reading.world[index];
    // The vision model's Y grows downward and its Z grows away from the
    // camera; the game's Y grows up and Z grows toward the opponent.
    return landmark ? new Vec3(landmark[0], -landmark[1], -landmark[2]) : null;
  };

  const shoulderL = at(LANDMARK.shoulderL);
  const shoulderR = at(LANDMARK.shoulderR);
  const hipL = at(LANDMARK.hipL);
  const hipR = at(LANDMARK.hipR);
  const nose = at(LANDMARK.nose);
  const elbowL = at(LANDMARK.elbowL);
  const elbowR = at(LANDMARK.elbowR);
  const wristL = at(LANDMARK.wristL);
  const wristR = at(LANDMARK.wristR);
  const kneeL = at(LANDMARK.kneeL);
  const kneeR = at(LANDMARK.kneeR);
  const ankleL = at(LANDMARK.ankleL);
  const ankleR = at(LANDMARK.ankleR);

  if (
    !shoulderL ||
    !shoulderR ||
    !hipL ||
    !hipR ||
    !nose ||
    !elbowL ||
    !elbowR ||
    !wristL ||
    !wristR ||
    !kneeL ||
    !kneeR ||
    !ankleL ||
    !ankleR
  ) {
    return null;
  }

  const neck = Vec3.mid(shoulderL, shoulderR);
  const pelvis = Vec3.mid(hipL, hipR);
  const pose: Record<JointName, Vec3> = {
    pelvis,
    neck,
    chest: pelvis.clone().lerpTo(neck, CHEST_ALONG_SPINE),
    head: nose.clone().lerpTo(neck, 0.18).addTo(new Vec3(0, 0.04, 0)),
    shL: shoulderL,
    elL: elbowL,
    wrL: wristL,
    shR: shoulderR,
    elR: elbowR,
    wrR: wristR,
    hipL,
    knL: kneeL,
    anL: ankleL,
    hipR,
    knR: kneeR,
    anR: ankleR,
  };

  // Re-centre on the hips, so where the player stands in the room does not
  // drag the fighter across the arena. Strafing is handled separately.
  const origin = pelvis.clone();
  for (const joint of JOINTS) pose[joint].subTo(origin);
  stiffenTorso(pose);
  return pose;
}

/**
 * Stops the torso folding over.
 *
 * A single camera measures depth poorly, and the torso is where that hurts
 * most: the spine is driven by the direction from the hips to the chest, and
 * both ends of that line come from landmarks whose Z is a guess. Lean toward
 * the camera and the model reports the shoulders well forward of the hips —
 * so the fighter bends at the waist, and at the extreme folds in half with
 * its head by the floor. It reads as cloth rather than a person.
 *
 * A real fighter's torso does lean, but within limits, so the measured tilt is
 * capped rather than discarded. The chest, neck and head all move together,
 * which keeps the spine straight and the head attached.
 */
function stiffenTorso(pose: Record<JointName, Vec3>): void {
  // The pose is hips-centred, so `neck` *is* the torso axis.
  const axis = pose.neck;
  const length = axis.length();
  if (length < 1e-4) return;

  const tilt = Math.acos(clamp(axis.y / length, -1, 1));
  if (tilt <= MAX_TORSO_TILT) return;

  // Keep the lean's direction, limit its size: rebuild the axis at exactly
  // the maximum tilt, still leaning the way the player is leaning.
  const horizontal = Math.hypot(axis.x, axis.z);
  const lean = Math.sin(MAX_TORSO_TILT);
  const upright = Math.cos(MAX_TORSO_TILT);
  const limited =
    horizontal < 1e-4
      ? new Vec3(0, upright, 0)
      : new Vec3((axis.x / horizontal) * lean, upright, (axis.z / horizontal) * lean);

  // The head keeps its offset from the neck, so looking around still works.
  const headOffset = Vec3.sub(pose.head, pose.neck);
  pose.neck.set(limited.x * length, limited.y * length, limited.z * length);
  pose.head.copyFrom(pose.neck).addTo(headOffset);
  // The chest sits along the same axis, which is what keeps the spine straight.
  pose.chest.set(pose.neck.x * CHEST_ALONG_SPINE, pose.neck.y * CHEST_ALONG_SPINE, pose.neck.z * CHEST_ALONG_SPINE);
}
