/**
 * The fighter's skeleton, as plain numbers.
 *
 * Poses are stored as `[x, y, z]` tuples rather than vector objects so that
 * blending two poses is scalar arithmetic with no allocation — the animation
 * blender runs over 16 joints twice a frame and must not litter the heap.
 *
 * Local space: +X is the fighter's own left, +Y is up, +Z points at the
 * opponent. Every pose below is expressed in that frame, which is what lets
 * the same numbers drive both fighters, mirrored.
 */
export type Triple = readonly [x: number, y: number, z: number];

export const JOINTS = [
  'pelvis',
  'chest',
  'neck',
  'head',
  'shL',
  'elL',
  'wrL',
  'shR',
  'elR',
  'wrR',
  'hipL',
  'knL',
  'anL',
  'hipR',
  'knR',
  'anR',
] as const;

export type JointName = (typeof JOINTS)[number];

/** Joints that can land a blow, and therefore need speed tracking. */
export const STRIKING_JOINTS = ['wrL', 'wrR', 'anL', 'anR'] as const;
export type StrikingJoint = (typeof STRIKING_JOINTS)[number];

export const BONES: readonly (readonly [JointName, JointName])[] = [
  ['pelvis', 'chest'],
  ['chest', 'neck'],
  ['neck', 'head'],
  ['chest', 'shL'],
  ['shL', 'elL'],
  ['elL', 'wrL'],
  ['chest', 'shR'],
  ['shR', 'elR'],
  ['elR', 'wrR'],
  ['pelvis', 'hipL'],
  ['hipL', 'knL'],
  ['knL', 'anL'],
  ['pelvis', 'hipR'],
  ['hipR', 'knR'],
  ['knR', 'anR'],
];

/** Sphere radius per joint; anything unlisted uses `DEFAULT_JOINT_RADIUS`. */
export const JOINT_RADIUS: Readonly<Partial<Record<JointName, number>>> = {
  head: 0.125,
  chest: 0.085,
  pelvis: 0.085,
  neck: 0.055,
};
export const DEFAULT_JOINT_RADIUS = 0.05;

export const radiusOf = (joint: JointName): number =>
  JOINT_RADIUS[joint] ?? DEFAULT_JOINT_RADIUS;

/** The neutral fighting stance every animation blends back toward. */
export const STANCE: Readonly<Record<JointName, Triple>> = {
  pelvis: [0, 0, 0],
  chest: [0, 0.29, 0.02],
  neck: [0, 0.5, 0.01],
  head: [0, 0.68, 0.01],
  shL: [0.19, 0.46, 0.02],
  elL: [0.27, 0.24, 0.12],
  wrL: [0.15, 0.42, 0.24],
  shR: [-0.19, 0.46, 0.02],
  elR: [-0.27, 0.24, 0.12],
  wrR: [-0.15, 0.42, 0.24],
  hipL: [0.11, 0, 0],
  knL: [0.15, -0.42, 0.06],
  anL: [0.16, -0.84, 0.1],
  hipR: [-0.11, 0, 0],
  knR: [-0.16, -0.42, -0.02],
  anR: [-0.17, -0.84, -0.06],
};

/** MediaPipe pose landmark indices this game reads. */
export const LANDMARK = {
  nose: 0,
  shoulderL: 11,
  shoulderR: 12,
  elbowL: 13,
  elbowR: 14,
  wristL: 15,
  wristR: 16,
  hipL: 23,
  hipR: 24,
  kneeL: 25,
  kneeR: 26,
  ankleL: 27,
  ankleR: 28,
} as const;

/** Bones drawn on the little camera preview. */
export const OVERLAY_LINKS: readonly (readonly [number, number])[] = [
  [11, 12],
  [11, 13],
  [13, 15],
  [12, 14],
  [14, 16],
  [11, 23],
  [12, 24],
  [23, 24],
  [23, 25],
  [25, 27],
  [24, 26],
  [26, 28],
  [0, 11],
  [0, 12],
];
