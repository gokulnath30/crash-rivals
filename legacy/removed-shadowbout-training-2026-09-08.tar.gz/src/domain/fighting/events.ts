import type { Vec3 } from '../shared/vec3.ts';
import type { MoveName } from './moves.ts';

/**
 * Which of the two fighters something happened to. Deliberately separate from
 * the lobby's `SeatIndex`: the fighting rules know nothing about rooms, and
 * the game session is what maps one onto the other.
 */
export type FighterIndex = 0 | 1;

export const otherFighter = (index: FighterIndex): FighterIndex => (index === 0 ? 1 : 0);

/** Where on the body a blow landed. */
export type HitZone = 'head' | 'body' | 'low';

/**
 * Everything the simulation wants the outside world to know about, as data.
 *
 * This is the seam that makes audio, HUD and particles possible without the
 * rules knowing any of them exist: the fighting domain emits events, and the
 * renderer, the mixer and the scoreboard each read the ones they care about.
 */
export type FightEvent =
  | {
      readonly kind: 'hit';
      readonly attacker: FighterIndex;
      readonly defender: FighterIndex;
      readonly damage: number;
      readonly blocked: boolean;
      readonly heavy: boolean;
      readonly zone: HitZone;
      /** World-space point of contact, for sparks and damage numbers. */
      readonly contact: Vec3;
      readonly label: string;
    }
  | {
      readonly kind: 'whiff';
      readonly attacker: FighterIndex;
      readonly at: Vec3;
      /** A short nudge for the player: "line up with them". */
      readonly hint: string;
    }
  | { readonly kind: 'move-thrown'; readonly attacker: FighterIndex; readonly move: MoveName }
  | { readonly kind: 'guard-raised'; readonly fighter: FighterIndex }
  | { readonly kind: 'knockout'; readonly loser: FighterIndex }
  | { readonly kind: 'round-start'; readonly round: number }
  | {
      readonly kind: 'round-end';
      readonly winner: FighterIndex | null;
      readonly round: number;
      readonly wins: readonly [number, number];
      readonly matchOver: boolean;
    }
  | { readonly kind: 'time-up'; readonly winner: FighterIndex | null }
  | { readonly kind: 'announce'; readonly text: string; readonly holdMs: number };

/** A convenience for the many places that collect events then drain them. */
export class EventBuffer {
  private events: FightEvent[] = [];

  emit(event: FightEvent): void {
    this.events.push(event);
  }

  emitAll(events: readonly FightEvent[]): void {
    for (const event of events) this.events.push(event);
  }

  /** Hands over everything queued and clears the buffer. */
  drain(): readonly FightEvent[] {
    if (this.events.length === 0) return EMPTY;
    const drained = this.events;
    this.events = [];
    return drained;
  }

  get size(): number {
    return this.events.length;
  }
}

const EMPTY: readonly FightEvent[] = Object.freeze([]);
