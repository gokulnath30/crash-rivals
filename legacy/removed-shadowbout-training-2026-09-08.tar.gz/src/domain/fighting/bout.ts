import { hitstopFor } from './combat.ts';
import type { FightEvent, FighterIndex } from './events.ts';
import { RULES } from './moves.ts';

/**
 * The scoreboard and the clock: rounds, wins, and the short pauses between
 * them.
 *
 * The original version of this game leaned on `setTimeout` for "announce K.O.,
 * then end the round a second and a half later". That works, but it puts the
 * match's state somewhere no test can reach and no pause can stop. Here every
 * delay is a `pending` entry advanced by `tick`, so a bout is a plain state
 * machine: feed it time, collect events.
 */
export type BoutPhase =
  | 'waiting'
  | 'fighting'
  /** A knockout or the clock has landed; the announcement is playing out. */
  | 'settling'
  | 'round-over'
  | 'match-over';

type PendingAction =
  | { readonly kind: 'shout-fight' }
  | { readonly kind: 'end-round'; readonly winner: FighterIndex | null }
  | { readonly kind: 'replay-round' };

interface Pending {
  readonly action: PendingAction;
  secondsLeft: number;
}

const FIGHT_SHOUT_DELAY = 1.1;
const SETTLE_DELAY = 1.5;

export class Bout {
  round = 1;
  readonly wins: [number, number] = [0, 0];
  timeLeft: number = RULES.roundSeconds;
  phase: BoutPhase = 'waiting';

  /** Seconds of freeze-frame left on an impact. */
  hitstop = 0;

  private pending: Pending | null = null;

  get isFighting(): boolean {
    return this.phase === 'fighting';
  }

  /** True once one fighter has taken enough rounds to win the bout. */
  get decided(): boolean {
    return this.wins[0] >= RULES.roundsToWin || this.wins[1] >= RULES.roundsToWin;
  }

  get winner(): FighterIndex | null {
    if (this.wins[0] >= RULES.roundsToWin) return 0;
    if (this.wins[1] >= RULES.roundsToWin) return 1;
    return null;
  }

  /** Wipes the scoreboard for a fresh bout. */
  resetMatch(): void {
    this.round = 1;
    this.wins[0] = 0;
    this.wins[1] = 0;
    this.phase = 'waiting';
    this.pending = null;
    this.hitstop = 0;
    this.timeLeft = RULES.roundSeconds;
  }

  beginRound(): readonly FightEvent[] {
    this.timeLeft = RULES.roundSeconds;
    this.phase = 'fighting';
    this.hitstop = 0;
    this.pending = { action: { kind: 'shout-fight' }, secondsLeft: FIGHT_SHOUT_DELAY };
    return [
      { kind: 'round-start', round: this.round },
      { kind: 'announce', text: `Round ${this.round}`, holdMs: 900 },
    ];
  }

  /** Called when a blow drops someone. The round is over; the shouting is not. */
  recordKnockout(loser: FighterIndex): readonly FightEvent[] {
    if (this.phase !== 'fighting') return NONE;
    const winner: FighterIndex = loser === 0 ? 1 : 0;
    this.wins[winner] += 1;
    this.phase = 'settling';
    this.pending = { action: { kind: 'end-round', winner }, secondsLeft: SETTLE_DELAY };
    return [{ kind: 'announce', text: 'K.O.', holdMs: 1200 }];
  }

  /**
   * Freezes the picture for a moment on impact. Applied through
   * `scaleFrameTime`, so the whole simulation slows together.
   */
  registerImpact(blocked: boolean, heavy: boolean): void {
    this.hitstop = Math.max(this.hitstop, hitstopFor(blocked, heavy));
  }

  /**
   * Burns hitstop and reports the time the simulation should actually advance.
   * Call once per frame, before `tick`.
   */
  scaleFrameTime(dt: number): number {
    if (this.hitstop <= 0) return dt;
    this.hitstop -= dt;
    return dt * HITSTOP_TIME_SCALE;
  }

  /**
   * Advances the clock and any pending announcement.
   *
   * @param hp current health of both fighters, for deciding a bout on time.
   */
  tick(dt: number, hp: readonly [number, number]): readonly FightEvent[] {
    const events: FightEvent[] = [];

    if (this.pending) {
      this.pending.secondsLeft -= dt;
      if (this.pending.secondsLeft <= 0) {
        const { action } = this.pending;
        this.pending = null;
        events.push(...this.runPending(action));
      }
    }

    if (this.phase === 'fighting') {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        events.push(...this.callTime(hp));
      }
    }

    return events;
  }

  /** The player asked for the next round (or a rematch) from the result screen. */
  advance(): readonly FightEvent[] {
    if (this.phase === 'match-over') {
      this.resetMatch();
    } else if (this.phase === 'round-over') {
      this.round += 1;
    }
    return this.beginRound();
  }

  private runPending(action: PendingAction): readonly FightEvent[] {
    switch (action.kind) {
      case 'shout-fight':
        // Only shout if the round is genuinely still going; a very fast
        // knockout would otherwise be followed by an eager "Fight".
        return this.phase === 'fighting'
          ? [{ kind: 'announce', text: 'Fight', holdMs: 700 }]
          : NONE;

      case 'end-round':
        return this.closeRound(action.winner);

      case 'replay-round':
        return this.beginRound();
    }
  }

  private closeRound(winner: FighterIndex | null): readonly FightEvent[] {
    const matchOver = this.decided;
    this.phase = matchOver ? 'match-over' : 'round-over';
    return [
      {
        kind: 'round-end',
        winner,
        round: this.round,
        wins: [this.wins[0], this.wins[1]],
        matchOver,
      },
    ];
  }

  /** The clock ran out: most health takes the round, level health replays it. */
  private callTime(hp: readonly [number, number]): readonly FightEvent[] {
    const [a, b] = hp;
    this.phase = 'settling';

    if (a === b) {
      this.pending = { action: { kind: 'replay-round' }, secondsLeft: SETTLE_DELAY };
      return [
        { kind: 'time-up', winner: null },
        { kind: 'announce', text: 'Draw', holdMs: 1200 },
      ];
    }

    const winner: FighterIndex = a > b ? 0 : 1;
    this.wins[winner] += 1;
    this.pending = { action: { kind: 'end-round', winner }, secondsLeft: SETTLE_DELAY };
    return [
      { kind: 'time-up', winner },
      { kind: 'announce', text: 'Time', holdMs: 1200 },
    ];
  }
}

/** How far time slows during hitstop. Not zero, so the freeze still breathes. */
const HITSTOP_TIME_SCALE = 0.18;

const NONE: readonly FightEvent[] = Object.freeze([]);
