import type { BodyReading } from '@domain/fighting/body-reading.ts';
import type { Result } from '@domain/shared/result.ts';
import type { Listener, Unsubscribe } from './types.ts';

/** One tracking frame: every body the camera can currently see. */
export interface PoseFrame {
  /**
   * Bodies sorted left to right across the frame, so "the player on the left"
   * is always index 0 however the model happened to order them.
   */
  readonly bodies: readonly BodyReading[];
  /** Normalised landmarks for the preview overlay, in the same order. */
  readonly forOverlay: readonly (readonly (readonly [number, number, number])[])[];
  readonly atMs: number;
}

export type PoseStatus =
  | { readonly kind: 'off' }
  | { readonly kind: 'starting'; readonly message: string }
  | { readonly kind: 'tracking'; readonly bodies: number }
  | { readonly kind: 'no-body' }
  | { readonly kind: 'failed'; readonly message: string };

/**
 * Body tracking as a port. The game asks for "the bodies you can see"; which
 * vision library answers, and whether it runs on the GPU, stays behind here.
 */
export interface PoseSourcePort {
  readonly status: PoseStatus;

  /**
   * Asks for the camera and loads the model.
   *
   * @param bodies how many people to track.
   *
   * Always 1 now that two-on-one-camera play is gone, but the parameter stays:
   * the choice of tracker still hangs on it, and only the pose-only model can
   * see two people at all.
   */
  start(bodies: 1 | 2): Promise<Result<void>>;

  /**
   * The newest frame, or null if nothing new has arrived since last asked.
   * Pull-based on purpose: the game loop decides when it wants input, rather
   * than being interrupted at the camera's frame rate.
   */
  read(): PoseFrame | null;

  onStatusChange(listener: Listener<PoseStatus>): Unsubscribe;

  /** The live camera feed, for the little preview window. */
  videoElement(): HTMLVideoElement | null;

  /**
   * The raw camera stream.
   *
   * Needed because an online match sends the same camera to the other player:
   * a device generally will not open twice, so the call has to share the one
   * the tracker already holds rather than asking for its own.
   */
  mediaStream(): MediaStream | null;

  stop(): void;
}
